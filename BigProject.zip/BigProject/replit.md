# DnD Interactive Table - Post-Apocalyptic USSR/STALKER

## Overview
This project aims to develop a comprehensive interactive system for DnD tables set in a post-apocalyptic USSR/STALKER universe. The system is designed to support over 1000 simultaneous players across various mobile devices (smartphones and 8.7" tablets). It includes robust features for character management, inventory, real-time interactions, trading, and administrative control, all within a custom-themed interface. The ultimate vision is to create an immersive and scalable platform for a unique tabletop role-playing experience.

## User Preferences
- **Interface Language**: Russian
- **Design Aesthetic**: Post-apocalyptic USSR/STALKER (dark palette, specific fonts: Roboto Condensed, Russo One, JetBrains Mono)
- **Target Devices**: Smartphones and 8.7" tablets (1340x800), supporting both portrait and landscape orientations.
- **Development Workflow**: Iterative development, focusing on completing core features before moving to planned enhancements.
- **Interaction**: The agent should prioritize the completion of "In Progress" tasks before starting "Planned" features.
- **Code Style**: Adherence to established architectural decisions and existing code patterns.

## System Architecture
The system is built around a robust client-server architecture with real-time capabilities.

### UI/UX Decisions
- **Theme**: Dark theme with a post-apocalyptic USSR/STALKER aesthetic.
- **Typography**: Roboto Condensed for UI, Russo One for headings, and JetBrains Mono for data.
- **Spacing**: Micro (p-2), Component (p-4), Section (p-8).
- **Animations**: Minimal, with 100-300ms transitions.
- **Responsiveness**: Mobile-first design with breakpoints for tablets and desktops.
- **Components**: Utilizes shadcn/ui for consistent UI elements.

### Technical Implementations
- **Database**: PostgreSQL with Drizzle ORM for schema definition and interaction. Includes 30+ tables with indices, enums, and JSONB for flexible data.
- **Backend**: Express.js server handling API routes, authentication, and WebSocket connections.
- **Frontend**: React application for the user interface, utilizing `wouter` for routing and `@tanstack/react-query` for data fetching and state management.
- **Real-time Communication**: WebSocket (Socket.IO) for features like lobby updates, chat, and auction.
- **Authentication**: Express sessions with a PostgreSQL store, bcrypt for password hashing, and role-based access control (Admin/GM/Player).
- **Storage Pattern**: A centralized `IStorage` interface with a `DatabaseStorage` implementation using Drizzle ORM for all CRUD operations.
- **API Design**: RESTful endpoints with `/api` prefix, standard HTTP status codes, and Zod validation for schemas.
- **Inventory System**: ENHANCED - Tetris-style inventory with advanced rotation logic (pre-rotation collision & boundary validation), full AABB collision detection on backend (including negative coordinate guards), optimized queries using getInventoryWithItems, improved rarity-based visualization (8 color levels with enhanced contrast), stack count display, and weight tracking. Expandable grid with drag-and-drop support. **NEW**: Equipment slots system (12 slots: head, headphones, top, armor, vest, belt, strap, hands, bottom, footwear), equip/unequip API with stat & class requirements validation, visual slots UI with character silhouette.
- **Chat System**: Real-time chat with `/roll` dice commands (e.g., `2d6`, `1d20+5`), message history, and dice roll visualization.
- **Traders System**: COMPLETED - Multi-currency transactions (9 currencies: gold, silver, cores, sovietMedal1-3, reichMark1-3), rotation-aware inventory placement, stock management, real-time updates. E2E tested with Playwright.
- **Admin Panel**: Dedicated interface for managing users, items, and viewing action logs, accessible only to admin users.

### Feature Specifications
- **Characters**: 6 STALKER classes, **27 characteristics in 6 categories** (Тело: 5, Интеллект: 5, Восприятие: 5, Харизма: 5, Реакция: 5, Сопротивление: 2), limit of 2 characters per account, maxWeight 80kg, avatar support (planned Object Storage).
- **Items**: ENHANCED - 8 rarity levels, **4 quality levels** (damaged, normal, good, perfect), **consumable types** (healing, hunger, thirst, radiation, temperature, stamina, buff), **stat requirements** (requiredStats JSONB), **class restrictions** (classRestrictions JSONB), durability system (breaks at 0, repairable via crafting), **stack limits** (ammo: 120, currency: 50, others: 1), JSONB for stat modifiers supporting all 27 characteristics, equipment slots (top, bottom, head, footwear, headphones, armor, vest, belt, strap, hand_left, hand_right).
- **Active Effects**: NEW TABLE - Temporary buffs/debuffs with real-time expiration (startedAt, expiresAt), stat modifiers (JSONB), source tracking, positive/negative flags. Storage methods: getActiveEffects, createActiveEffect, deleteActiveEffect, cleanupExpiredEffects.
- **Lobby**: 10x10 item grid with real-time pickup mechanics and item locking.
- **Auction**: Planned with a customizable storage, lot duration, and single-currency pricing.
- **News System**: Planned with rich-text support.
- **Crafting System**: COMPLETED - Backend API routes (GET/POST/PATCH/DELETE /api/recipes, POST /api/craft), frontend pages (crafting.tsx, recipes-admin.tsx), navigation in admin panel and home page.
- **GM Panel**: Planned for managing traders and spawning items.
- **World Map**: Planned canvas interaction.

## External Dependencies
- **Database**: PostgreSQL (specifically Neon for `DATABASE_URL`).
- **ORM**: Drizzle ORM.
- **Real-time**: `ws` (WebSocket server) and Socket.IO for client-side.
- **Authentication**: `bcryptjs` for password hashing, `express-session` and `connect-pg-simple` for session management.
- **Frontend Libraries**: React, `wouter`, `@tanstack/react-query`, `shadcn/ui`, `tailwindcss`.
- **Validation**: Zod.