import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation, useParams } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { InventoryItem, Item, Character } from "@shared/schema";
import { ArrowLeft, RotateCw, Trash2 } from "lucide-react";
import {
  DndContext,
  DragEndEvent,
  DragOverlay,
  MouseSensor,
  TouchSensor,
  useSensor,
  useSensors,
  useDraggable,
  useDroppable,
} from "@dnd-kit/core";
import { CSS } from "@dnd-kit/utilities";
import EquipmentSlots from "@/components/EquipmentSlots";
import CharacterStats from "@/components/CharacterStats";

const GRID_CELL_SIZE = 50; // pixels
const MAX_GRID_WIDTH = 10;
const MAX_GRID_HEIGHT = 10;

// Rarity colors (optimized for dark theme with better contrast)
const RARITY_COLORS = {
  poor: "border-gray-600 bg-gray-600/20",
  common: "border-slate-400 bg-slate-400/15",
  uncommon: "border-green-500 bg-green-500/20",
  rare: "border-blue-500 bg-blue-500/20",
  epic: "border-purple-500 bg-purple-500/20",
  legendary: "border-orange-500 bg-orange-500/20",
  artifact: "border-red-500 bg-red-500/20",
  unique: "border-yellow-400 bg-yellow-400/20",
};

interface GridItem extends InventoryItem {
  item: Item;
}

// Droppable grid cell component
function DroppableCell({ x, y }: { x: number; y: number }) {
  const { setNodeRef, isOver } = useDroppable({
    id: `${x}-${y}`,
  });

  return (
    <div
      ref={setNodeRef}
      className={`border border-border/30 ${isOver ? "bg-primary/20" : "bg-card/20"}`}
      style={{
        width: GRID_CELL_SIZE,
        height: GRID_CELL_SIZE,
      }}
      data-testid={`grid-cell-${x}-${y}`}
    />
  );
}

// Draggable inventory item component
function DraggableItem({
  gridItem,
  isSelected,
  onSelect,
}: {
  gridItem: GridItem;
  isSelected: boolean;
  onSelect: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: gridItem.id,
  });

  const itemWidth = gridItem.rotated ? gridItem.item.height : gridItem.item.width;
  const itemHeight = gridItem.rotated ? gridItem.item.width : gridItem.item.height;

  const style = {
    left: gridItem.gridX * GRID_CELL_SIZE,
    top: gridItem.gridY * GRID_CELL_SIZE,
    width: itemWidth * GRID_CELL_SIZE,
    height: itemHeight * GRID_CELL_SIZE,
    transform: CSS.Translate.toString(transform),
  };

  const rarityClass = RARITY_COLORS[gridItem.item.rarity as keyof typeof RARITY_COLORS] || RARITY_COLORS.common;
  const showStack = gridItem.stackCount && gridItem.stackCount > 1;

  return (
    <div
      ref={setNodeRef}
      {...listeners}
      {...attributes}
      className={`absolute cursor-grab border-2 p-1 hover-elevate active-elevate-2 ${
        isSelected ? "border-primary" : rarityClass
      } ${isDragging ? "opacity-50" : ""}`}
      style={style}
      onClick={onSelect}
      data-testid={`inventory-item-${gridItem.id}`}
    >
      <div className="flex h-full flex-col items-center justify-center">
        <p className="text-center text-xs font-mono leading-tight">
          {gridItem.item.name}
        </p>
        {showStack && (
          <span className="mt-0.5 text-[10px] font-bold text-primary">
            ×{gridItem.stackCount}
          </span>
        )}
      </div>
    </div>
  );
}

export default function InventoryPage() {
  const { characterId } = useParams<{ characterId: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [selectedItem, setSelectedItem] = useState<GridItem | null>(null);
  const [activeId, setActiveId] = useState<number | null>(null);

  // Setup drag sensors for mouse and touch
  const mouseSensor = useSensor(MouseSensor, {
    activationConstraint: {
      distance: 10, // Require 10px movement before drag starts
    },
  });
  const touchSensor = useSensor(TouchSensor, {
    activationConstraint: {
      delay: 250, // Require 250ms press before drag starts
      tolerance: 5,
    },
  });
  const sensors = useSensors(mouseSensor, touchSensor);

  // Get character
  const { data: character, isLoading: characterLoading } = useQuery<Character>({
    queryKey: [`/api/characters/${characterId}`],
    enabled: !!characterId,
  });

  // Get inventory (already includes joined item data from backend)
  const { data: inventory = [], isLoading: inventoryLoading } = useQuery<GridItem[]>({
    queryKey: [`/api/characters/${characterId}/inventory`],
    enabled: !!characterId,
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/inventory/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/characters/${characterId}/inventory`] });
      toast({
        title: "Предмет удалён",
      });
      setSelectedItem(null);
    },
  });

  // Move mutation
  const moveMutation = useMutation({
    mutationFn: async (data: { id: number; gridX: number; gridY: number; rotated: boolean }) => {
      return apiRequest("PATCH", `/api/inventory/${data.id}`, {
        gridX: data.gridX,
        gridY: data.gridY,
        rotated: data.rotated,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/characters/${characterId}/inventory`] });
    },
  });

  // Expand inventory mutation
  const expandMutation = useMutation({
    mutationFn: async (data: { width: number; height: number }) => {
      return apiRequest("PATCH", `/api/characters/${characterId}/inventory/expand`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/characters/${characterId}`] });
      toast({
        title: "Инвентарь расширен",
      });
    },
  });

  // Equip mutation
  const equipMutation = useMutation({
    mutationFn: async (data: { id: number; slot: string }) => {
      return apiRequest("POST", `/api/inventory/${data.id}/equip`, { slot: data.slot });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/characters/${characterId}/inventory`] });
      queryClient.invalidateQueries({ queryKey: [`/api/characters/${characterId}`] });
      toast({
        title: "Предмет экипирован",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось экипировать предмет",
        variant: "destructive",
      });
    },
  });

  // Unequip mutation
  const unequipMutation = useMutation({
    mutationFn: async (data: { id: number; gridX: number; gridY: number }) => {
      return apiRequest("POST", `/api/inventory/${data.id}/unequip`, {
        gridX: data.gridX,
        gridY: data.gridY,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/characters/${characterId}/inventory`] });
      queryClient.invalidateQueries({ queryKey: [`/api/characters/${characterId}`] });
      toast({
        title: "Предмет снят",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось снять предмет",
        variant: "destructive",
      });
    },
  });

  // Filter equipped and grid items
  const equippedItems = inventory.filter((item) => item.equippedSlot !== null);
  const gridItems = inventory.filter((item) => item.equippedSlot === null);

  // Redirect if not authenticated
  const { data: currentUser, isLoading: userLoading } = useQuery({
    queryKey: ["/api/auth/me"],
    retry: false,
  });

  useEffect(() => {
    if (!userLoading && !currentUser) {
      setLocation("/login");
    }
  }, [currentUser, userLoading, setLocation]);

  if (userLoading || characterLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <p className="text-muted-foreground">Загрузка...</p>
      </div>
    );
  }

  if (!character) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <p className="text-muted-foreground">Персонаж не найден</p>
      </div>
    );
  }

  const handleRotateItem = (item: GridItem) => {
    const newRotated = !item.rotated;
    
    // Calculate new dimensions after rotation
    const newWidth = newRotated ? item.item.height : item.item.width;
    const newHeight = newRotated ? item.item.width : item.item.height;
    
    const gridWidth = character?.inventoryGridWidth || 4;
    const gridHeight = character?.inventoryGridHeight || 2;
    
    // Check if item fits within grid bounds after rotation
    if (item.gridX + newWidth > gridWidth || item.gridY + newHeight > gridHeight) {
      toast({
        title: "Невозможно повернуть",
        description: "Предмет не помещается в текущей позиции после поворота",
        variant: "destructive",
      });
      return;
    }
    
    // Check for collisions with other items after rotation
    const hasCollision = gridItems.some((otherItem) => {
      if (otherItem.id === item.id) {
        return false;
      }
      
      const otherWidth = otherItem.rotated
        ? otherItem.item.height
        : otherItem.item.width;
      const otherHeight = otherItem.rotated
        ? otherItem.item.width
        : otherItem.item.height;
      
      // Check if rectangles overlap
      return !(
        item.gridX + newWidth <= otherItem.gridX ||
        item.gridX >= otherItem.gridX + otherWidth ||
        item.gridY + newHeight <= otherItem.gridY ||
        item.gridY >= otherItem.gridY + otherHeight
      );
    });
    
    if (hasCollision) {
      toast({
        title: "Невозможно повернуть",
        description: "Место будет занято другим предметом",
        variant: "destructive",
      });
      return;
    }
    
    // Rotation is valid, proceed
    moveMutation.mutate({
      id: item.id,
      gridX: item.gridX,
      gridY: item.gridY,
      rotated: newRotated,
    });
  };

  const handleDeleteItem = (item: GridItem) => {
    if (confirm(`Удалить ${item.item.name}?`)) {
      deleteMutation.mutate(item.id);
    }
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveId(null);

    if (!over) {
      return;
    }

    // Parse dragged item ID
    const draggedItemId = Number(active.id);
    const draggedItem = inventory.find((item) => item.id === draggedItemId);

    if (!draggedItem) {
      return;
    }

    // Parse drop cell coordinates
    const [dropX, dropY] = (over.id as string).split("-").map(Number);

    // Calculate item dimensions (considering rotation)
    const itemWidth = draggedItem.rotated
      ? draggedItem.item.height
      : draggedItem.item.width;
    const itemHeight = draggedItem.rotated
      ? draggedItem.item.width
      : draggedItem.item.height;

    // Check if item fits within grid bounds
    const gridWidth = character?.inventoryGridWidth || 4;
    const gridHeight = character?.inventoryGridHeight || 2;
    
    if (dropX + itemWidth > gridWidth || dropY + itemHeight > gridHeight) {
      toast({
        title: "Невозможно разместить",
        description: "Предмет не помещается в выбранной позиции",
        variant: "destructive",
      });
      return;
    }

    // Check for collisions with other items
    const hasCollision = gridItems.some((otherItem) => {
      if (otherItem.id === draggedItemId) {
        return false;
      }

      const otherWidth = otherItem.rotated
        ? otherItem.item.height
        : otherItem.item.width;
      const otherHeight = otherItem.rotated
        ? otherItem.item.width
        : otherItem.item.height;

      // Check if rectangles overlap
      return !(
        dropX + itemWidth <= otherItem.gridX ||
        dropX >= otherItem.gridX + otherWidth ||
        dropY + itemHeight <= otherItem.gridY ||
        dropY >= otherItem.gridY + otherHeight
      );
    });

    if (hasCollision) {
      toast({
        title: "Коллизия",
        description: "Место занято другим предметом",
        variant: "destructive",
      });
      return;
    }

    // Update item position
    moveMutation.mutate({
      id: draggedItemId,
      gridX: dropX,
      gridY: dropY,
      rotated: draggedItem.rotated,
    });
  };

  // Create grid cells coordinates
  const gridCells: { x: number; y: number }[] = [];
  const gridWidth = character?.inventoryGridWidth || 4;
  const gridHeight = character?.inventoryGridHeight || 2;
  
  for (let y = 0; y < gridHeight; y++) {
    for (let x = 0; x < gridWidth; x++) {
      gridCells.push({ x, y });
    }
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="mx-auto max-w-6xl">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/world/sphere")}
              data-testid="button-back"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="font-russo text-2xl">Инвентарь</h1>
              <p className="text-sm text-muted-foreground">{character.name}</p>
            </div>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
          {/* Left column: Equipment and Stats */}
          <div className="space-y-4">
            <EquipmentSlots
              equippedItems={equippedItems}
              onSlotClick={(slot) => {
                const equippedItem = equippedItems.find((item) => item.equippedSlot === slot);
                if (!equippedItem) return;

                // Try to unequip to (0,0) - backend will validate and return error if occupied
                unequipMutation.mutate({
                  id: equippedItem.id,
                  gridX: 0,
                  gridY: 0,
                });
              }}
            />
            <CharacterStats character={character} />
          </div>

          {/* Right column: Grid and Item Details */}
          <div className="space-y-4">
            {/* Grid */}
            <Card className="p-6">
            <div className="mb-4 space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="font-russo text-lg">
                  Сетка: {gridWidth}×{gridHeight}
                </h2>
                {(gridWidth < MAX_GRID_WIDTH || gridHeight < MAX_GRID_HEIGHT) && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      expandMutation.mutate({
                        width: Math.min(gridWidth + 1, MAX_GRID_WIDTH),
                        height: Math.min(gridHeight + 1, MAX_GRID_HEIGHT),
                      });
                    }}
                    disabled={expandMutation.isPending}
                    data-testid="button-expand-grid"
                  >
                    Расширить сетку
                  </Button>
                )}
              </div>
              
              {/* Weight meter */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Вес</span>
                  <span className="font-mono">
                    {((character?.currentWeight || 0) / 1000).toFixed(1)} / {((character?.maxWeight || 80000) / 1000).toFixed(0)} кг
                  </span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full bg-primary transition-all"
                    style={{
                      width: `${Math.min(100, ((character?.currentWeight || 0) / (character?.maxWeight || 80000)) * 100)}%`,
                    }}
                  />
                </div>
              </div>
            </div>

            <DndContext
              sensors={sensors}
              onDragStart={(event) => setActiveId(Number(event.active.id))}
              onDragEnd={handleDragEnd}
            >
              <div className="relative">
              {/* Grid background */}
              <div
                className="inline-grid gap-0"
                style={{
                  gridTemplateColumns: `repeat(${gridWidth}, ${GRID_CELL_SIZE}px)`,
                }}
              >
                {gridCells.map((cell) => (
                  <DroppableCell key={`${cell.x}-${cell.y}`} x={cell.x} y={cell.y} />
                ))}
              </div>

              {/* Inventory items */}
              {gridItems.map((gridItem) => (
                <DraggableItem
                  key={gridItem.id}
                  gridItem={gridItem}
                  isSelected={selectedItem?.id === gridItem.id}
                  onSelect={() => setSelectedItem(gridItem)}
                />
              ))}
            </div>

            {inventoryLoading && (
              <p className="mt-4 text-sm text-muted-foreground">Загрузка инвентаря...</p>
            )}

              <DragOverlay>
                {activeId ? (
                  (() => {
                    const activeItem = gridItems.find((item) => item.id === activeId);
                    if (!activeItem) return null;
                    
                    const itemWidth = activeItem.rotated
                      ? activeItem.item.height
                      : activeItem.item.width;
                    const itemHeight = activeItem.rotated
                      ? activeItem.item.width
                      : activeItem.item.height;
                    
                    const rarityClass = RARITY_COLORS[activeItem.item.rarity as keyof typeof RARITY_COLORS] || RARITY_COLORS.common;
                    const showStack = activeItem.stackCount && activeItem.stackCount > 1;
                    
                    return (
                      <div
                        className={`cursor-grabbing border-2 ${rarityClass} p-1 shadow-lg`}
                        style={{
                          width: itemWidth * GRID_CELL_SIZE,
                          height: itemHeight * GRID_CELL_SIZE,
                        }}
                      >
                        <div className="flex h-full flex-col items-center justify-center">
                          <p className="text-center text-xs font-mono leading-tight">
                            {activeItem.item.name}
                          </p>
                          {showStack && (
                            <span className="mt-0.5 text-[10px] font-bold text-primary">
                              ×{activeItem.stackCount}
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })()
                ) : null}
              </DragOverlay>
            </DndContext>
          </Card>

          {/* Item details */}
          <Card className="p-6">
            <h2 className="mb-4 font-russo text-lg">Детали предмета</h2>
            {selectedItem ? (
              <div className="space-y-4">
                <div>
                  <p className="font-semibold">{selectedItem.item.name}</p>
                  {selectedItem.item.description && (
                    <p className="mt-1 text-sm text-muted-foreground">
                      {selectedItem.item.description}
                    </p>
                  )}
                </div>

                <div className="space-y-2 text-sm">
                  <p>
                    Размер: {selectedItem.item.width}×{selectedItem.item.height}
                  </p>
                  <p>Вес: {selectedItem.item.weight}г</p>
                  <p>
                    Позиция: ({selectedItem.gridX}, {selectedItem.gridY})
                  </p>
                  <p>Повёрнут: {selectedItem.rotated ? "Да" : "Нет"}</p>
                </div>

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleRotateItem(selectedItem)}
                    disabled={moveMutation.isPending}
                    data-testid="button-rotate-item"
                  >
                    <RotateCw className="mr-2 h-4 w-4" />
                    Повернуть
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDeleteItem(selectedItem)}
                    disabled={deleteMutation.isPending}
                    data-testid="button-delete-item"
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Удалить
                  </Button>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Выберите предмет</p>
            )}
          </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
