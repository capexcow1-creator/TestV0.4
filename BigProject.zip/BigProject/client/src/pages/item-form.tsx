import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation, useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { insertItemSchema, type Item, type InsertItem } from "@shared/schema";
import { ArrowLeft, Save } from "lucide-react";

const CATEGORIES = [
  { value: "weapon", label: "Оружие" },
  { value: "equipment", label: "Снаряжение" },
  { value: "consumable", label: "Расходник" },
];

const SUBCATEGORIES = [
  { value: "food", label: "Еда" },
  { value: "medicine", label: "Медикаменты" },
  { value: "ammo", label: "Боеприпасы" },
  { value: "material", label: "Материалы" },
  { value: "quest", label: "Квестовый" },
  { value: "currency", label: "Валюта" },
];

const RARITIES = [
  { value: "poor", label: "Плохое" },
  { value: "common", label: "Обычное" },
  { value: "uncommon", label: "Необычное" },
  { value: "rare", label: "Редкое" },
  { value: "epic", label: "Эпическое" },
  { value: "legendary", label: "Легендарное" },
  { value: "artifact", label: "Артефакт" },
  { value: "unique", label: "Уникальное" },
];

export default function ItemFormPage() {
  const { itemId } = useParams<{ itemId?: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const isEditing = !!itemId;

  // Fetch item if editing
  const { data: item, isLoading: itemLoading } = useQuery<Item>({
    queryKey: [`/api/items/${itemId}`],
    enabled: isEditing,
  });

  // Form with validation
  const form = useForm<InsertItem>({
    resolver: zodResolver(insertItemSchema),
    defaultValues: {
      name: "",
      description: "",
      category: "consumable",
      subcategory: undefined,
      rarity: "common",
      iconUrl: "",
      width: 1,
      height: 1,
      weight: 1,
      durability: 100,
      maxDurability: 100,
      capacity: 0,
    },
  });

  // Update form when item loads
  useEffect(() => {
    if (item) {
      form.reset({
        name: item.name,
        description: item.description ?? "",
        category: item.category,
        subcategory: item.subcategory ?? undefined,
        rarity: item.rarity,
        iconUrl: item.iconUrl ?? "",
        width: item.width,
        height: item.height,
        weight: item.weight,
        durability: item.durability ?? 100,
        maxDurability: item.maxDurability ?? 100,
        capacity: item.capacity ?? 0,
      });
    }
  }, [item, form]);

  // Create mutation
  const createMutation = useMutation({
    mutationFn: async (data: InsertItem) => {
      return await apiRequest("POST", "/api/items", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      toast({
        title: "Предмет создан",
        description: "Новый предмет успешно добавлен в базу данных",
      });
      setLocation("/items");
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Не удалось создать предмет",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: async (data: InsertItem) => {
      return await apiRequest("PATCH", `/api/items/${itemId}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      queryClient.invalidateQueries({ queryKey: [`/api/items/${itemId}`] });
      toast({
        title: "Предмет обновлен",
        description: "Изменения сохранены",
      });
      setLocation("/items");
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Не удалось обновить предмет",
      });
    },
  });

  const onSubmit = (data: InsertItem) => {
    if (isEditing) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  if (isEditing && itemLoading) {
    return (
      <div className="container mx-auto p-6">
        <p className="text-sm text-muted-foreground">Загрузка предмета...</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setLocation("/items")}
          data-testid="button-back"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold">
            {isEditing ? "Редактировать предмет" : "Создать предмет"}
          </h1>
          <p className="text-sm text-muted-foreground">
            {isEditing
              ? "Измените свойства предмета"
              : "Добавьте новый предмет в базу данных"}
          </p>
        </div>
      </div>

      <Card className="p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Name */}
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Название *</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Введите название предмета"
                      {...field}
                      data-testid="input-name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Description */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Описание</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Введите описание предмета"
                      {...field}
                      value={field.value ?? ""}
                      data-testid="input-description"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Category and Subcategory */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Категория *</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="select-category">
                          <SelectValue placeholder="Выберите категорию" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {CATEGORIES.map((cat) => (
                          <SelectItem key={cat.value} value={cat.value}>
                            {cat.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="subcategory"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Подкатегория</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value ?? undefined}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="select-subcategory">
                          <SelectValue placeholder="Выберите подкатегорию" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {SUBCATEGORIES.map((subcat) => (
                          <SelectItem key={subcat.value} value={subcat.value}>
                            {subcat.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Rarity */}
            <FormField
              control={form.control}
              name="rarity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Редкость *</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger data-testid="select-rarity">
                        <SelectValue placeholder="Выберите редкость" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {RARITIES.map((rarity) => (
                        <SelectItem key={rarity.value} value={rarity.value}>
                          {rarity.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Icon URL */}
            <FormField
              control={form.control}
              name="iconUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>URL иконки</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="https://example.com/icon.png"
                      {...field}
                      value={field.value ?? ""}
                      data-testid="input-icon-url"
                    />
                  </FormControl>
                  <FormDescription>
                    Ссылка на изображение предмета
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Size: Width and Height */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="width"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Ширина (клеток) *</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="1"
                        max="10"
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                        data-testid="input-width"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="height"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Высота (клеток) *</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="1"
                        max="10"
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                        data-testid="input-height"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Weight */}
            <FormField
              control={form.control}
              name="weight"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Вес (граммы) *</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min="1"
                      {...field}
                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                      data-testid="input-weight"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Durability */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="durability"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Прочность</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="0"
                        {...field}
                        value={field.value ?? 100}
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                        data-testid="input-durability"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="maxDurability"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Макс. прочность</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="0"
                        {...field}
                        value={field.value ?? 100}
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                        data-testid="input-max-durability"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Capacity */}
            <FormField
              control={form.control}
              name="capacity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Вместимость (клеток)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min="0"
                      {...field}
                      value={field.value ?? 0}
                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                      data-testid="input-capacity"
                    />
                  </FormControl>
                  <FormDescription>
                    Для контейнеров (рюкзаки, сумки)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Submit */}
            <div className="flex justify-end gap-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setLocation("/items")}
                data-testid="button-cancel"
              >
                Отмена
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending || updateMutation.isPending}
                data-testid="button-submit"
              >
                <Save className="mr-2 h-4 w-4" />
                {isEditing ? "Сохранить" : "Создать"}
              </Button>
            </div>
          </form>
        </Form>
      </Card>
    </div>
  );
}
