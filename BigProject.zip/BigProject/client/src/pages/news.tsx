import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { News } from "@shared/schema";
import { ArrowLeft, Calendar, User } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

export default function NewsPage() {
  const [, navigate] = useLocation();

  // Fetch all news
  const { data: newsList = [], isLoading } = useQuery<News[]>({
    queryKey: ["/api/news"],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-4 flex items-center justify-center">
        <div className="text-muted-foreground">Загрузка новостей...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/")}
              data-testid="button-back"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-3xl font-bold font-russo">Новости</h1>
          </div>
        </div>

        {/* News List */}
        {newsList.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              <p>Новостей пока нет</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {newsList.map((news) => (
              <Card key={news.id} data-testid={`news-card-${news.id}`} className="hover-elevate">
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-2">
                      <CardTitle className="text-2xl font-russo">
                        {news.title}
                      </CardTitle>
                      <CardDescription className="flex items-center gap-4 text-sm">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          {format(new Date(news.createdAt), "d MMMM yyyy, HH:mm", { locale: ru })}
                        </span>
                        {news.updatedAt && new Date(news.updatedAt).getTime() !== new Date(news.createdAt).getTime() && (
                          <Badge variant="outline" className="text-xs">
                            Обновлено: {format(new Date(news.updatedAt), "d MMM yyyy", { locale: ru })}
                          </Badge>
                        )}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>

                {news.imageUrl && (
                  <div className="px-6">
                    <img
                      src={news.imageUrl}
                      alt={news.title}
                      className="w-full h-64 object-cover rounded-md"
                      data-testid={`news-image-${news.id}`}
                    />
                  </div>
                )}

                <CardContent className="space-y-4">
                  <div
                    className="prose prose-sm dark:prose-invert max-w-none"
                    dangerouslySetInnerHTML={{ __html: news.content }}
                    data-testid={`news-content-${news.id}`}
                  />
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
