import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Users, Package, FileText, Shield, User, Crown, Plus, Edit, Trash2, Copy, Search, Newspaper, Hammer } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { Input } from "@/components/ui/input";

type User = {
  id: string;
  username: string;
  role: "admin" | "gm" | "player";
  createdAt: string;
};

type Item = {
  id: number;
  name: string;
  category: string;
  rarity: string;
  weight: number;
  sizeX: number;
  sizeY: number;
};

type ActionLog = {
  id: number;
  userId: string | null;
  username: string;
  actionType: string;
  description: string;
  createdAt: string;
};

const roleColors = {
  admin: "destructive",
  gm: "default",
  player: "secondary",
} as const;

const roleIcons = {
  admin: Crown,
  gm: Shield,
  player: User,
};

const roleNames = {
  admin: "Администратор",
  gm: "Гейм-Мастер",
  player: "Игрок",
};

export default function AdminPanel() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [newRole, setNewRole] = useState<"admin" | "gm" | "player">("player");
  const [roleDialogOpen, setRoleDialogOpen] = useState(false);
  
  // Items state
  const [itemSearch, setItemSearch] = useState("");
  const [itemCategoryFilter, setItemCategoryFilter] = useState<string>("all");
  const [itemRarityFilter, setItemRarityFilter] = useState<string>("all");
  const [deleteItemId, setDeleteItemId] = useState<number | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  
  // Logs state
  const [logActionFilter, setLogActionFilter] = useState<string>("all");

  // Fetch current user to verify admin access
  const { data: currentUser } = useQuery<any>({
    queryKey: ["/api/auth/me"],
  });

  // Fetch users (only if admin)
  const { data: users, isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
    enabled: currentUser?.role === "admin",
  });

  // Fetch items (only if admin)
  const { data: items, isLoading: itemsLoading } = useQuery<Item[]>({
    queryKey: ["/api/items"],
    enabled: currentUser?.role === "admin",
  });

  // Fetch logs (only if admin)
  const { data: logs, isLoading: logsLoading } = useQuery<ActionLog[]>({
    queryKey: ["/api/logs"],
    enabled: currentUser?.role === "admin",
  });

  // Update user role mutation
  const updateRoleMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: string }) => {
      return await apiRequest("PATCH", `/api/users/${userId}/role`, { role });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "Роль обновлена",
        description: "Роль пользователя успешно изменена",
      });
      setRoleDialogOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось обновить роль",
        variant: "destructive",
      });
    },
  });

  // Delete item mutation
  const deleteItemMutation = useMutation({
    mutationFn: async (itemId: number) => {
      return await apiRequest("DELETE", `/api/items/${itemId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      toast({
        title: "Предмет удалён",
        description: "Предмет успешно удалён из системы",
      });
      setDeleteDialogOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось удалить предмет",
        variant: "destructive",
      });
    },
  });

  // Duplicate item mutation
  const duplicateItemMutation = useMutation({
    mutationFn: async (itemId: number) => {
      return await apiRequest("POST", `/api/items/${itemId}/duplicate`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      toast({
        title: "Предмет дублирован",
        description: "Создана копия предмета",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось дублировать предмет",
        variant: "destructive",
      });
    },
  });

  const handleRoleChange = () => {
    if (selectedUser) {
      updateRoleMutation.mutate({ userId: selectedUser.id, role: newRole });
    }
  };

  if (!currentUser) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-muted-foreground">Загрузка...</p>
      </div>
    );
  }

  if (currentUser.role !== "admin") {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen gap-4">
        <Shield className="w-16 h-16 text-destructive" />
        <h1 className="text-2xl font-bold">Доступ запрещён</h1>
        <p className="text-muted-foreground">Эта страница доступна только администраторам</p>
        <Button onClick={() => navigate("/")} data-testid="button-back-home">
          <ArrowLeft className="mr-2 h-4 w-4" />
          На главную
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/")}
              data-testid="button-back"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold uppercase tracking-wide">Панель Администратора</h1>
              <p className="text-sm text-muted-foreground">
                {currentUser.username} • {roleNames[currentUser.role as keyof typeof roleNames]}
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="users" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 max-w-3xl" data-testid="tabs-admin">
            <TabsTrigger value="users" data-testid="tab-users">
              <Users className="mr-2 h-4 w-4" />
              Пользователи
            </TabsTrigger>
            <TabsTrigger value="items" data-testid="tab-items">
              <Package className="mr-2 h-4 w-4" />
              Предметы
            </TabsTrigger>
            <TabsTrigger value="logs" data-testid="tab-logs">
              <FileText className="mr-2 h-4 w-4" />
              Логи
            </TabsTrigger>
            <TabsTrigger value="recipes" data-testid="tab-recipes" onClick={() => navigate("/recipes/admin")}>
              <Hammer className="mr-2 h-4 w-4" />
              Рецепты
            </TabsTrigger>
            <TabsTrigger value="news" data-testid="tab-news" onClick={() => navigate("/news/admin")}>
              <Newspaper className="mr-2 h-4 w-4" />
              Новости
            </TabsTrigger>
          </TabsList>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Управление пользователями</CardTitle>
                <CardDescription>
                  Всего пользователей: {users?.length || 0}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {usersLoading ? (
                  <p className="text-muted-foreground">Загрузка...</p>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Пользователь</TableHead>
                          <TableHead>Роль</TableHead>
                          <TableHead>Дата регистрации</TableHead>
                          <TableHead className="text-right">Действия</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {users?.map((user) => {
                          const RoleIcon = roleIcons[user.role];
                          return (
                            <TableRow key={user.id} data-testid={`row-user-${user.id}`}>
                              <TableCell className="font-medium">{user.username}</TableCell>
                              <TableCell>
                                <Badge variant={roleColors[user.role]}>
                                  <RoleIcon className="mr-1 h-3 w-3" />
                                  {roleNames[user.role]}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-muted-foreground">
                                {format(new Date(user.createdAt), "dd MMM yyyy, HH:mm", { locale: ru })}
                              </TableCell>
                              <TableCell className="text-right">
                                <Dialog open={roleDialogOpen && selectedUser?.id === user.id} onOpenChange={(open) => {
                                  setRoleDialogOpen(open);
                                  if (!open) setSelectedUser(null);
                                }}>
                                  <DialogTrigger asChild>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => {
                                        setSelectedUser(user);
                                        setNewRole(user.role);
                                        setRoleDialogOpen(true);
                                      }}
                                      data-testid={`button-change-role-${user.id}`}
                                    >
                                      Изменить роль
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent data-testid="dialog-change-role">
                                    <DialogHeader>
                                      <DialogTitle>Изменить роль пользователя</DialogTitle>
                                      <DialogDescription>
                                        Пользователь: <strong>{selectedUser?.username}</strong>
                                      </DialogDescription>
                                    </DialogHeader>
                                    <div className="py-4">
                                      <label className="text-sm font-medium mb-2 block">
                                        Выберите новую роль
                                      </label>
                                      <Select value={newRole} onValueChange={(value: any) => setNewRole(value)}>
                                        <SelectTrigger data-testid="select-role">
                                          <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                          <SelectItem value="player" data-testid="option-player">
                                            <div className="flex items-center gap-2">
                                              <User className="h-4 w-4" />
                                              Игрок
                                            </div>
                                          </SelectItem>
                                          <SelectItem value="gm" data-testid="option-gm">
                                            <div className="flex items-center gap-2">
                                              <Shield className="h-4 w-4" />
                                              Гейм-Мастер
                                            </div>
                                          </SelectItem>
                                          <SelectItem value="admin" data-testid="option-admin">
                                            <div className="flex items-center gap-2">
                                              <Crown className="h-4 w-4" />
                                              Администратор
                                            </div>
                                          </SelectItem>
                                        </SelectContent>
                                      </Select>
                                    </div>
                                    <DialogFooter>
                                      <Button
                                        variant="outline"
                                        onClick={() => setRoleDialogOpen(false)}
                                        data-testid="button-cancel-role"
                                      >
                                        Отмена
                                      </Button>
                                      <Button
                                        onClick={handleRoleChange}
                                        disabled={updateRoleMutation.isPending}
                                        data-testid="button-confirm-role"
                                      >
                                        {updateRoleMutation.isPending ? "Сохранение..." : "Сохранить"}
                                      </Button>
                                    </DialogFooter>
                                  </DialogContent>
                                </Dialog>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Items Tab */}
          <TabsContent value="items" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Управление предметами</CardTitle>
                    <CardDescription>
                      Всего предметов: {items?.length || 0}
                    </CardDescription>
                  </div>
                  <Button
                    onClick={() => navigate("/items/create")}
                    data-testid="button-create-item"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Создать предмет
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Filters */}
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Поиск по названию..."
                      value={itemSearch}
                      onChange={(e) => setItemSearch(e.target.value)}
                      className="pl-9"
                      data-testid="input-search-items"
                    />
                  </div>
                  <Select value={itemCategoryFilter} onValueChange={setItemCategoryFilter}>
                    <SelectTrigger data-testid="select-category-filter">
                      <SelectValue placeholder="Все категории" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Все категории</SelectItem>
                      <SelectItem value="weapon">Оружие</SelectItem>
                      <SelectItem value="armor">Броня</SelectItem>
                      <SelectItem value="consumable">Расходник</SelectItem>
                      <SelectItem value="quest">Квестовый</SelectItem>
                      <SelectItem value="misc">Разное</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={itemRarityFilter} onValueChange={setItemRarityFilter}>
                    <SelectTrigger data-testid="select-rarity-filter">
                      <SelectValue placeholder="Все редкости" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Все редкости</SelectItem>
                      <SelectItem value="poor">Слабое</SelectItem>
                      <SelectItem value="common">Обычное</SelectItem>
                      <SelectItem value="uncommon">Необычное</SelectItem>
                      <SelectItem value="rare">Редкое</SelectItem>
                      <SelectItem value="epic">Эпическое</SelectItem>
                      <SelectItem value="legendary">Легендарное</SelectItem>
                      <SelectItem value="artifact">Артефакт</SelectItem>
                      <SelectItem value="unique">Уникальное</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {itemsLoading ? (
                  <p className="text-muted-foreground">Загрузка...</p>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Название</TableHead>
                          <TableHead>Категория</TableHead>
                          <TableHead>Редкость</TableHead>
                          <TableHead>Размер</TableHead>
                          <TableHead>Вес</TableHead>
                          <TableHead className="text-right">Действия</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {items
                          ?.filter((item) => {
                            const matchSearch = item.name.toLowerCase().includes(itemSearch.toLowerCase());
                            const matchCategory = itemCategoryFilter === "all" || item.category === itemCategoryFilter;
                            const matchRarity = itemRarityFilter === "all" || item.rarity === itemRarityFilter;
                            return matchSearch && matchCategory && matchRarity;
                          })
                          .map((item) => (
                            <TableRow key={item.id} data-testid={`row-item-${item.id}`}>
                              <TableCell className="font-mono text-xs">{item.id}</TableCell>
                              <TableCell className="font-medium">{item.name}</TableCell>
                              <TableCell>
                                <Badge variant="outline">{item.category}</Badge>
                              </TableCell>
                              <TableCell>
                                <Badge>{item.rarity}</Badge>
                              </TableCell>
                              <TableCell className="font-mono text-xs">
                                {item.sizeX}x{item.sizeY}
                              </TableCell>
                              <TableCell className="font-mono text-xs">{item.weight} кг</TableCell>
                              <TableCell className="text-right">
                                <div className="flex items-center justify-end gap-1">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => navigate(`/items/${item.id}/edit`)}
                                    data-testid={`button-edit-${item.id}`}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => duplicateItemMutation.mutate(item.id)}
                                    disabled={duplicateItemMutation.isPending}
                                    data-testid={`button-duplicate-${item.id}`}
                                  >
                                    <Copy className="h-4 w-4" />
                                  </Button>
                                  <Dialog
                                    open={deleteDialogOpen && deleteItemId === item.id}
                                    onOpenChange={(open) => {
                                      setDeleteDialogOpen(open);
                                      if (!open) setDeleteItemId(null);
                                    }}
                                  >
                                    <DialogTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => {
                                          setDeleteItemId(item.id);
                                          setDeleteDialogOpen(true);
                                        }}
                                        data-testid={`button-delete-${item.id}`}
                                      >
                                        <Trash2 className="h-4 w-4 text-destructive" />
                                      </Button>
                                    </DialogTrigger>
                                    <DialogContent data-testid="dialog-delete-item">
                                      <DialogHeader>
                                        <DialogTitle>Удалить предмет?</DialogTitle>
                                        <DialogDescription>
                                          Вы уверены, что хотите удалить <strong>{item.name}</strong>?
                                          Это действие нельзя отменить.
                                        </DialogDescription>
                                      </DialogHeader>
                                      <DialogFooter>
                                        <Button
                                          variant="outline"
                                          onClick={() => setDeleteDialogOpen(false)}
                                          data-testid="button-cancel-delete"
                                        >
                                          Отмена
                                        </Button>
                                        <Button
                                          variant="destructive"
                                          onClick={() => deleteItemMutation.mutate(item.id)}
                                          disabled={deleteItemMutation.isPending}
                                          data-testid="button-confirm-delete"
                                        >
                                          {deleteItemMutation.isPending ? "Удаление..." : "Удалить"}
                                        </Button>
                                      </DialogFooter>
                                    </DialogContent>
                                  </Dialog>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Logs Tab */}
          <TabsContent value="logs" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Логи действий</CardTitle>
                <CardDescription>
                  Всего записей: {logs?.length || 0}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Filters */}
                <div className="flex gap-4">
                  <Select value={logActionFilter} onValueChange={setLogActionFilter}>
                    <SelectTrigger className="w-[250px]" data-testid="select-action-filter">
                      <SelectValue placeholder="Все действия" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Все действия</SelectItem>
                      <SelectItem value="create_item">Создание предмета</SelectItem>
                      <SelectItem value="delete_item">Удаление предмета</SelectItem>
                      <SelectItem value="assign_role">Назначение роли</SelectItem>
                      <SelectItem value="spawn_item">Спавн предмета</SelectItem>
                      <SelectItem value="pickup_item">Подбор предмета</SelectItem>
                      <SelectItem value="chat_message">Сообщение в чате</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {logsLoading ? (
                  <p className="text-muted-foreground">Загрузка...</p>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Пользователь</TableHead>
                          <TableHead>Действие</TableHead>
                          <TableHead>Описание</TableHead>
                          <TableHead>Дата</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {logs
                          ?.filter((log) => {
                            return logActionFilter === "all" || log.actionType === logActionFilter;
                          })
                          .slice(0, 100) // Show last 100 logs
                          .map((log) => (
                            <TableRow key={log.id} data-testid={`row-log-${log.id}`}>
                              <TableCell className="font-mono text-xs">{log.id}</TableCell>
                              <TableCell className="font-medium">{log.username}</TableCell>
                              <TableCell>
                                <Badge variant="outline">{log.actionType}</Badge>
                              </TableCell>
                              <TableCell className="max-w-md truncate">{log.description}</TableCell>
                              <TableCell className="text-muted-foreground">
                                {format(new Date(log.createdAt), "dd MMM yyyy, HH:mm:ss", { locale: ru })}
                              </TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
