import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { News } from "@shared/schema";
import { ArrowLeft, Plus, Edit, Trash2, Calendar } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

const newsFormSchema = z.object({
  title: z.string().min(1, "Заголовок обязателен").max(300, "Максимум 300 символов"),
  content: z.string().min(1, "Содержание обязательно"),
  imageUrl: z.string().refine((val) => {
    if (!val || val === "") return true;
    return z.string().url().safeParse(val).success;
  }, "Неверный URL или оставьте пустым").optional(),
});

type NewsFormData = z.infer<typeof newsFormSchema>;

export default function NewsAdminPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingNews, setEditingNews] = useState<News | null>(null);
  const [deleteNewsId, setDeleteNewsId] = useState<number | null>(null);

  // Fetch all news
  const { data: newsList = [], isLoading } = useQuery<News[]>({
    queryKey: ["/api/news"],
  });

  // Form
  const form = useForm<NewsFormData>({
    resolver: zodResolver(newsFormSchema),
    defaultValues: {
      title: "",
      content: "",
      imageUrl: "",
    },
  });

  // Create mutation
  const createMutation = useMutation({
    mutationFn: async (data: NewsFormData) => {
      return await apiRequest("POST", "/api/news", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/news"] });
      toast({
        title: "Новость создана",
        description: "Новость успешно опубликована",
      });
      setIsDialogOpen(false);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: error.message || "Не удалось создать новость",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: async (data: NewsFormData & { id: number }) => {
      const { id, ...payload } = data;
      return await apiRequest("PATCH", `/api/news/${id}`, payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/news"] });
      toast({
        title: "Новость обновлена",
        description: "Изменения сохранены",
      });
      setIsDialogOpen(false);
      setEditingNews(null);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: error.message || "Не удалось обновить новость",
      });
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/news/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/news"] });
      toast({
        title: "Новость удалена",
        description: "Новость успешно удалена",
      });
      setDeleteNewsId(null);
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: error.message || "Не удалось удалить новость",
      });
    },
  });

  const handleOpenDialog = (news?: News) => {
    if (news) {
      setEditingNews(news);
      form.reset({
        title: news.title,
        content: news.content,
        imageUrl: news.imageUrl || "",
      });
    } else {
      setEditingNews(null);
      form.reset({
        title: "",
        content: "",
        imageUrl: "",
      });
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingNews(null);
    form.reset();
  };

  const onSubmit = (data: NewsFormData) => {
    if (editingNews) {
      updateMutation.mutate({ ...data, id: editingNews.id });
    } else {
      createMutation.mutate(data);
    }
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-6xl mx-auto space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/admin")}
              data-testid="button-back"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-3xl font-bold font-russo">Управление новостями</h1>
          </div>
          <Button
            onClick={() => handleOpenDialog()}
            data-testid="button-create-news"
          >
            <Plus className="mr-2 h-4 w-4" />
            Создать новость
          </Button>
        </div>

        {/* News List */}
        {isLoading ? (
          <div className="text-center text-muted-foreground p-8">
            Загрузка...
          </div>
        ) : newsList.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              <p>Новостей пока нет. Создайте первую новость!</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {newsList.map((news) => (
              <Card key={news.id} data-testid={`news-admin-card-${news.id}`}>
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-2">
                      <CardTitle className="font-russo">{news.title}</CardTitle>
                      <CardDescription className="flex items-center gap-4 text-sm">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          {format(new Date(news.createdAt), "d MMMM yyyy, HH:mm", { locale: ru })}
                        </span>
                        {news.updatedAt && new Date(news.updatedAt).getTime() !== new Date(news.createdAt).getTime() && (
                          <Badge variant="outline" className="text-xs">
                            Обновлено: {format(new Date(news.updatedAt), "d MMM yyyy", { locale: ru })}
                          </Badge>
                        )}
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleOpenDialog(news)}
                        data-testid={`button-edit-news-${news.id}`}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => setDeleteNewsId(news.id)}
                        data-testid={`button-delete-news-${news.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>

                {news.imageUrl && (
                  <div className="px-6">
                    <img
                      src={news.imageUrl}
                      alt={news.title}
                      className="w-full h-48 object-cover rounded-md"
                    />
                  </div>
                )}

                <CardContent>
                  <div
                    className="prose prose-sm dark:prose-invert max-w-none line-clamp-3"
                    dangerouslySetInnerHTML={{ __html: news.content }}
                  />
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Create/Edit Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={handleCloseDialog}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="font-russo">
                {editingNews ? "Редактировать новость" : "Создать новость"}
              </DialogTitle>
              <DialogDescription>
                {editingNews
                  ? "Внесите изменения в новость"
                  : "Создайте новую новость для игроков"}
              </DialogDescription>
            </DialogHeader>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Заголовок *</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="Заголовок новости"
                          data-testid="input-news-title"
                        />
                      </FormControl>
                      <FormDescription>
                        Максимум 300 символов
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="imageUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>URL изображения</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="https://example.com/image.jpg"
                          data-testid="input-news-image"
                        />
                      </FormControl>
                      <FormDescription>
                        Необязательно. Введите URL изображения для новости
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Содержание *</FormLabel>
                      <FormControl>
                        <Textarea
                          {...field}
                          placeholder="Текст новости (поддерживается HTML)"
                          className="min-h-[200px] font-mono text-sm"
                          data-testid="input-news-content"
                        />
                      </FormControl>
                      <FormDescription>
                        Вы можете использовать HTML для форматирования текста
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleCloseDialog}
                    data-testid="button-cancel"
                  >
                    Отмена
                  </Button>
                  <Button
                    type="submit"
                    disabled={createMutation.isPending || updateMutation.isPending}
                    data-testid="button-submit-news"
                  >
                    {editingNews ? "Сохранить" : "Создать"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation */}
        <AlertDialog open={deleteNewsId !== null} onOpenChange={() => setDeleteNewsId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Удалить новость?</AlertDialogTitle>
              <AlertDialogDescription>
                Это действие нельзя отменить. Новость будет удалена навсегда.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel data-testid="button-cancel-delete">
                Отмена
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={() => deleteNewsId && deleteMutation.mutate(deleteNewsId)}
                data-testid="button-confirm-delete"
              >
                Удалить
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}
