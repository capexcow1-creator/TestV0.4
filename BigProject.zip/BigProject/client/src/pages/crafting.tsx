import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Hammer, Package, CheckCircle2, XCircle } from "lucide-react";
import type { Recipe, Character, Item, InventoryItem } from "@shared/schema";

type RecipeWithItems = Recipe & {
  resultItem?: Item;
  materials?: Array<{ itemId: number; quantity: number; item?: Item }>;
};

export default function CraftingPage() {
  const { toast } = useToast();
  const [selectedCharacterId, setSelectedCharacterId] = useState<number | null>(null);

  // Get current user
  const { data: currentUser } = useQuery<{ id: string; username: string; role: string }>({
    queryKey: ["/api/auth/me"],
  });

  // Fetch user characters
  const { data: characters, isLoading: charactersLoading } = useQuery<Character[]>({
    queryKey: ["/api/characters"],
    enabled: !!currentUser,
  });

  // Fetch recipes
  const { data: recipes, isLoading: recipesLoading } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes"],
    enabled: !!currentUser,
  });

  // Fetch all items for material details
  const { data: allItems } = useQuery<Item[]>({
    queryKey: ["/api/items"],
    enabled: !!currentUser,
  });

  // Fetch inventory for selected character
  const { data: inventory } = useQuery<Array<InventoryItem & { item: Item }>>({
    queryKey: ["/api/inventory", selectedCharacterId],
    enabled: !!selectedCharacterId,
  });

  // Craft mutation
  const craftMutation = useMutation({
    mutationFn: async (recipeId: number) => {
      return await apiRequest("POST", "/api/craft", {
        recipeId,
        characterId: selectedCharacterId,
      });
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory", selectedCharacterId] });
      toast({
        title: "Крафт успешен!",
        description: data.message,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка крафта",
        description: error.message || "Не удалось скрафтить предмет",
        variant: "destructive",
      });
    },
  });

  // Auto-select first character
  if (characters && characters.length > 0 && !selectedCharacterId) {
    setSelectedCharacterId(characters[0].id);
  }

  const selectedCharacter = characters?.find((c: Character) => c.id === selectedCharacterId);

  // Enrich recipes with item details
  const enrichedRecipes: RecipeWithItems[] = recipes?.map((recipe) => {
    const resultItem = allItems?.find((item) => item.id === recipe.resultItemId);
    const materials = recipe.materials as Array<{ itemId: number; quantity: number }>;
    const enrichedMaterials = materials?.map((mat) => ({
      ...mat,
      item: allItems?.find((item) => item.id === mat.itemId),
    }));

    return {
      ...recipe,
      resultItem,
      materials: enrichedMaterials,
    };
  }) || [];

  // Check if character can craft recipe
  const canCraft = (recipe: RecipeWithItems) => {
    if (!selectedCharacter || !inventory) return false;

    // Check class requirement
    if (recipe.requiredClass && selectedCharacter.characterClass !== recipe.requiredClass) {
      return false;
    }

    // Check materials
    const inventoryCounts = new Map<number, number>();
    if (inventory) {
      inventory.forEach((invItem) => {
        const current = inventoryCounts.get(invItem.itemId) || 0;
        inventoryCounts.set(invItem.itemId, current + invItem.stackCount);
      });
    }

    for (const material of recipe.materials || []) {
      const available = inventoryCounts.get(material.itemId) || 0;
      if (available < material.quantity) {
        return false;
      }
    }

    return true;
  };

  if (charactersLoading || recipesLoading) {
    return <div className="p-8 text-center">Загрузка...</div>;
  }

  if (!characters || characters.length === 0) {
    return (
      <div className="p-8 text-center">
        <p className="text-muted-foreground">У вас нет персонажей для крафта</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-7xl">
      <div className="mb-6">
        <h1 className="text-3xl font-heading font-bold mb-2">Крафтинг</h1>
        <p className="text-muted-foreground">Создавайте предметы из материалов</p>
      </div>

      {/* Character Selection */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="font-heading">Выберите персонажа</CardTitle>
          <CardDescription>Персонаж для крафтинга</CardDescription>
        </CardHeader>
        <CardContent>
          <Select
            value={selectedCharacterId?.toString() || ""}
            onValueChange={(val) => setSelectedCharacterId(parseInt(val))}
          >
            <SelectTrigger data-testid="select-character">
              <SelectValue placeholder="Выберите персонажа" />
            </SelectTrigger>
            <SelectContent>
              {characters.map((char) => (
                <SelectItem key={char.id} value={char.id.toString()}>
                  {char.name} ({char.characterClass})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {selectedCharacter && (
            <div className="mt-4 text-sm text-muted-foreground">
              <p>
                <strong>Класс:</strong> {selectedCharacter.characterClass}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recipes Grid */}
      <div className="grid gap-4">
        {enrichedRecipes.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              Нет доступных рецептов
            </CardContent>
          </Card>
        ) : (
          enrichedRecipes.map((recipe) => {
            const craftable = canCraft(recipe);
            const classMatch = !recipe.requiredClass || selectedCharacter?.characterClass === recipe.requiredClass;

            return (
              <Card
                key={recipe.id}
                className={craftable ? "border-green-500/50" : ""}
                data-testid={`recipe-card-${recipe.id}`}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="font-heading flex items-center gap-2">
                        <Hammer className="h-5 w-5" />
                        {recipe.name}
                      </CardTitle>
                      <CardDescription className="mt-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span>Результат:</span>
                          <Badge variant="outline">
                            {recipe.resultItem?.name || "Unknown"} x{recipe.resultQuantity}
                          </Badge>
                          {recipe.requiredClass && (
                            <Badge variant={classMatch ? "default" : "destructive"}>
                              Требуется: {recipe.requiredClass}
                            </Badge>
                          )}
                        </div>
                      </CardDescription>
                    </div>
                    <Button
                      onClick={() => craftMutation.mutate(recipe.id)}
                      disabled={!craftable || craftMutation.isPending}
                      data-testid={`button-craft-${recipe.id}`}
                    >
                      {craftMutation.isPending ? "Крафт..." : "Скрафтить"}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm">Требуемые материалы:</h4>
                    <div className="grid gap-2">
                      {recipe.materials?.map((material, idx) => {
                        const inventoryCounts = new Map<number, number>();
                        if (inventory) {
                          inventory.forEach((invItem) => {
                            const current = inventoryCounts.get(invItem.itemId) || 0;
                            inventoryCounts.set(invItem.itemId, current + invItem.stackCount);
                          });
                        }

                        const available = inventoryCounts.get(material.itemId) || 0;
                        const sufficient = available >= material.quantity;

                        return (
                          <div
                            key={idx}
                            className="flex items-center justify-between p-2 border rounded-md"
                            data-testid={`material-${recipe.id}-${material.itemId}`}
                          >
                            <div className="flex items-center gap-2">
                              <Package className="h-4 w-4 text-muted-foreground" />
                              <span>{material.item?.name || `Item #${material.itemId}`}</span>
                              <span className="text-sm text-muted-foreground">
                                x{material.quantity}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-mono" data-testid={`available-${recipe.id}-${material.itemId}`}>
                                {available}/{material.quantity}
                              </span>
                              {sufficient ? (
                                <CheckCircle2 className="h-4 w-4 text-green-500" />
                              ) : (
                                <XCircle className="h-4 w-4 text-red-500" />
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}
