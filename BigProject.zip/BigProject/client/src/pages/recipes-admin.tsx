import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Plus, Edit, Trash2, Hammer, X } from "lucide-react";
import { Link } from "wouter";
import type { Recipe, Item } from "@shared/schema";

type RecipeWithDetails = Recipe & {
  resultItem?: Item;
};

type MaterialInput = {
  itemId: number;
  quantity: number;
};

export default function RecipesAdminPage() {
  const { toast } = useToast();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingRecipe, setEditingRecipe] = useState<Recipe | null>(null);

  // Form states
  const [name, setName] = useState("");
  const [resultItemId, setResultItemId] = useState("");
  const [resultQuantity, setResultQuantity] = useState("1");
  const [requiredClass, setRequiredClass] = useState<string>("");
  const [materials, setMaterials] = useState<MaterialInput[]>([]);

  // Fetch recipes
  const { data: recipes, isLoading: recipesLoading } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes"],
  });

  // Fetch all items
  const { data: allItems, isLoading: itemsLoading } = useQuery<Item[]>({
    queryKey: ["/api/items"],
  });

  // Enrich recipes with item details
  const enrichedRecipes: RecipeWithDetails[] = recipes?.map((recipe) => ({
    ...recipe,
    resultItem: allItems?.find((item) => item.id === recipe.resultItemId),
  })) || [];

  // Create recipe
  const createRecipeMutation = useMutation({
    mutationFn: async (data: {
      name: string;
      resultItemId: number;
      resultQuantity: number;
      requiredClass: string | null;
      materials: MaterialInput[];
    }) => {
      return await apiRequest("POST", "/api/admin/recipes", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      setShowCreateDialog(false);
      resetForm();
      toast({
        title: "Рецепт создан",
        description: "Новый рецепт успешно создан",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать рецепт",
        variant: "destructive",
      });
    },
  });

  // Update recipe
  const updateRecipeMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      return await apiRequest("PATCH", `/api/admin/recipes/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      setShowEditDialog(false);
      setEditingRecipe(null);
      resetForm();
      toast({
        title: "Рецепт обновлён",
        description: "Рецепт успешно обновлён",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить рецепт",
        variant: "destructive",
      });
    },
  });

  // Delete recipe
  const deleteRecipeMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/admin/recipes/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      toast({
        title: "Рецепт удалён",
        description: "Рецепт успешно удалён",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось удалить рецепт",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setName("");
    setResultItemId("");
    setResultQuantity("1");
    setRequiredClass("");
    setMaterials([]);
  };

  const openEditDialog = (recipe: Recipe) => {
    setEditingRecipe(recipe);
    setName(recipe.name);
    setResultItemId(recipe.resultItemId.toString());
    setResultQuantity(recipe.resultQuantity.toString());
    setRequiredClass(recipe.requiredClass || "");
    setMaterials((recipe.materials as MaterialInput[]) || []);
    setShowEditDialog(true);
  };

  const handleCreate = () => {
    if (!name || !resultItemId || materials.length === 0) {
      toast({
        title: "Ошибка",
        description: "Заполните все обязательные поля",
        variant: "destructive",
      });
      return;
    }

    // Validate materials
    const invalidMaterial = materials.find((m) => m.itemId === 0 || m.quantity < 1);
    if (invalidMaterial) {
      toast({
        title: "Ошибка",
        description: "Выберите предмет и укажите количество для всех материалов",
        variant: "destructive",
      });
      return;
    }

    createRecipeMutation.mutate({
      name,
      resultItemId: parseInt(resultItemId),
      resultQuantity: parseInt(resultQuantity) || 1,
      requiredClass: requiredClass === "none" ? null : requiredClass || null,
      materials,
    });
  };

  const handleUpdate = () => {
    if (!editingRecipe || !name || !resultItemId || materials.length === 0) {
      toast({
        title: "Ошибка",
        description: "Заполните все обязательные поля",
        variant: "destructive",
      });
      return;
    }

    updateRecipeMutation.mutate({
      id: editingRecipe.id,
      data: {
        name,
        resultItemId: parseInt(resultItemId),
        resultQuantity: parseInt(resultQuantity) || 1,
        requiredClass: requiredClass || null,
        materials,
      },
    });
  };

  const addMaterial = () => {
    setMaterials([...materials, { itemId: 0, quantity: 1 }]);
  };

  const removeMaterial = (index: number) => {
    setMaterials(materials.filter((_, i) => i !== index));
  };

  const updateMaterial = (index: number, field: "itemId" | "quantity", value: number) => {
    const updated = [...materials];
    updated[index][field] = value;
    setMaterials(updated);
  };

  if (recipesLoading || itemsLoading) {
    return <div className="p-8 text-center">Загрузка...</div>;
  }

  return (
    <div className="container mx-auto p-4 max-w-7xl">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Link href="/admin">
              <Button variant="ghost" size="icon" data-testid="button-back">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-3xl font-heading font-bold">Управление рецептами</h1>
          </div>
          <p className="text-muted-foreground">Создавайте и редактируйте рецепты крафтинга</p>
        </div>
        <Button onClick={() => setShowCreateDialog(true)} data-testid="button-create">
          <Plus className="h-4 w-4 mr-1" />
          Создать рецепт
        </Button>
      </div>

      {/* Recipes List */}
      <div className="grid gap-4">
        {enrichedRecipes.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              Нет рецептов
            </CardContent>
          </Card>
        ) : (
          enrichedRecipes.map((recipe) => (
            <Card key={recipe.id} data-testid={`recipe-card-${recipe.id}`}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="font-heading flex items-center gap-2">
                      <Hammer className="h-5 w-5" />
                      {recipe.name}
                    </CardTitle>
                    <CardDescription className="mt-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span>Результат:</span>
                        <Badge variant="outline">
                          {recipe.resultItem?.name || "Unknown"} x{recipe.resultQuantity}
                        </Badge>
                        {recipe.requiredClass && (
                          <Badge variant="secondary">
                            Класс: {recipe.requiredClass}
                          </Badge>
                        )}
                      </div>
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => openEditDialog(recipe)}
                      data-testid={`button-edit-${recipe.id}`}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => deleteRecipeMutation.mutate(recipe.id)}
                      disabled={deleteRecipeMutation.isPending}
                      data-testid={`button-delete-${recipe.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div>
                  <h4 className="font-semibold text-sm mb-2">Материалы:</h4>
                  <div className="flex flex-wrap gap-2">
                    {(recipe.materials as MaterialInput[])?.map((mat, idx) => {
                      const item = allItems?.find((i) => i.id === mat.itemId);
                      return (
                        <Badge key={idx} variant="outline">
                          {item?.name || `Item #${mat.itemId}`} x{mat.quantity}
                        </Badge>
                      );
                    })}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Create Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="dialog-create">
          <DialogHeader>
            <DialogTitle className="font-heading">Создать рецепт</DialogTitle>
            <DialogDescription>Добавьте новый рецепт крафтинга</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Название *</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Крафт меча"
                data-testid="input-name"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="result-item">Результат *</Label>
                <Select value={resultItemId} onValueChange={setResultItemId}>
                  <SelectTrigger id="result-item" data-testid="select-result-item">
                    <SelectValue placeholder="Выберите предмет" />
                  </SelectTrigger>
                  <SelectContent>
                    {allItems?.map((item) => (
                      <SelectItem key={item.id} value={item.id.toString()}>
                        {item.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="result-quantity">Количество</Label>
                <Input
                  id="result-quantity"
                  type="number"
                  min="1"
                  value={resultQuantity}
                  onChange={(e) => setResultQuantity(e.target.value)}
                  data-testid="input-result-quantity"
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="required-class">Требуемый класс (опционально)</Label>
              <Select value={requiredClass || "none"} onValueChange={(val) => setRequiredClass(val === "none" ? "" : val)}>
                <SelectTrigger id="required-class" data-testid="select-required-class">
                  <SelectValue placeholder="Любой класс" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Любой класс</SelectItem>
                  <SelectItem value="loner">loner</SelectItem>
                  <SelectItem value="mercenary">mercenary</SelectItem>
                  <SelectItem value="technician">technician</SelectItem>
                  <SelectItem value="medic">medic</SelectItem>
                  <SelectItem value="stalker">stalker</SelectItem>
                  <SelectItem value="bandit">bandit</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <div className="flex items-center justify-between">
                <Label>Материалы *</Label>
                <Button size="sm" variant="outline" onClick={addMaterial} data-testid="button-add-material">
                  <Plus className="h-4 w-4 mr-1" />
                  Добавить
                </Button>
              </div>
              <div className="grid gap-2">
                {materials.map((mat, idx) => (
                  <div key={idx} className="flex items-center gap-2" data-testid={`material-${idx}`}>
                    <Select
                      value={mat.itemId === 0 ? "" : mat.itemId.toString()}
                      onValueChange={(val) => updateMaterial(idx, "itemId", parseInt(val) || 0)}
                    >
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Выберите предмет" />
                      </SelectTrigger>
                      <SelectContent>
                        {allItems?.map((item) => (
                          <SelectItem key={item.id} value={item.id.toString()}>
                            {item.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input
                      type="number"
                      min="1"
                      value={mat.quantity}
                      onChange={(e) => updateMaterial(idx, "quantity", parseInt(e.target.value) || 1)}
                      className="w-24"
                      placeholder="Кол-во"
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeMaterial(idx)}
                      data-testid={`button-remove-material-${idx}`}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                {materials.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center p-4 border rounded-md">
                    Добавьте материалы для крафта
                  </p>
                )}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
              Отмена
            </Button>
            <Button
              onClick={handleCreate}
              disabled={createRecipeMutation.isPending}
              data-testid="button-confirm-create"
            >
              Создать
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="dialog-edit">
          <DialogHeader>
            <DialogTitle className="font-heading">Редактировать рецепт</DialogTitle>
            <DialogDescription>
              {editingRecipe && `Редактирование: ${editingRecipe.name}`}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-name">Название *</Label>
              <Input
                id="edit-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                data-testid="input-edit-name"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-result-item">Результат *</Label>
                <Select value={resultItemId} onValueChange={setResultItemId}>
                  <SelectTrigger id="edit-result-item" data-testid="select-edit-result-item">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {allItems?.map((item) => (
                      <SelectItem key={item.id} value={item.id.toString()}>
                        {item.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-result-quantity">Количество</Label>
                <Input
                  id="edit-result-quantity"
                  type="number"
                  min="1"
                  value={resultQuantity}
                  onChange={(e) => setResultQuantity(e.target.value)}
                  data-testid="input-edit-result-quantity"
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-required-class">Требуемый класс</Label>
              <Select value={requiredClass || "none"} onValueChange={(val) => setRequiredClass(val === "none" ? "" : val)}>
                <SelectTrigger id="edit-required-class" data-testid="select-edit-required-class">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Любой класс</SelectItem>
                  <SelectItem value="loner">loner</SelectItem>
                  <SelectItem value="mercenary">mercenary</SelectItem>
                  <SelectItem value="technician">technician</SelectItem>
                  <SelectItem value="medic">medic</SelectItem>
                  <SelectItem value="stalker">stalker</SelectItem>
                  <SelectItem value="bandit">bandit</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <div className="flex items-center justify-between">
                <Label>Материалы *</Label>
                <Button size="sm" variant="outline" onClick={addMaterial} data-testid="button-add-material-edit">
                  <Plus className="h-4 w-4 mr-1" />
                  Добавить
                </Button>
              </div>
              <div className="grid gap-2">
                {materials.map((mat, idx) => (
                  <div key={idx} className="flex items-center gap-2" data-testid={`edit-material-${idx}`}>
                    <Select
                      value={mat.itemId === 0 ? "" : mat.itemId.toString()}
                      onValueChange={(val) => updateMaterial(idx, "itemId", parseInt(val) || 0)}
                    >
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Выберите предмет" />
                      </SelectTrigger>
                      <SelectContent>
                        {allItems?.map((item) => (
                          <SelectItem key={item.id} value={item.id.toString()}>
                            {item.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input
                      type="number"
                      min="1"
                      value={mat.quantity}
                      onChange={(e) => updateMaterial(idx, "quantity", parseInt(e.target.value) || 1)}
                      className="w-24"
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeMaterial(idx)}
                      data-testid={`button-remove-material-edit-${idx}`}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>
              Отмена
            </Button>
            <Button
              onClick={handleUpdate}
              disabled={updateRecipeMutation.isPending}
              data-testid="button-confirm-edit"
            >
              Сохранить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
