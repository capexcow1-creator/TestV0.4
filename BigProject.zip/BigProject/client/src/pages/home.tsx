import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { LogOut, Package, Shield, Newspaper, Wrench, Users, ShoppingBag, Hammer, Map, MessageSquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function HomePage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: currentUser, isLoading } = useQuery<{
    id: string;
    username: string;
    role: "admin" | "gm" | "player";
  }>({
    queryKey: ["/api/auth/me"],
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/auth/logout");
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      localStorage.removeItem("selectedCharacterId");
      toast({
        title: "Выход выполнен",
        description: "До новых встреч",
      });
      setLocation("/login");
    },
  });

  useEffect(() => {
    if (!isLoading && !currentUser) {
      setLocation("/login");
    }
  }, [isLoading, currentUser, setLocation]);

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <p className="text-muted-foreground">Загрузка...</p>
      </div>
    );
  }

  if (!currentUser) {
    return null;
  }

  const handleWorldClick = (worldName: string) => {
    if (worldName === "Сфера") {
      setLocation("/world/sphere");
    } else {
      toast({
        title: "В разработке",
        description: `Стол "${worldName}" будет доступен позже`,
      });
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="flex items-center justify-between border-b p-4">
        <div className="flex items-center gap-2">
          <Avatar>
            <AvatarFallback className="bg-primary text-primary-foreground font-mono">
              {currentUser.username.substring(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="font-medium" data-testid="text-username">
              {currentUser.username}
            </p>
            <p className="text-xs text-muted-foreground capitalize">
              {currentUser.role}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/news")}
            data-testid="button-news"
          >
            <Newspaper className="h-5 w-5" />
          </Button>
          {(currentUser.role === "admin" || currentUser.role === "gm") && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/gm-panel")}
              data-testid="button-gm-panel"
            >
              <Wrench className="h-5 w-5" />
            </Button>
          )}
          {currentUser.role === "admin" && (
            <>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLocation("/admin")}
                data-testid="button-admin"
              >
                <Shield className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLocation("/items")}
                data-testid="button-items"
              >
                <Package className="h-5 w-5" />
              </Button>
            </>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
            data-testid="button-logout"
          >
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex flex-1 flex-col items-center justify-center gap-12 p-6">
        <div className="text-center">
          <h1 className="mb-2 font-heading text-4xl uppercase tracking-widest md:text-6xl">
            Выберите стол
          </h1>
          <p className="text-muted-foreground">
            Выберите игровой стол для начала игры
          </p>
        </div>

        {/* World Selection */}
        <div className="grid w-full max-w-4xl gap-8 md:grid-cols-2">
          {/* Сфера - Active */}
          <Card className="border-primary hover-elevate">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 flex h-48 w-48 items-center justify-center rounded-full border-4 border-primary bg-card text-primary">
                <div className="font-heading text-6xl">D20</div>
              </div>
              <CardTitle className="font-heading text-2xl uppercase">
                Сфера
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-center text-sm text-muted-foreground">
                Основной игровой стол. Все системы активны.
              </p>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full font-heading uppercase tracking-wider"
                onClick={() => handleWorldClick("Сфера")}
                data-testid="button-world-sphere"
              >
                Войти в мир
              </Button>
            </CardFooter>
          </Card>

          {/* Наарн - In Development */}
          <Card className="border-muted opacity-60">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 flex h-48 w-48 items-center justify-center rounded-full border-4 border-muted bg-card text-muted">
                <div className="font-heading text-6xl">D20</div>
              </div>
              <CardTitle className="font-heading text-2xl uppercase">
                Наарн
              </CardTitle>
              <CardDescription>В разработке</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-center text-sm text-muted-foreground">
                Скоро откроется.
              </p>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full font-heading uppercase tracking-wider"
                variant="secondary"
                disabled
                data-testid="button-world-naarn"
              >
                Скоро
              </Button>
            </CardFooter>
          </Card>
        </div>

        {/* Game Features */}
        <div className="w-full max-w-6xl">
          <h2 className="mb-6 text-center font-heading text-2xl uppercase tracking-wider">
            Игровые функции
          </h2>
          <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-5">
            <Card className="hover-elevate active-elevate-2 cursor-pointer" onClick={() => setLocation("/characters")}>
              <CardHeader className="text-center">
                <Users className="mx-auto h-8 w-8 mb-2 text-primary" />
                <CardTitle className="text-lg font-heading">Персонажи</CardTitle>
              </CardHeader>
            </Card>

            <Card className="hover-elevate active-elevate-2 cursor-pointer" onClick={() => setLocation("/traders")}>
              <CardHeader className="text-center">
                <ShoppingBag className="mx-auto h-8 w-8 mb-2 text-primary" />
                <CardTitle className="text-lg font-heading">Торговцы</CardTitle>
              </CardHeader>
            </Card>

            <Card className="hover-elevate active-elevate-2 cursor-pointer" onClick={() => setLocation("/crafting")} data-testid="button-crafting">
              <CardHeader className="text-center">
                <Hammer className="mx-auto h-8 w-8 mb-2 text-primary" />
                <CardTitle className="text-lg font-heading">Крафтинг</CardTitle>
              </CardHeader>
            </Card>

            <Card className="hover-elevate active-elevate-2 cursor-pointer" onClick={() => setLocation("/lobby")}>
              <CardHeader className="text-center">
                <Map className="mx-auto h-8 w-8 mb-2 text-primary" />
                <CardTitle className="text-lg font-heading">Лобби</CardTitle>
              </CardHeader>
            </Card>

            <Card className="hover-elevate active-elevate-2 cursor-pointer" onClick={() => setLocation("/chat")}>
              <CardHeader className="text-center">
                <MessageSquare className="mx-auto h-8 w-8 mb-2 text-primary" />
                <CardTitle className="text-lg font-heading">Чат</CardTitle>
              </CardHeader>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
