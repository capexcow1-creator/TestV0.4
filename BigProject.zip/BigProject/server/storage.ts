import { db } from "./db";
import { eq, and, desc, asc, gte, lte, like, sql } from "drizzle-orm";
import * as schema from "@shared/schema";
import type {
  User,
  InsertUser,
  Character,
  InsertCharacter,
  Item,
  InsertItem,
  InventoryItem,
  InsertInventoryItem,
  LobbyItem,
  InsertLobbyItem,
  Trader,
  InsertTrader,
  TraderItem,
  InsertTraderItem,
  Recipe,
  InsertRecipe,
  AuctionListing,
  InsertAuctionListing,
  AuctionWarehouse,
  AuctionWarehouseItem,
  GmRequest,
  InsertGmRequest,
  ChatMessage,
  InsertChatMessage,
  News,
  InsertNews,
  ActionLog,
  InsertActionLog,
  ActiveEffect,
  InsertActiveEffect,
  WorldMap,
  GamePassword,
} from "@shared/schema";

// Storage interface definition
export interface IStorage {
  // ========== USERS ==========
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserRole(id: string, role: "admin" | "gm" | "player"): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;

  // ========== CHARACTERS ==========
  getCharacter(id: number): Promise<Character | undefined>;
  getCharactersByUserId(userId: string): Promise<Character[]>;
  createCharacter(character: InsertCharacter): Promise<Character>;
  updateCharacter(id: number, data: Partial<Character>): Promise<Character | undefined>;
  deleteCharacter(id: number): Promise<boolean>;
  updateCharacterStats(id: number, stats: Partial<Character>): Promise<Character | undefined>;

  // ========== ITEMS ==========
  getItem(id: number): Promise<Item | undefined>;
  getAllItems(): Promise<Item[]>;
  searchItems(query: string): Promise<Item[]>;
  createItem(item: InsertItem): Promise<Item>;
  updateItem(id: number, data: Partial<Item>): Promise<Item | undefined>;
  deleteItem(id: number): Promise<boolean>;
  duplicateItem(id: number): Promise<Item | undefined>;

  // ========== INVENTORY ==========
  getInventoryByCharacterId(characterId: number): Promise<InventoryItem[]>;
  getInventoryWithItems(characterId: number): Promise<Array<InventoryItem & { item: Item }>>;
  getInventoryItem(id: number): Promise<InventoryItem | undefined>;
  addInventoryItem(item: InsertInventoryItem): Promise<InventoryItem>;
  updateInventoryItem(id: number, data: Partial<InventoryItem>): Promise<InventoryItem | undefined>;
  deleteInventoryItem(id: number): Promise<boolean>;
  moveInventoryItem(
    id: number,
    gridX: number,
    gridY: number,
    rotated: boolean
  ): Promise<InventoryItem | undefined>;
  equipItem(id: number, slot: string): Promise<InventoryItem | undefined>;
  unequipItem(id: number): Promise<InventoryItem | undefined>;

  // ========== LOBBY ==========
  getLobbyItems(worldName: string): Promise<LobbyItem[]>;
  addLobbyItem(item: InsertLobbyItem): Promise<LobbyItem>;
  lockLobbyItem(id: number, userId: string): Promise<boolean>;
  unlockLobbyItem(id: number): Promise<boolean>;
  deleteLobbyItem(id: number): Promise<boolean>;
  clearExpiredLocks(): Promise<void>;

  // ========== TRADERS ==========
  getTrader(id: number): Promise<Trader | undefined>;
  getAllTraders(): Promise<Trader[]>;
  createTrader(trader: InsertTrader): Promise<Trader>;
  updateTrader(id: number, data: Partial<Trader>): Promise<Trader | undefined>;
  deleteTrader(id: number): Promise<boolean>;
  toggleTraderStatus(id: number): Promise<Trader | undefined>;

  // ========== TRADER ITEMS ==========
  getTraderItems(traderId: number): Promise<TraderItem[]>;
  getTraderItemsWithDetails(traderId: number): Promise<Array<TraderItem & { item: Item }>>;
  addTraderItem(item: InsertTraderItem): Promise<TraderItem>;
  updateTraderItem(id: number, data: Partial<TraderItem>): Promise<TraderItem | undefined>;
  deleteTraderItem(id: number): Promise<boolean>;

  // ========== RECIPES ==========
  getRecipe(id: number): Promise<Recipe | undefined>;
  getAllRecipes(): Promise<Recipe[]>;
  createRecipe(recipe: InsertRecipe): Promise<Recipe>;
  updateRecipe(id: number, data: Partial<Recipe>): Promise<Recipe | undefined>;
  deleteRecipe(id: number): Promise<boolean>;

  // ========== AUCTION ==========
  getAuctionListing(id: number): Promise<AuctionListing | undefined>;
  getAllAuctionListings(): Promise<AuctionListing[]>;
  searchAuctionListings(
    query: string,
    sortBy?: string,
    order?: "asc" | "desc"
  ): Promise<AuctionListing[]>;
  createAuctionListing(listing: InsertAuctionListing): Promise<AuctionListing>;
  deleteAuctionListing(id: number): Promise<boolean>;
  getAuctionWarehouse(userId: string): Promise<AuctionWarehouse | undefined>;
  createAuctionWarehouse(userId: string): Promise<AuctionWarehouse>;
  expandAuctionWarehouse(userId: string): Promise<AuctionWarehouse | undefined>;
  getAuctionWarehouseItems(warehouseId: number): Promise<AuctionWarehouseItem[]>;
  addAuctionWarehouseItem(
    warehouseId: number,
    itemId: number,
    gridX: number,
    gridY: number,
    stackCount: number
  ): Promise<AuctionWarehouseItem>;
  deleteAuctionWarehouseItem(id: number): Promise<boolean>;

  // ========== GM REQUESTS ==========
  getGmRequest(id: number): Promise<GmRequest | undefined>;
  getGmRequestsByGmId(gmId: string): Promise<GmRequest[]>;
  getPendingGmRequests(): Promise<GmRequest[]>;
  createGmRequest(request: InsertGmRequest): Promise<GmRequest>;
  approveGmRequest(
    id: number,
    reviewedBy: string,
    approvedQuantity: number,
    comment?: string
  ): Promise<GmRequest | undefined>;
  rejectGmRequest(
    id: number,
    reviewedBy: string,
    comment?: string
  ): Promise<GmRequest | undefined>;

  // ========== CHAT ==========
  getChatMessages(worldName: string, limit?: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  deleteChatMessage(id: number): Promise<boolean>;

  // ========== NEWS ==========
  getNewsArticle(id: number): Promise<News | undefined>;
  getAllNews(): Promise<News[]>;
  createNews(news: InsertNews): Promise<News>;
  updateNews(id: number, data: Partial<News>): Promise<News | undefined>;
  deleteNews(id: number): Promise<boolean>;

  // ========== ACTION LOGS ==========
  getActionLogs(
    filter?: {
      userId?: string;
      actionType?: string;
      startDate?: Date;
      endDate?: Date;
    }
  ): Promise<ActionLog[]>;
  createActionLog(log: InsertActionLog): Promise<ActionLog>;

  // ========== WORLD MAP ==========
  getWorldMap(worldName: string): Promise<WorldMap | undefined>;
  updateWorldMap(
    worldName: string,
    canvasData: any,
    layers: any,
    markers: any,
    updatedBy: string
  ): Promise<WorldMap>;

  // ========== GAME PASSWORD ==========
  getCurrentGamePassword(): Promise<GamePassword | undefined>;
  setGamePassword(password: string, setBy: string): Promise<GamePassword>;

  // ========== ACTIVE EFFECTS ==========
  getActiveEffect(id: number): Promise<ActiveEffect | undefined>;
  getActiveEffects(characterId: number): Promise<ActiveEffect[]>;
  createActiveEffect(effect: InsertActiveEffect): Promise<ActiveEffect>;
  deleteActiveEffect(id: number): Promise<boolean>;
  cleanupExpiredEffects(): Promise<void>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // ========== USERS ==========
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(schema.users)
      .where(eq(schema.users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(schema.users).values(user).returning();
    return newUser;
  }

  async updateUserRole(
    id: string,
    role: "admin" | "gm" | "player"
  ): Promise<User | undefined> {
    const [updated] = await db
      .update(schema.users)
      .set({ role, updatedAt: new Date() })
      .where(eq(schema.users.id, id))
      .returning();
    return updated;
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(schema.users).orderBy(asc(schema.users.username));
  }

  // ========== CHARACTERS ==========
  async getCharacter(id: number): Promise<Character | undefined> {
    const [character] = await db
      .select()
      .from(schema.characters)
      .where(eq(schema.characters.id, id));
    return character;
  }

  async getCharactersByUserId(userId: string): Promise<Character[]> {
    return db
      .select()
      .from(schema.characters)
      .where(eq(schema.characters.userId, userId))
      .orderBy(desc(schema.characters.createdAt));
  }

  async createCharacter(character: InsertCharacter): Promise<Character> {
    const [newCharacter] = await db
      .insert(schema.characters)
      .values(character)
      .returning();
    return newCharacter;
  }

  async updateCharacter(
    id: number,
    data: Partial<Character>
  ): Promise<Character | undefined> {
    const [updated] = await db
      .update(schema.characters)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(schema.characters.id, id))
      .returning();
    return updated;
  }

  async deleteCharacter(id: number): Promise<boolean> {
    const result = await db
      .delete(schema.characters)
      .where(eq(schema.characters.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async updateCharacterStats(
    id: number,
    stats: Partial<Character>
  ): Promise<Character | undefined> {
    return this.updateCharacter(id, stats);
  }

  // ========== ITEMS ==========
  async getItem(id: number): Promise<Item | undefined> {
    const [item] = await db.select().from(schema.items).where(eq(schema.items.id, id));
    return item;
  }

  async getAllItems(): Promise<Item[]> {
    return db.select().from(schema.items).orderBy(asc(schema.items.name));
  }

  async searchItems(query: string): Promise<Item[]> {
    return db
      .select()
      .from(schema.items)
      .where(like(schema.items.name, `%${query}%`))
      .orderBy(asc(schema.items.name));
  }

  async createItem(item: InsertItem): Promise<Item> {
    const [newItem] = await db.insert(schema.items).values(item).returning();
    return newItem;
  }

  async updateItem(id: number, data: Partial<Item>): Promise<Item | undefined> {
    const [updated] = await db
      .update(schema.items)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(schema.items.id, id))
      .returning();
    return updated;
  }

  async deleteItem(id: number): Promise<boolean> {
    const result = await db.delete(schema.items).where(eq(schema.items.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async duplicateItem(id: number): Promise<Item | undefined> {
    const original = await this.getItem(id);
    if (!original) return undefined;

    const { id: _, createdAt, updatedAt, ...itemData } = original;
    const [duplicated] = await db
      .insert(schema.items)
      .values({
        ...itemData,
        name: `${itemData.name} (Копия)`,
      })
      .returning();
    return duplicated;
  }

  // ========== INVENTORY ==========
  async getInventoryByCharacterId(characterId: number): Promise<InventoryItem[]> {
    return db
      .select()
      .from(schema.inventoryItems)
      .where(eq(schema.inventoryItems.characterId, characterId));
  }

  async getInventoryWithItems(characterId: number): Promise<Array<InventoryItem & { item: Item }>> {
    const results = await db
      .select()
      .from(schema.inventoryItems)
      .leftJoin(schema.items, eq(schema.inventoryItems.itemId, schema.items.id))
      .where(eq(schema.inventoryItems.characterId, characterId));

    return results
      .filter((row) => row.items !== null)
      .map((row) => ({
        ...row.inventory_items,
        item: row.items!,
      }));
  }

  async getInventoryItem(id: number): Promise<InventoryItem | undefined> {
    const [item] = await db
      .select()
      .from(schema.inventoryItems)
      .where(eq(schema.inventoryItems.id, id));
    return item;
  }

  async addInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    const [newItem] = await db.insert(schema.inventoryItems).values(item).returning();
    return newItem;
  }

  async updateInventoryItem(
    id: number,
    data: Partial<InventoryItem>
  ): Promise<InventoryItem | undefined> {
    const [updated] = await db
      .update(schema.inventoryItems)
      .set(data)
      .where(eq(schema.inventoryItems.id, id))
      .returning();
    return updated;
  }

  async deleteInventoryItem(id: number): Promise<boolean> {
    const result = await db
      .delete(schema.inventoryItems)
      .where(eq(schema.inventoryItems.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async moveInventoryItem(
    id: number,
    gridX: number,
    gridY: number,
    rotated: boolean
  ): Promise<InventoryItem | undefined> {
    return this.updateInventoryItem(id, { gridX, gridY, rotated });
  }

  async equipItem(id: number, slot: string): Promise<InventoryItem | undefined> {
    // Get inventory item with joined item data
    const inventoryItem = await this.getInventoryItem(id);
    if (!inventoryItem) return undefined;

    const item = await this.getItem(inventoryItem.itemId);
    if (!item) return undefined;

    // Check if item can be equipped in this slot
    if (item.equipmentSlot !== slot) {
      throw new Error(`Предмет не может быть экипирован в слот ${slot}`);
    }

    // Unequip any existing item in this slot
    const equipped = await this.getInventoryByCharacterId(inventoryItem.characterId);
    const existingInSlot = equipped.find(i => i.equippedSlot === slot);
    if (existingInSlot) {
      await this.updateInventoryItem(existingInSlot.id, { equippedSlot: null });
    }

    // Equip the item (set position to -1, -1 when equipped)
    return this.updateInventoryItem(id, {
      equippedSlot: slot as any,
      gridX: -1,
      gridY: -1,
    });
  }

  async unequipItem(id: number): Promise<InventoryItem | undefined> {
    // Simply remove the equipped slot (item returns to inventory grid position)
    return this.updateInventoryItem(id, { equippedSlot: null as any });
  }

  // ========== LOBBY ==========
  async getLobbyItems(worldName: string): Promise<LobbyItem[]> {
    return db
      .select()
      .from(schema.lobbyItems)
      .where(eq(schema.lobbyItems.worldName, worldName));
  }

  async addLobbyItem(item: InsertLobbyItem): Promise<LobbyItem> {
    const [newItem] = await db.insert(schema.lobbyItems).values(item).returning();
    return newItem;
  }

  async lockLobbyItem(id: number, userId: string): Promise<boolean> {
    const result = await db
      .update(schema.lobbyItems)
      .set({ lockedBy: userId, lockedAt: new Date() })
      .where(eq(schema.lobbyItems.id, id))
      .returning();
    return result.length > 0;
  }

  async unlockLobbyItem(id: number): Promise<boolean> {
    const result = await db
      .update(schema.lobbyItems)
      .set({ lockedBy: null, lockedAt: null })
      .where(eq(schema.lobbyItems.id, id))
      .returning();
    return result.length > 0;
  }

  async deleteLobbyItem(id: number): Promise<boolean> {
    const result = await db
      .delete(schema.lobbyItems)
      .where(eq(schema.lobbyItems.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async clearExpiredLocks(): Promise<void> {
    const expirationTime = new Date(Date.now() - 800); // 0.8 seconds ago
    await db
      .update(schema.lobbyItems)
      .set({ lockedBy: null, lockedAt: null })
      .where(lte(schema.lobbyItems.lockedAt as any, expirationTime));
  }

  // ========== TRADERS ==========
  async getTrader(id: number): Promise<Trader | undefined> {
    const [trader] = await db
      .select()
      .from(schema.traders)
      .where(eq(schema.traders.id, id));
    return trader;
  }

  async getAllTraders(): Promise<Trader[]> {
    return db.select().from(schema.traders).orderBy(asc(schema.traders.name));
  }

  async createTrader(trader: InsertTrader): Promise<Trader> {
    const [newTrader] = await db.insert(schema.traders).values(trader).returning();
    return newTrader;
  }

  async updateTrader(id: number, data: Partial<Trader>): Promise<Trader | undefined> {
    const [updated] = await db
      .update(schema.traders)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(schema.traders.id, id))
      .returning();
    return updated;
  }

  async deleteTrader(id: number): Promise<boolean> {
    const result = await db.delete(schema.traders).where(eq(schema.traders.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async toggleTraderStatus(id: number): Promise<Trader | undefined> {
    const trader = await this.getTrader(id);
    if (!trader) return undefined;
    return this.updateTrader(id, { isOpen: !trader.isOpen });
  }

  // ========== TRADER ITEMS ==========
  async getTraderItems(traderId: number): Promise<TraderItem[]> {
    return db
      .select()
      .from(schema.traderItems)
      .where(eq(schema.traderItems.traderId, traderId));
  }

  async getTraderItemsWithDetails(
    traderId: number
  ): Promise<Array<TraderItem & { item: Item }>> {
    const traderItems = await db
      .select()
      .from(schema.traderItems)
      .where(eq(schema.traderItems.traderId, traderId));

    const itemsWithDetails = await Promise.all(
      traderItems.map(async (traderItem) => {
        const [item] = await db
          .select()
          .from(schema.items)
          .where(eq(schema.items.id, traderItem.itemId));
        return { ...traderItem, item };
      })
    );

    return itemsWithDetails;
  }

  async addTraderItem(item: InsertTraderItem): Promise<TraderItem> {
    const [newItem] = await db.insert(schema.traderItems).values(item).returning();
    return newItem;
  }

  async updateTraderItem(
    id: number,
    data: Partial<TraderItem>
  ): Promise<TraderItem | undefined> {
    const [updated] = await db
      .update(schema.traderItems)
      .set(data)
      .where(eq(schema.traderItems.id, id))
      .returning();
    return updated;
  }

  async deleteTraderItem(id: number): Promise<boolean> {
    const result = await db
      .delete(schema.traderItems)
      .where(eq(schema.traderItems.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // ========== RECIPES ==========
  async getRecipe(id: number): Promise<Recipe | undefined> {
    const [recipe] = await db
      .select()
      .from(schema.recipes)
      .where(eq(schema.recipes.id, id));
    return recipe;
  }

  async getAllRecipes(): Promise<Recipe[]> {
    return db.select().from(schema.recipes).orderBy(asc(schema.recipes.name));
  }

  async createRecipe(recipe: InsertRecipe): Promise<Recipe> {
    const [newRecipe] = await db.insert(schema.recipes).values(recipe).returning();
    return newRecipe;
  }

  async updateRecipe(id: number, data: Partial<Recipe>): Promise<Recipe | undefined> {
    const [updated] = await db
      .update(schema.recipes)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(schema.recipes.id, id))
      .returning();
    return updated;
  }

  async deleteRecipe(id: number): Promise<boolean> {
    const result = await db.delete(schema.recipes).where(eq(schema.recipes.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // ========== AUCTION ==========
  async getAuctionListing(id: number): Promise<AuctionListing | undefined> {
    const [listing] = await db
      .select()
      .from(schema.auctionListings)
      .where(eq(schema.auctionListings.id, id));
    return listing;
  }

  async getAllAuctionListings(): Promise<AuctionListing[]> {
    return db
      .select()
      .from(schema.auctionListings)
      .where(gte(schema.auctionListings.expiresAt, new Date()))
      .orderBy(desc(schema.auctionListings.createdAt));
  }

  async searchAuctionListings(
    query: string,
    sortBy: string = "createdAt",
    order: "asc" | "desc" = "desc"
  ): Promise<AuctionListing[]> {
    const listings = await db
      .select()
      .from(schema.auctionListings)
      .where(gte(schema.auctionListings.expiresAt, new Date()));

    // Client-side filtering and sorting
    let filtered = listings;
    if (query) {
      filtered = listings.filter((listing) => {
        // Will need to join with items table for full search
        return true;
      });
    }

    return filtered;
  }

  async createAuctionListing(listing: InsertAuctionListing): Promise<AuctionListing> {
    const [newListing] = await db
      .insert(schema.auctionListings)
      .values(listing)
      .returning();
    return newListing;
  }

  async deleteAuctionListing(id: number): Promise<boolean> {
    const result = await db
      .delete(schema.auctionListings)
      .where(eq(schema.auctionListings.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async getAuctionWarehouse(userId: string): Promise<AuctionWarehouse | undefined> {
    const [warehouse] = await db
      .select()
      .from(schema.auctionWarehouses)
      .where(eq(schema.auctionWarehouses.userId, userId));
    return warehouse;
  }

  async createAuctionWarehouse(userId: string): Promise<AuctionWarehouse> {
    const [warehouse] = await db
      .insert(schema.auctionWarehouses)
      .values({ userId })
      .returning();
    return warehouse;
  }

  async expandAuctionWarehouse(
    userId: string
  ): Promise<AuctionWarehouse | undefined> {
    const warehouse = await this.getAuctionWarehouse(userId);
    if (!warehouse) return undefined;

    const [expanded] = await db
      .update(schema.auctionWarehouses)
      .set({ capacity: warehouse.capacity + 4 })
      .where(eq(schema.auctionWarehouses.userId, userId))
      .returning();
    return expanded;
  }

  async getAuctionWarehouseItems(
    warehouseId: number
  ): Promise<AuctionWarehouseItem[]> {
    return db
      .select()
      .from(schema.auctionWarehouseItems)
      .where(eq(schema.auctionWarehouseItems.warehouseId, warehouseId));
  }

  async addAuctionWarehouseItem(
    warehouseId: number,
    itemId: number,
    gridX: number,
    gridY: number,
    stackCount: number
  ): Promise<AuctionWarehouseItem> {
    const [item] = await db
      .insert(schema.auctionWarehouseItems)
      .values({ warehouseId, itemId, gridX, gridY, stackCount })
      .returning();
    return item;
  }

  async deleteAuctionWarehouseItem(id: number): Promise<boolean> {
    const result = await db
      .delete(schema.auctionWarehouseItems)
      .where(eq(schema.auctionWarehouseItems.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // ========== GM REQUESTS ==========
  async getGmRequest(id: number): Promise<GmRequest | undefined> {
    const [request] = await db
      .select()
      .from(schema.gmRequests)
      .where(eq(schema.gmRequests.id, id));
    return request;
  }

  async getGmRequestsByGmId(gmId: string): Promise<GmRequest[]> {
    return db
      .select()
      .from(schema.gmRequests)
      .where(eq(schema.gmRequests.gmId, gmId))
      .orderBy(desc(schema.gmRequests.createdAt));
  }

  async getPendingGmRequests(): Promise<GmRequest[]> {
    return db
      .select()
      .from(schema.gmRequests)
      .where(eq(schema.gmRequests.status, "pending"))
      .orderBy(desc(schema.gmRequests.createdAt));
  }

  async createGmRequest(request: InsertGmRequest): Promise<GmRequest> {
    const [newRequest] = await db
      .insert(schema.gmRequests)
      .values(request)
      .returning();
    return newRequest;
  }

  async approveGmRequest(
    id: number,
    reviewedBy: string,
    approvedQuantity: number,
    comment?: string
  ): Promise<GmRequest | undefined> {
    const [approved] = await db
      .update(schema.gmRequests)
      .set({
        status: "approved",
        approvedQuantity,
        adminComment: comment,
        reviewedBy,
        reviewedAt: new Date(),
      })
      .where(eq(schema.gmRequests.id, id))
      .returning();
    return approved;
  }

  async rejectGmRequest(
    id: number,
    reviewedBy: string,
    comment?: string
  ): Promise<GmRequest | undefined> {
    const [rejected] = await db
      .update(schema.gmRequests)
      .set({
        status: "rejected",
        adminComment: comment,
        reviewedBy,
        reviewedAt: new Date(),
      })
      .where(eq(schema.gmRequests.id, id))
      .returning();
    return rejected;
  }

  // ========== CHAT ==========
  async getChatMessages(worldName: string, limit: number = 300): Promise<ChatMessage[]> {
    return db
      .select()
      .from(schema.chatMessages)
      .where(eq(schema.chatMessages.worldName, worldName))
      .orderBy(desc(schema.chatMessages.createdAt))
      .limit(limit);
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [newMessage] = await db
      .insert(schema.chatMessages)
      .values(message)
      .returning();

    // Keep only last 300 messages
    const worldName = message.worldName || "sphere";
    const allMessages = await db
      .select()
      .from(schema.chatMessages)
      .where(eq(schema.chatMessages.worldName, worldName))
      .orderBy(desc(schema.chatMessages.createdAt));

    if (allMessages.length > 300) {
      const toDelete = allMessages.slice(300);
      for (const msg of toDelete) {
        await db.delete(schema.chatMessages).where(eq(schema.chatMessages.id, msg.id));
      }
    }

    return newMessage;
  }

  async deleteChatMessage(id: number): Promise<boolean> {
    const result = await db
      .delete(schema.chatMessages)
      .where(eq(schema.chatMessages.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // ========== NEWS ==========
  async getNewsArticle(id: number): Promise<News | undefined> {
    const [news] = await db.select().from(schema.news).where(eq(schema.news.id, id));
    return news;
  }

  async getAllNews(): Promise<News[]> {
    return db.select().from(schema.news).orderBy(desc(schema.news.createdAt));
  }

  async createNews(news: InsertNews): Promise<News> {
    const [newNews] = await db.insert(schema.news).values(news).returning();
    return newNews;
  }

  async updateNews(id: number, data: Partial<News>): Promise<News | undefined> {
    const [updated] = await db
      .update(schema.news)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(schema.news.id, id))
      .returning();
    return updated;
  }

  async deleteNews(id: number): Promise<boolean> {
    const result = await db.delete(schema.news).where(eq(schema.news.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // ========== ACTION LOGS ==========
  async getActionLogs(filter?: {
    userId?: string;
    actionType?: string;
    startDate?: Date;
    endDate?: Date;
  }): Promise<ActionLog[]> {
    let query = db.select().from(schema.actionLogs);

    if (filter?.userId) {
      query = query.where(eq(schema.actionLogs.userId as any, filter.userId)) as any;
    }

    // Additional filters can be added here

    const logs = await query;
    return logs.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createActionLog(log: InsertActionLog): Promise<ActionLog> {
    const [newLog] = await db.insert(schema.actionLogs).values(log).returning();
    return newLog;
  }

  // ========== WORLD MAP ==========
  async getWorldMap(worldName: string): Promise<WorldMap | undefined> {
    const [map] = await db
      .select()
      .from(schema.worldMaps)
      .where(eq(schema.worldMaps.worldName, worldName));
    return map;
  }

  async updateWorldMap(
    worldName: string,
    canvasData: any,
    layers: any,
    markers: any,
    updatedBy: string
  ): Promise<WorldMap> {
    const existing = await this.getWorldMap(worldName);

    if (existing) {
      const [updated] = await db
        .update(schema.worldMaps)
        .set({ canvasData, layers, markers, updatedBy, updatedAt: new Date() })
        .where(eq(schema.worldMaps.worldName, worldName))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(schema.worldMaps)
        .values({ worldName, canvasData, layers, markers, updatedBy })
        .returning();
      return created;
    }
  }

  // ========== GAME PASSWORD ==========
  async getCurrentGamePassword(): Promise<GamePassword | undefined> {
    const [password] = await db
      .select()
      .from(schema.gamePassword)
      .orderBy(desc(schema.gamePassword.createdAt))
      .limit(1);
    return password;
  }

  async setGamePassword(password: string, setBy: string): Promise<GamePassword> {
    const [newPassword] = await db
      .insert(schema.gamePassword)
      .values({ password, setBy })
      .returning();
    return newPassword;
  }

  // ========== ACTIVE EFFECTS ==========
  async getActiveEffect(id: number): Promise<ActiveEffect | undefined> {
    const [effect] = await db
      .select()
      .from(schema.activeEffects)
      .where(eq(schema.activeEffects.id, id))
      .limit(1);
    return effect;
  }

  async getActiveEffects(characterId: number): Promise<ActiveEffect[]> {
    return db
      .select()
      .from(schema.activeEffects)
      .where(eq(schema.activeEffects.characterId, characterId));
  }

  async createActiveEffect(effect: InsertActiveEffect): Promise<ActiveEffect> {
    const [newEffect] = await db
      .insert(schema.activeEffects)
      .values(effect)
      .returning();
    return newEffect;
  }

  async deleteActiveEffect(id: number): Promise<boolean> {
    const result = await db
      .delete(schema.activeEffects)
      .where(eq(schema.activeEffects.id, id));
    return result.rowCount !== null && result.rowCount > 0;
  }

  async cleanupExpiredEffects(): Promise<void> {
    await db
      .delete(schema.activeEffects)
      .where(sql`expires_at < NOW()`);
  }
}

export const storage = new DatabaseStorage();
