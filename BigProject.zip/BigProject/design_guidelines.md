# Design Guidelines: DnD Interactive Table - Post-Apocalyptic USSR/STALKER Theme

## Core Principles
- **Atmospheric Immersion**: Soviet brutalist + post-apocalyptic aesthetic in all UI elements
- **Mobile-First**: Optimized for 8.7" tablets and smartphones with touch interactions (min 44x44px targets)
- **Information Density**: Clear visual hierarchy for complex systems (inventory, crafting, trading)
- **Real-time Clarity**: Immediate visual feedback for live updates (lobby, chat, auctions)

## Typography

### Fonts
- **Interface**: Roboto Condensed (space-efficient, technical)
- **Headings**: Russo One (Soviet-style impact, uppercase)
- **Data/Numbers**: JetBrains Mono (stats, inventory, dice)

### Scale & Treatment
```
Hero/Page Titles: 2.5rem (40px) - Russo One, bold, uppercase
Section Headers: 1.75rem (28px) - Russo One, uppercase
Card Titles: 1.25rem (20px) - Roboto Condensed, semi-bold
Body: 1rem (16px) - Roboto Condensed, regular
Labels: 0.875rem (14px) - Roboto Condensed, light
Stats: 0.75rem (12px) - JetBrains Mono
```
- Uppercase all headings, letter-spacing: 0.05em
- Line-height: 1.5 (body), 1.2 (headings)
- High contrast for dark theme readability

## Layout & Spacing

### Tailwind Spacing Units
```
Micro: p-2, m-2 (inventory cells, buttons)
Component: p-4, gap-4 (cards, forms, lists)
Section: p-8, py-12 (major sections)
Page margins: px-6 (mobile), px-12 (desktop)
Section gaps: mb-16, gap-24
```

### Grid Patterns
- **Inventory**: 10x10 grid-template-columns (tetris system)
- **Cards**: grid-cols-1 → md:grid-cols-2 → lg:grid-cols-3
- **Admin**: 2-column desktop (sidebar + content), single mobile
- **Lobby**: Fixed 10x10 with explicit cell sizing

### Containers
```
Full-width: Chat, Lobby, Map (w-full)
Gameplay: max-w-7xl
Forms: max-w-md (login/registration)
Admin: max-w-screen-2xl
```

## Color System & Visual Treatment

### Atmospheric Elements
- Grain texture overlays (post-apocalyptic)
- Optional scan-line effects
- Distressed container edges
- Industrial dividers/borders
- Corner vignettes on large panels
- Rarity borders: Epic/Legendary glow effects

## Components

### Navigation
**Main Menu (World Selection)**
- 3D D20 dice (50vw each desktop, stacked mobile)
- "ВОЙТИ В МИР" buttons centered beneath
- User avatar (top-right), exit (top-left)
- Full-width bottom info panel

**In-Game**
- Vertical sidebar (left), icon + text
- Collapsible mobile (hamburger)
- Active state: bold + indicator bar
- Lock icons for password-protected sections

### Cards
**Character Cards**
- Portrait avatar, class badge (top-right)
- Name below, action buttons at bottom
- Hover: elevation + border accent

**Item Cards**
- Square cells (1x1 to 2x2), centered icon
- Rarity borders, Epic/Legendary glow
- Stack count badge (top-right)
- Hover: tooltip, click for details

**News Cards**
- 16:9 featured image, full-width mobile, 2-col tablet
- Headline, author, timestamp, rich text

### Forms & Inputs
**Standard Inputs**
- Full-width, h-12, labels above
- Inline validation below
- Password strength indicator
- Clear error states

**Character Creation**
- Multi-step wizard with progress
- Class: grid of large clickable cards
- Point allocation: +/- buttons with remaining count
- Confirmation modal before submit

**Item Creation (Admin)**
- Collapsible sections, image upload + preview
- Dropdowns: category/rarity, numerical inputs: size/weight/stats
- Dynamic characteristic modifier fields
- Fixed save/cancel buttons (mobile bottom)

### Buttons
```css
Primary: min h-12, bold, full-width mobile
Secondary: outlined, same height
Icon: h-10 w-10, square, centered
Danger: distinct treatment (delete/sell)
All: clear active/pressed states, subtle transitions (100-150ms)
```

### Interactive Elements
**Tabs**: Horizontal bar, active underline + bold, scrollable mobile
**Modals**: Centered with backdrop, close (top-right), scrollable content, mobile full-screen for complex forms
**Toggles**: Admin controls (trader open/close)

### Data Displays
**Inventory System**
- Grid with visible boundaries
- Equipment slots: left sidebar, labeled
- Main inventory: center (4x2 expandable)
- Details panel: expandable accordion
- Weight: progress bar at bottom
- Visual equipment warning beneath character name

**Stats (Health Tab)**
- Grouped collapsible categories
- Stat name + value rows
- Modified stats: distinct visual
- Progress bars: HP/Water/Food
- Hover tooltips for details

**Lobby Grid**
- 10x10 visible grid lines
- Items placed by size
- Blocked items: 0.8s dimmed overlay
- Empty: subtle grid pattern
- New items: brief flash (300ms)

**Trading Interface**
- Split: merchant (left) vs player (right)
- Center panel: item details when selected
- Currency exchange slot with required amount
- Confirm active when valid currency placed

**Auction/Marketplace**
- Card grid with top filter bar
- Search: real-time results
- Sort dropdown (price ascending/descending)
- Lot modal: seller info, expiration timer
- Warehouse: separate grid view

### Notifications & Feedback
**Toasts**: Top-right, auto-dismiss 5s with progress, icons, stackable, mobile full-width top
**Loading**: Skeleton loaders (cards/lists), spinners (full-page), progress bars (uploads), inline button spinners
**Real-time**: Online dots, typing indicators, unread badges, new item pulse, update flash

## Special Components

### 3D Dice (Main Page)
- Large D20 models, subtle rotation animation
- Hover: glow + scale increase
- Names beneath (Russo One)

### Inventory Tetris
- Drag-and-drop with ghost preview
- Rotation button (touch-friendly)
- Snap-to-grid, invalid: red overlay
- Equipment slots: labeled with icons
- Backpack: nested grid view

### Chat
- Fixed height container, scroll
- Messages: sender, timestamp, content
- Dice rolls: centered, larger text, distinct visual
- Input bar fixed bottom
- Emoji picker button
- Mobile: keyboard-aware positioning

### Map Canvas
- Toolbar: brush/shapes/text/eraser icons
- Color picker popover, brush size slider
- Layer panel (collapsible sidebar)
- Zoom controls (buttons + pinch)
- Save button (top-right, prominent)
- Mobile: tool palette at bottom

### Admin Panel
- Persistent left sidebar (desktop)
- Breadcrumb navigation
- Sortable tables, pagination
- Batch actions with checkboxes
- Log viewer: filterable with search
- Backup: prominent download button with timestamp

## Responsive Breakpoints

**Mobile (Portrait/Landscape)**
- Single column, bottom nav for critical actions
- Collapsible sections, full-screen modals
- Swipe gestures, horizontal scrollable tabs
- Optimized inventory grid for touch

**Tablet (1340x800)**
- 2-column layouts, side panels for filters/details
- Persistent sidebar (landscape)
- Hover states disabled, tap interactions

**Desktop (Admin Only)**
- Multi-column, expanded tables
- Always-visible sidebar
- Keyboard shortcuts, hover tooltips

## Images & Media

**Hero (Main Page)**: 3D D20 dice (50vw desktop), subtle lighting + rotation
**Avatars**: User-uploaded portraits, fallback silhouette
**Item Icons**: 108x108px base, rarity borders, Epic/Legendary glow
**News**: 16:9 aspect ratio, full card width
**Map**: Admin-uploaded background or blank canvas

## Animations (Minimal)
```
Page transitions: fade 200ms
Card hover: elevation 150ms
Button press: scale 100ms
Real-time updates: flash 300ms
Lobby item: pop-in 200ms
Dice idle: rotation 5s loop
```

## Sound Design (Toggle in Settings)
- Click: mechanical typewriter
- Item pickup: metallic clink
- Chat: subtle beep
- Purchase: cash register
- Craft success: industrial clunk

## Accessibility
- Consistent tab order, clear focus indicators
- ARIA labels for icon buttons
- Form validation with clear errors
- Contrast ratios maintained
- Min 44x44px touch targets
- Screen reader support for critical flows

---

**Design Reference**: Escape from Tarkov inventory + STALKER atmosphere + Soviet brutalism + Linear typography + Notion interactions