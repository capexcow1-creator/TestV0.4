import { sql } from "drizzle-orm";
import { relations } from "drizzle-orm";
import {
  pgTable,
  varchar,
  text,
  integer,
  timestamp,
  boolean,
  jsonb,
  index,
  serial,
  pgEnum,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ========== ENUMS ==========

export const roleEnum = pgEnum("role", ["admin", "gm", "player"]);

export const characterClassEnum = pgEnum("character_class", [
  "loner",
  "mercenary",
  "technician",
  "medic",
  "stalker",
  "bandit",
]);

export const itemCategoryEnum = pgEnum("item_category", [
  "weapon",
  "equipment",
  "consumable",
]);

export const itemSubcategoryEnum = pgEnum("item_subcategory", [
  "food",
  "medicine",
  "ammo",
  "material",
  "quest",
  "currency",
]);

export const rarityEnum = pgEnum("rarity", [
  "poor",
  "common",
  "uncommon",
  "rare",
  "epic",
  "legendary",
  "artifact",
  "unique",
]);

export const qualityEnum = pgEnum("quality", [
  "damaged", // Повреждённый
  "normal", // Обычный
  "good", // Отличный
  "perfect", // Идеальный
]);

export const consumableTypeEnum = pgEnum("consumable_type", [
  "healing", // Лечение
  "hunger", // Голод
  "thirst", // Жажда
  "radiation", // Радиация
  "temperature", // Температура
  "stamina", // Выносливость
  "buff", // Временный бонус
]);

export const equipmentSlotEnum = pgEnum("equipment_slot", [
  "top",
  "bottom",
  "head",
  "footwear",
  "headphones", // Только наушники из аксессуаров
  "clothing",
  "armor",
  "vest",
  "belt",
  "strap",
  "hand_left",
  "hand_right",
]);

export const currencyTypeEnum = pgEnum("currency_type", [
  "gold",
  "silver",
  "cores",
  "soviet_medal_1",
  "soviet_medal_2",
  "soviet_medal_3",
  "reich_mark_1",
  "reich_mark_2",
  "reich_mark_3",
]);

export const requestStatusEnum = pgEnum("request_status", [
  "pending",
  "approved",
  "rejected",
]);

export const actionTypeEnum = pgEnum("action_type", [
  "create_item",
  "delete_item",
  "spawn_item",
  "spawn_lobby_item",
  "pickup_item",
  "assign_role",
  "remove_role",
  "create_recipe",
  "update_recipe",
  "delete_recipe",
  "craft",
  "update_trader",
  "update_character",
  "create_news",
  "update_news",
  "delete_news",
  "chat_message",
  "other",
]);

// ========== TABLES ==========

// Session storage for auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)]
);

// Users with roles and authentication
export const users = pgTable(
  "users",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    username: varchar("username", { length: 50 }).notNull().unique(),
    password: text("password").notNull(),
    role: roleEnum("role").default("player").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [index("idx_users_role").on(table.role)]
);

// Characters with 27 characteristics in 5 categories
export const characters = pgTable(
  "characters",
  {
    id: serial("id").primaryKey(),
    userId: varchar("user_id")
      .references(() => users.id, { onDelete: "cascade" })
      .notNull(),
    name: varchar("name", { length: 100 }).notNull(),
    characterClass: characterClassEnum("character_class").notNull(),
    avatarUrl: text("avatar_url"),

    // Characteristics (27 total, 6 categories)
    // Тело (5)
    shooting: integer("shooting").default(0).notNull(), // Стрельба
    meleeCombat: integer("melee_combat").default(0).notNull(), // Рукопашный бой
    throwing: integer("throwing").default(0).notNull(), // Метание
    climbing: integer("climbing").default(0).notNull(), // Лазание
    athletics: integer("athletics").default(0).notNull(), // Атлетика

    // Интеллект (5)
    repair: integer("repair").default(0).notNull(), // Ремонт
    hacking: integer("hacking").default(0).notNull(), // Взлом (цифровой)
    medicine: integer("medicine").default(0).notNull(), // Медицина
    analysis: integer("analysis").default(0).notNull(), // Анализ
    electronics: integer("electronics").default(0).notNull(), // Электроника

    // Восприятие (5)
    attentiveness: integer("attentiveness").default(0).notNull(), // Внимательность
    tracking: integer("tracking").default(0).notNull(), // Слежка
    survival: integer("survival").default(0).notNull(), // Выживание
    appraisal: integer("appraisal").default(0).notNull(), // Оценка
    statusMonitoring: integer("status_monitoring").default(0).notNull(), // Слежение за состоянием

    // Харизма (5)
    persuasion: integer("persuasion").default(0).notNull(), // Убеждение
    deception: integer("deception").default(0).notNull(), // Обман
    intimidation: integer("intimidation").default(0).notNull(), // Запугивание
    provocation: integer("provocation").default(0).notNull(), // Провокация
    respect: integer("respect").default(0).notNull(), // Уважение

    // Реакция (5)
    stealth: integer("stealth").default(0).notNull(), // Скрытность
    lockpicking: integer("lockpicking").default(0).notNull(), // Вскрытие
    evasion: integer("evasion").default(0).notNull(), // Уклонение
    pickpocket: integer("pickpocket").default(0).notNull(), // Карманник
    balance: integer("balance").default(0).notNull(), // Баланс

    // Сопротивление (2)
    physicalResistance: integer("physical_resistance").default(0).notNull(), // Физическое сопротивление
    mentalResistance: integer("mental_resistance").default(0).notNull(), // Ментальное сопротивление

    // Resources
    currentHp: integer("current_hp").default(100).notNull(),
    maxHp: integer("max_hp").default(100).notNull(),
    currentWater: integer("current_water").default(100).notNull(),
    maxWater: integer("max_water").default(100).notNull(),
    currentFood: integer("current_food").default(100).notNull(),
    maxFood: integer("max_food").default(100).notNull(),

    // Inventory
    inventoryGridWidth: integer("inventory_grid_width").default(4).notNull(),
    inventoryGridHeight: integer("inventory_grid_height").default(2).notNull(),
    currentWeight: integer("current_weight").default(0).notNull(), // in grams
    maxWeight: integer("max_weight").default(80000).notNull(), // 80kg in grams

    // Currencies
    gold: integer("gold").default(0).notNull(),
    silver: integer("silver").default(0).notNull(),
    cores: integer("cores").default(0).notNull(),
    sovietMedal1: integer("soviet_medal_1").default(0).notNull(),
    sovietMedal2: integer("soviet_medal_2").default(0).notNull(),
    sovietMedal3: integer("soviet_medal_3").default(0).notNull(),
    reichMark1: integer("reich_mark_1").default(0).notNull(),
    reichMark2: integer("reich_mark_2").default(0).notNull(),
    reichMark3: integer("reich_mark_3").default(0).notNull(),

    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_characters_user_id").on(table.userId),
    index("idx_characters_class").on(table.characterClass),
  ]
);

// Items master table with all properties
export const items = pgTable(
  "items",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 200 }).notNull(),
    description: text("description"),
    category: itemCategoryEnum("category").notNull(),
    subcategory: itemSubcategoryEnum("subcategory"),
    rarity: rarityEnum("rarity").default("common").notNull(),
    quality: qualityEnum("quality").default("normal").notNull(), // Качество предмета
    iconUrl: text("icon_url"),

    // Size and weight
    width: integer("width").default(1).notNull(), // 1-2
    height: integer("height").default(1).notNull(), // 1-2
    weight: integer("weight").default(1).notNull(), // in grams
    
    // Durability (ломается при 0, чинится через крафт)
    durability: integer("durability").default(100),
    maxDurability: integer("max_durability").default(100),

    // Capacity (for containers like backpacks)
    capacity: integer("capacity").default(0), // number of cells

    // Equipment slot
    equipmentSlot: equipmentSlotEnum("equipment_slot"),

    // Requirements
    requiredLevel: integer("required_level").default(1),
    requiredStats: jsonb("required_stats"), // { shooting: 10, repair: 5, ... }
    classRestrictions: jsonb("class_restrictions"), // ["loner", "medic"] или null для всех

    // Consumable effects
    consumableType: consumableTypeEnum("consumable_type"), // Тип расходника
    hpRestore: integer("hp_restore").default(0),
    waterRestore: integer("water_restore").default(0),
    foodRestore: integer("food_restore").default(0),
    radiationRestore: integer("radiation_restore").default(0), // Для радиации
    temperatureRestore: integer("temperature_restore").default(0), // Для температуры
    effectDuration: integer("effect_duration").default(0), // Длительность бафа в секундах

    // Stackable (патроны=120, валюта=50, остальное=1)
    stackable: boolean("stackable").default(false).notNull(),
    maxStack: integer("max_stack").default(1).notNull(),

    // Stat modifiers (JSON для модификации всех 27 характеристик)
    statModifiers: jsonb("stat_modifiers"), // { shooting: 2, stealth: -1, ... }

    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_items_category").on(table.category),
    index("idx_items_rarity").on(table.rarity),
    index("idx_items_name").on(table.name),
  ]
);

// Inventory instances (each character has inventory items)
export const inventoryItems = pgTable(
  "inventory_items",
  {
    id: serial("id").primaryKey(),
    characterId: integer("character_id")
      .references(() => characters.id, { onDelete: "cascade" })
      .notNull(),
    itemId: integer("item_id")
      .references(() => items.id, { onDelete: "cascade" })
      .notNull(),

    // Grid position
    gridX: integer("grid_x").notNull(), // 0-based position in inventory grid
    gridY: integer("grid_y").notNull(),
    rotated: boolean("rotated").default(false).notNull(),

    // Equipment slot (if equipped)
    equippedSlot: equipmentSlotEnum("equipped_slot"),

    // Current durability, quality and stack count
    currentDurability: integer("current_durability"),
    quality: qualityEnum("quality").default("normal").notNull(), // Качество экземпляра
    stackCount: integer("stack_count").default(1).notNull(),

    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_inventory_character_id").on(table.characterId),
    index("idx_inventory_item_id").on(table.itemId),
  ]
);

// Lobby items (real-time shared lobby for item pickup)
export const lobbyItems = pgTable(
  "lobby_items",
  {
    id: serial("id").primaryKey(),
    itemId: integer("item_id")
      .references(() => items.id, { onDelete: "cascade" })
      .notNull(),
    worldName: varchar("world_name", { length: 50 }).default("sphere").notNull(), // sphere or table2

    // Grid position (10x10 grid)
    gridX: integer("grid_x").notNull(),
    gridY: integer("grid_y").notNull(),

    // Lock mechanism (0.8 second lock)
    lockedBy: varchar("locked_by"),
    lockedAt: timestamp("locked_at"),

    stackCount: integer("stack_count").default(1).notNull(),

    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_lobby_items_world").on(table.worldName),
    index("idx_lobby_items_item_id").on(table.itemId),
  ]
);

// Active Effects (временные бафы/дебафы на персонажей)
export const activeEffects = pgTable(
  "active_effects",
  {
    id: serial("id").primaryKey(),
    characterId: integer("character_id")
      .references(() => characters.id, { onDelete: "cascade" })
      .notNull(),
    
    name: varchar("name", { length: 100 }).notNull(), // Название эффекта
    description: text("description"), // Описание
    
    // Модификаторы характеристик
    statModifiers: jsonb("stat_modifiers"), // { shooting: 5, stealth: -2, ... }
    
    // Время действия (реальное время)
    startedAt: timestamp("started_at").defaultNow().notNull(),
    expiresAt: timestamp("expires_at"), // Когда истекает (null для постоянных эффектов)
    
    // Метаданные
    sourceItemId: integer("source_item_id").references(() => items.id), // Откуда эффект
    isPositive: boolean("is_positive").default(true).notNull(), // Баф или дебаф
    
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_active_effects_character").on(table.characterId),
    index("idx_active_effects_expires").on(table.expiresAt),
  ]
);

// Traders
export const traders = pgTable("traders", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  isOpen: boolean("is_open").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Trader inventory
export const traderItems = pgTable(
  "trader_items",
  {
    id: serial("id").primaryKey(),
    traderId: integer("trader_id")
      .references(() => traders.id, { onDelete: "cascade" })
      .notNull(),
    itemId: integer("item_id")
      .references(() => items.id, { onDelete: "cascade" })
      .notNull(),
    stock: integer("stock").default(0).notNull(),

    // Multi-currency pricing (can have multiple currencies required)
    priceGold: integer("price_gold").default(0),
    priceSilver: integer("price_silver").default(0),
    priceCores: integer("price_cores").default(0),
    priceSovietMedal1: integer("price_soviet_medal_1").default(0),
    priceSovietMedal2: integer("price_soviet_medal_2").default(0),
    priceSovietMedal3: integer("price_soviet_medal_3").default(0),
    priceReichMark1: integer("price_reich_mark_1").default(0),
    priceReichMark2: integer("price_reich_mark_2").default(0),
    priceReichMark3: integer("price_reich_mark_3").default(0),

    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [index("idx_trader_items_trader_id").on(table.traderId)]
);

// Crafting recipes
export const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  resultItemId: integer("result_item_id")
    .references(() => items.id, { onDelete: "cascade" })
    .notNull(),
  resultQuantity: integer("result_quantity").default(1).notNull(),

  // Required class (null = any class can craft)
  requiredClass: characterClassEnum("required_class"),

  // Materials as JSON: [{ itemId: 1, quantity: 3 }, ...]
  materials: jsonb("materials").notNull(),

  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Auction listings
export const auctionListings = pgTable(
  "auction_listings",
  {
    id: serial("id").primaryKey(),
    sellerId: varchar("seller_id")
      .references(() => users.id, { onDelete: "cascade" })
      .notNull(),
    itemId: integer("item_id")
      .references(() => items.id, { onDelete: "cascade" })
      .notNull(),
    quantity: integer("quantity").default(1).notNull(),

    // Price in single currency
    currencyType: currencyTypeEnum("currency_type").notNull(),
    price: integer("price").notNull(),

    expiresAt: timestamp("expires_at").notNull(), // 30 days from creation
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_auction_seller_id").on(table.sellerId),
    index("idx_auction_item_id").on(table.itemId),
    index("idx_auction_expires_at").on(table.expiresAt),
  ]
);

// Auction warehouse (20 cells, expandable with gold)
export const auctionWarehouses = pgTable(
  "auction_warehouses",
  {
    id: serial("id").primaryKey(),
    userId: varchar("user_id")
      .references(() => users.id, { onDelete: "cascade" })
      .notNull()
      .unique(),
    capacity: integer("capacity").default(20).notNull(), // Starts at 20, +4 per gold spent
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [index("idx_auction_warehouse_user_id").on(table.userId)]
);

// Auction warehouse items
export const auctionWarehouseItems = pgTable(
  "auction_warehouse_items",
  {
    id: serial("id").primaryKey(),
    warehouseId: integer("warehouse_id")
      .references(() => auctionWarehouses.id, { onDelete: "cascade" })
      .notNull(),
    itemId: integer("item_id")
      .references(() => items.id, { onDelete: "cascade" })
      .notNull(),
    gridX: integer("grid_x").notNull(),
    gridY: integer("grid_y").notNull(),
    stackCount: integer("stack_count").default(1).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [index("idx_auction_warehouse_items_warehouse_id").on(table.warehouseId)]
);

// GM requests for item spawning
export const gmRequests = pgTable(
  "gm_requests",
  {
    id: serial("id").primaryKey(),
    gmId: varchar("gm_id")
      .references(() => users.id, { onDelete: "cascade" })
      .notNull(),
    itemId: integer("item_id")
      .references(() => items.id, { onDelete: "cascade" })
      .notNull(),
    requestedQuantity: integer("requested_quantity").notNull(),
    approvedQuantity: integer("approved_quantity"),
    status: requestStatusEnum("status").default("pending").notNull(),
    adminComment: text("admin_comment"),
    reviewedBy: varchar("reviewed_by").references(() => users.id),
    reviewedAt: timestamp("reviewed_at"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_gm_requests_gm_id").on(table.gmId),
    index("idx_gm_requests_status").on(table.status),
  ]
);

// Chat messages (300 message history)
export const chatMessages = pgTable(
  "chat_messages",
  {
    id: serial("id").primaryKey(),
    userId: varchar("user_id")
      .references(() => users.id, { onDelete: "set null" })
      ,
    username: varchar("username", { length: 50 }).notNull(),
    worldName: varchar("world_name", { length: 50 }).default("sphere").notNull(),
    message: text("message").notNull(),
    isDiceRoll: boolean("is_dice_roll").default(false).notNull(),
    diceResult: text("dice_result"), // e.g., "2d6+3 = 11 [4, 4]"
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_chat_messages_world").on(table.worldName),
    index("idx_chat_messages_created_at").on(table.createdAt),
  ]
);

// News articles
export const news = pgTable("news", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 300 }).notNull(),
  content: text("content").notNull(), // Rich text HTML
  authorId: varchar("author_id")
    .references(() => users.id, { onDelete: "set null" })
    ,
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Admin/GM action logs
export const actionLogs = pgTable(
  "action_logs",
  {
    id: serial("id").primaryKey(),
    userId: varchar("user_id")
      .references(() => users.id, { onDelete: "set null" })
      ,
    username: varchar("username", { length: 50 }).notNull(),
    actionType: actionTypeEnum("action_type").notNull(),
    description: text("description").notNull(),
    metadata: jsonb("metadata"), // Additional context
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_action_logs_user_id").on(table.userId),
    index("idx_action_logs_action_type").on(table.actionType),
    index("idx_action_logs_created_at").on(table.createdAt),
  ]
);

// World map state (saved canvas data for each world)
export const worldMaps = pgTable("world_maps", {
  id: serial("id").primaryKey(),
  worldName: varchar("world_name", { length: 50 }).notNull().unique(),
  canvasData: jsonb("canvas_data").notNull(), // Serialized canvas state
  layers: jsonb("layers").notNull(), // Layer information
  markers: jsonb("markers"), // [{ x, y, title, description }]
  updatedBy: varchar("updated_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Game access password (for lobby, trader, craft, inventory rooms)
export const gamePassword = pgTable("game_password", {
  id: serial("id").primaryKey(),
  password: text("password").notNull(),
  setBy: varchar("set_by")
    .references(() => users.id, { onDelete: "set null" })
    ,
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ========== RELATIONS ==========

export const usersRelations = relations(users, ({ many }) => ({
  characters: many(characters),
  auctionListings: many(auctionListings),
  gmRequests: many(gmRequests),
  chatMessages: many(chatMessages),
  news: many(news),
  actionLogs: many(actionLogs),
  auctionWarehouse: many(auctionWarehouses),
}));

export const charactersRelations = relations(characters, ({ one, many }) => ({
  user: one(users, {
    fields: [characters.userId],
    references: [users.id],
  }),
  inventoryItems: many(inventoryItems),
}));

export const itemsRelations = relations(items, ({ many }) => ({
  inventoryItems: many(inventoryItems),
  lobbyItems: many(lobbyItems),
  traderItems: many(traderItems),
  recipes: many(recipes),
  auctionListings: many(auctionListings),
  auctionWarehouseItems: many(auctionWarehouseItems),
}));

export const inventoryItemsRelations = relations(inventoryItems, ({ one }) => ({
  character: one(characters, {
    fields: [inventoryItems.characterId],
    references: [characters.id],
  }),
  item: one(items, {
    fields: [inventoryItems.itemId],
    references: [items.id],
  }),
}));

export const lobbyItemsRelations = relations(lobbyItems, ({ one }) => ({
  item: one(items, {
    fields: [lobbyItems.itemId],
    references: [items.id],
  }),
}));

export const tradersRelations = relations(traders, ({ many }) => ({
  traderItems: many(traderItems),
}));

export const traderItemsRelations = relations(traderItems, ({ one }) => ({
  trader: one(traders, {
    fields: [traderItems.traderId],
    references: [traders.id],
  }),
  item: one(items, {
    fields: [traderItems.itemId],
    references: [items.id],
  }),
}));

export const recipesRelations = relations(recipes, ({ one }) => ({
  resultItem: one(items, {
    fields: [recipes.resultItemId],
    references: [items.id],
  }),
}));

export const auctionListingsRelations = relations(auctionListings, ({ one }) => ({
  seller: one(users, {
    fields: [auctionListings.sellerId],
    references: [users.id],
  }),
  item: one(items, {
    fields: [auctionListings.itemId],
    references: [items.id],
  }),
}));

export const auctionWarehousesRelations = relations(
  auctionWarehouses,
  ({ one, many }) => ({
    user: one(users, {
      fields: [auctionWarehouses.userId],
      references: [users.id],
    }),
    items: many(auctionWarehouseItems),
  })
);

export const auctionWarehouseItemsRelations = relations(
  auctionWarehouseItems,
  ({ one }) => ({
    warehouse: one(auctionWarehouses, {
      fields: [auctionWarehouseItems.warehouseId],
      references: [auctionWarehouses.id],
    }),
    item: one(items, {
      fields: [auctionWarehouseItems.itemId],
      references: [items.id],
    }),
  })
);

export const gmRequestsRelations = relations(gmRequests, ({ one }) => ({
  gm: one(users, {
    fields: [gmRequests.gmId],
    references: [users.id],
  }),
  item: one(items, {
    fields: [gmRequests.itemId],
    references: [items.id],
  }),
}));

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  user: one(users, {
    fields: [chatMessages.userId],
    references: [users.id],
  }),
}));

export const newsRelations = relations(news, ({ one }) => ({
  author: one(users, {
    fields: [news.authorId],
    references: [users.id],
  }),
}));

export const actionLogsRelations = relations(actionLogs, ({ one }) => ({
  user: one(users, {
    fields: [actionLogs.userId],
    references: [users.id],
  }),
}));

export const worldMapsRelations = relations(worldMaps, ({ one }) => ({
  updater: one(users, {
    fields: [worldMaps.updatedBy],
    references: [users.id],
  }),
}));

// ========== ZOD SCHEMAS ==========

export const insertUserSchema = createInsertSchema(users, {
  username: z.string().min(4, "Логин должен содержать минимум 4 символа"),
  password: z.string().min(8, "Пароль должен содержать минимум 8 символов"),
}).omit({ id: true, createdAt: true, updatedAt: true });

export const insertCharacterSchema = createInsertSchema(characters).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertItemSchema = createInsertSchema(items).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertInventoryItemSchema = createInsertSchema(inventoryItems).omit({
  id: true,
  createdAt: true,
});

export const insertLobbyItemSchema = createInsertSchema(lobbyItems).omit({
  id: true,
  createdAt: true,
});

export const insertTraderSchema = createInsertSchema(traders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTraderItemSchema = createInsertSchema(traderItems).omit({
  id: true,
  createdAt: true,
});

export const insertRecipeSchema = createInsertSchema(recipes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAuctionListingSchema = createInsertSchema(auctionListings).omit({
  id: true,
  createdAt: true,
});

export const insertGmRequestSchema = createInsertSchema(gmRequests).omit({
  id: true,
  createdAt: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
});

export const insertNewsSchema = createInsertSchema(news).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertActionLogSchema = createInsertSchema(actionLogs).omit({
  id: true,
  createdAt: true,
});

export const insertActiveEffectSchema = createInsertSchema(activeEffects).omit({
  id: true,
  createdAt: true,
});

// ========== TYPES ==========

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Character = typeof characters.$inferSelect;
export type InsertCharacter = z.infer<typeof insertCharacterSchema>;

export type Item = typeof items.$inferSelect;
export type InsertItem = z.infer<typeof insertItemSchema>;

export type InventoryItem = typeof inventoryItems.$inferSelect;
export type InsertInventoryItem = z.infer<typeof insertInventoryItemSchema>;

export type LobbyItem = typeof lobbyItems.$inferSelect;
export type InsertLobbyItem = z.infer<typeof insertLobbyItemSchema>;

export type Trader = typeof traders.$inferSelect;
export type InsertTrader = z.infer<typeof insertTraderSchema>;

export type TraderItem = typeof traderItems.$inferSelect;
export type InsertTraderItem = z.infer<typeof insertTraderItemSchema>;

export type Recipe = typeof recipes.$inferSelect;
export type InsertRecipe = z.infer<typeof insertRecipeSchema>;

export type AuctionListing = typeof auctionListings.$inferSelect;
export type InsertAuctionListing = z.infer<typeof insertAuctionListingSchema>;

export type AuctionWarehouse = typeof auctionWarehouses.$inferSelect;

export type AuctionWarehouseItem = typeof auctionWarehouseItems.$inferSelect;

export type GmRequest = typeof gmRequests.$inferSelect;
export type InsertGmRequest = z.infer<typeof insertGmRequestSchema>;

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;

export type News = typeof news.$inferSelect;
export type InsertNews = z.infer<typeof insertNewsSchema>;

export type ActionLog = typeof actionLogs.$inferSelect;
export type InsertActionLog = z.infer<typeof insertActionLogSchema>;

export type ActiveEffect = typeof activeEffects.$inferSelect;
export type InsertActiveEffect = z.infer<typeof insertActiveEffectSchema>;

export type WorldMap = typeof worldMaps.$inferSelect;
export type GamePassword = typeof gamePassword.$inferSelect;
