import { useMemo } from "react";
import { Card } from "@/components/ui/card";
import type { InventoryItem, Item } from "@shared/schema";
import { 
  User, 
  Shirt, 
  Shield, 
  ArrowUpSquare,
  Footprints,
  CircleDot,
  Headphones,
  AlignVerticalJustifyStart,
  Hand
} from "lucide-react";

interface GridItem extends InventoryItem {
  item: Item;
}

interface EquipmentSlotsProps {
  equippedItems: GridItem[];
  onSlotClick?: (slot: string) => void;
}

const EQUIPMENT_SLOTS = [
  { id: "head", label: "Голова", icon: User, position: "top-0 left-1/2 -translate-x-1/2" },
  { id: "headphones", label: "Наушники", icon: Headphones, position: "top-8 left-0" },
  { id: "top", label: "Верх", icon: Shirt, position: "top-16 left-1/2 -translate-x-1/2" },
  { id: "armor", label: "Броня", icon: Shield, position: "top-16 right-0" },
  { id: "vest", label: "Разгрузка", icon: ArrowUpSquare, position: "top-24 left-0" },
  { id: "clothing", label: "Одежда", icon: Shirt, position: "top-24 right-0" },
  { id: "belt", label: "Пояс", icon: CircleDot, position: "top-32 left-1/2 -translate-x-1/2" },
  { id: "strap", label: "Лямка", icon: AlignVerticalJustifyStart, position: "top-32 right-0" },
  { id: "hand_left", label: "Левая рука", icon: Hand, position: "top-40 left-0" },
  { id: "hand_right", label: "Правая рука", icon: Hand, position: "top-40 right-0" },
  { id: "bottom", label: "Низ", icon: Shirt, position: "top-48 left-1/2 -translate-x-1/2" },
  { id: "footwear", label: "Обувь", icon: Footprints, position: "top-56 left-1/2 -translate-x-1/2" },
];

const RARITY_COLORS = {
  poor: "border-gray-600 bg-gray-600/20",
  common: "border-slate-400 bg-slate-400/15",
  uncommon: "border-green-500 bg-green-500/20",
  rare: "border-blue-500 bg-blue-500/20",
  epic: "border-purple-500 bg-purple-500/20",
  legendary: "border-orange-500 bg-orange-500/20",
  artifact: "border-red-500 bg-red-500/20",
  unique: "border-yellow-400 bg-yellow-400/20",
};

export default function EquipmentSlots({ equippedItems, onSlotClick }: EquipmentSlotsProps) {
  const slotMap = useMemo(() => {
    const map: Record<string, GridItem> = {};
    equippedItems.forEach((item) => {
      if (item.equippedSlot) {
        map[item.equippedSlot] = item;
      }
    });
    return map;
  }, [equippedItems]);

  return (
    <Card className="p-4">
      <h2 className="mb-4 font-russo text-lg">Экипировка</h2>
      
      {/* Character Silhouette Container */}
      <div className="relative mx-auto" style={{ width: "200px", height: "400px" }}>
        {/* Simple character silhouette - vertical line representation */}
        <div className="absolute left-1/2 top-8 h-64 w-1 -translate-x-1/2 bg-muted-foreground/20" />
        <div className="absolute left-1/2 top-12 h-1 w-24 -translate-x-1/2 bg-muted-foreground/20" />
        
        {/* Equipment slots */}
        {EQUIPMENT_SLOTS.map((slot) => {
          const equipped = slotMap[slot.id];
          const Icon = slot.icon;
          const rarityClass = equipped 
            ? RARITY_COLORS[equipped.item.rarity as keyof typeof RARITY_COLORS] || RARITY_COLORS.common
            : "border-border bg-card";

          return (
            <div
              key={slot.id}
              className={`absolute ${slot.position}`}
              data-testid={`equipment-slot-${slot.id}`}
            >
              <button
                onClick={() => onSlotClick?.(slot.id)}
                className={`flex h-12 w-12 cursor-pointer items-center justify-center rounded border-2 p-1 text-xs transition-all hover-elevate active-elevate-2 ${rarityClass}`}
                title={slot.label}
              >
                {equipped ? (
                  <span className="text-center font-mono text-[9px] leading-tight">
                    {equipped.item.name.slice(0, 6)}
                  </span>
                ) : (
                  <Icon className="h-5 w-5 text-muted-foreground" />
                )}
              </button>
            </div>
          );
        })}
      </div>
      
      {/* Legend */}
      <div className="mt-4 space-y-1 text-xs text-muted-foreground">
        <p>Кликните на слот чтобы снять</p>
        <p>Перетащите предмет из сетки</p>
      </div>
    </Card>
  );
}
