import { Card } from "@/components/ui/card";
import type { Character } from "@shared/schema";
import { Heart, Drumstick, Droplet, Weight } from "lucide-react";

interface CharacterStatsProps {
  character: Character;
}

export default function CharacterStats({ character }: CharacterStatsProps) {
  const currentWeight = (character.currentWeight || 0) / 1000; // convert to kg
  const maxWeight = (character.maxWeight || 80000) / 1000;
  const weightPercent = Math.min(100, (currentWeight / maxWeight) * 100);

  // TODO: These are placeholder values until health/hunger/thirst are added to character schema
  const health = 100;
  const maxHealth = 100;
  const hunger = 80;
  const thirst = 60;

  return (
    <Card className="p-4">
      <h2 className="mb-4 font-russo text-lg">Характеристики</h2>
      
      <div className="space-y-3">
        {/* Health */}
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-sm">
            <Heart className="h-4 w-4 text-red-500" />
            <span className="text-muted-foreground">Здоровье</span>
            <span className="ml-auto font-mono">
              {health}/{maxHealth}
            </span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full bg-red-500 transition-all"
              style={{ width: `${(health / maxHealth) * 100}%` }}
            />
          </div>
        </div>

        {/* Hunger */}
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-sm">
            <Drumstick className="h-4 w-4 text-orange-500" />
            <span className="text-muted-foreground">Голод</span>
            <span className="ml-auto font-mono">{hunger}%</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full bg-orange-500 transition-all"
              style={{ width: `${hunger}%` }}
            />
          </div>
        </div>

        {/* Thirst */}
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-sm">
            <Droplet className="h-4 w-4 text-blue-500" />
            <span className="text-muted-foreground">Жажда</span>
            <span className="ml-auto font-mono">{thirst}%</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full bg-blue-500 transition-all"
              style={{ width: `${thirst}%` }}
            />
          </div>
        </div>

        {/* Weight */}
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-sm">
            <Weight className="h-4 w-4 text-yellow-500" />
            <span className="text-muted-foreground">Вес</span>
            <span className="ml-auto font-mono">
              {currentWeight.toFixed(1)} / {maxWeight.toFixed(0)} кг
            </span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full bg-yellow-500 transition-all"
              style={{ width: `${weightPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Character info */}
      <div className="mt-4 space-y-1 border-t border-border pt-3 text-xs text-muted-foreground">
        <p><span className="font-semibold">Имя:</span> {character.name}</p>
        <p><span className="font-semibold">Класс:</span> {character.characterClass}</p>
      </div>
    </Card>
  );
}
