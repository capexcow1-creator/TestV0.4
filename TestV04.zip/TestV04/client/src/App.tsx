import { Switch, Route, Redirect } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import NotFound from "@/pages/not-found";
import LoginPage from "@/pages/login";
import HomePage from "@/pages/home";
import CharactersPage from "@/pages/characters";
import CreateCharacterPage from "@/pages/create-character";
import InventoryPage from "@/pages/inventory";
import ItemsPage from "@/pages/items";
import ItemFormPage from "@/pages/item-form";
import LobbyPage from "@/pages/lobby";
import LobbyAdminPage from "@/pages/lobby-admin";
import WorldSpherePage from "@/pages/world-sphere";
import ChatPage from "@/pages/chat";
import AdminPanel from "@/pages/admin";
import TradersPage from "@/pages/traders";
import NewsPage from "@/pages/news";
import NewsAdminPage from "@/pages/news-admin";
import GmPanelPage from "@/pages/gm-panel";
import CraftingPage from "@/pages/crafting";
import RecipesAdminPage from "@/pages/recipes-admin";

function ProtectedRoute({ component: Component }: { component: () => JSX.Element | null }) {
  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/me"],
  });

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <p className="text-muted-foreground">Загрузка...</p>
      </div>
    );
  }

  if (!user) {
    return <Redirect to="/login" />;
  }

  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={LoginPage} />
      <Route path="/items/create">
        {() => <ProtectedRoute component={ItemFormPage} />}
      </Route>
      <Route path="/items/:itemId/edit">
        {() => <ProtectedRoute component={ItemFormPage} />}
      </Route>
      <Route path="/items">
        {() => <ProtectedRoute component={ItemsPage} />}
      </Route>
      <Route path="/characters/:characterId/inventory">
        {() => <ProtectedRoute component={InventoryPage} />}
      </Route>
      <Route path="/characters/new">
        {() => <ProtectedRoute component={CreateCharacterPage} />}
      </Route>
      <Route path="/characters">
        {() => <ProtectedRoute component={CharactersPage} />}
      </Route>
      <Route path="/world/sphere">
        {() => <ProtectedRoute component={WorldSpherePage} />}
      </Route>
      <Route path="/lobby/admin">
        {() => <ProtectedRoute component={LobbyAdminPage} />}
      </Route>
      <Route path="/lobby">
        {() => <ProtectedRoute component={LobbyPage} />}
      </Route>
      <Route path="/chat">
        {() => <ProtectedRoute component={ChatPage} />}
      </Route>
      <Route path="/traders">
        {() => <ProtectedRoute component={TradersPage} />}
      </Route>
      <Route path="/news/admin">
        {() => <ProtectedRoute component={NewsAdminPage} />}
      </Route>
      <Route path="/news">
        {() => <ProtectedRoute component={NewsPage} />}
      </Route>
      <Route path="/gm-panel">
        {() => <ProtectedRoute component={GmPanelPage} />}
      </Route>
      <Route path="/crafting">
        {() => <ProtectedRoute component={CraftingPage} />}
      </Route>
      <Route path="/recipes/admin">
        {() => <ProtectedRoute component={RecipesAdminPage} />}
      </Route>
      <Route path="/admin">
        {() => <ProtectedRoute component={AdminPanel} />}
      </Route>
      <Route path="/">
        {() => <ProtectedRoute component={HomePage} />}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark" storageKey="dnd-theme">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
