import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Trader, TraderItem, Item, Character } from "@shared/schema";
import { ArrowLeft, Store, ShoppingCart, Coins } from "lucide-react";

interface TraderItemWithItem extends TraderItem {
  item: Item;
}

export default function TradersPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [selectedTraderId, setSelectedTraderId] = useState<number | null>(null);
  const [selectedCharacterId, setSelectedCharacterId] = useState<number | null>(null);

  // Load selected character from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("selectedCharacterId");
    if (saved) {
      setSelectedCharacterId(parseInt(saved, 10));
    }
  }, []);

  // Fetch current user
  const { data: currentUser } = useQuery<any>({
    queryKey: ["/api/auth/me"],
  });

  // Fetch character details
  const { data: character } = useQuery<Character>({
    queryKey: ["/api/characters", selectedCharacterId],
    enabled: !!selectedCharacterId,
  });

  // Fetch all traders
  const { data: traders = [], isLoading: tradersLoading } = useQuery<Trader[]>({
    queryKey: ["/api/traders"],
    enabled: !!currentUser,
  });

  // Fetch trader items
  const { data: traderItems = [], isLoading: itemsLoading } = useQuery<TraderItemWithItem[]>({
    queryKey: ["/api/traders", selectedTraderId, "items"],
    enabled: !!selectedTraderId,
  });

  // Buy item mutation
  const buyMutation = useMutation({
    mutationFn: async (data: { traderItemId: number }) => {
      return apiRequest("POST", `/api/traders/${selectedTraderId}/buy`, {
        traderItemId: data.traderItemId,
        characterId: selectedCharacterId,
      });
    },
    onSuccess: () => {
      toast({
        title: "Покупка успешна!",
        description: "Предмет добавлен в инвентарь",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/traders", selectedTraderId, "items"] });
      queryClient.invalidateQueries({ queryKey: ["/api/characters", selectedCharacterId] });
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка покупки",
        description: error.message || "Не удалось купить предмет",
        variant: "destructive",
      });
    },
  });

  const handleBuyItem = (traderItemId: number) => {
    if (!selectedCharacterId) {
      toast({
        title: "Ошибка",
        description: "Выберите персонажа",
        variant: "destructive",
      });
      return;
    }
    buyMutation.mutate({ traderItemId });
  };

  const getRarityColor = (rarity: string) => {
    const colors: Record<string, string> = {
      poor: "text-gray-500",
      common: "text-white",
      uncommon: "text-green-400",
      rare: "text-blue-400",
      epic: "text-purple-400",
      legendary: "text-orange-400",
      artifact: "text-red-400",
      unique: "text-yellow-400",
    };
    return colors[rarity] || "text-white";
  };

  const formatCurrencies = (traderItem: TraderItemWithItem) => {
    const currencies: string[] = [];
    if (traderItem.priceGold) currencies.push(`${traderItem.priceGold} Золото`);
    if (traderItem.priceSilver) currencies.push(`${traderItem.priceSilver} Серебро`);
    if (traderItem.priceCores) currencies.push(`${traderItem.priceCores} Ядра`);
    if (traderItem.priceSovietMedal1) currencies.push(`${traderItem.priceSovietMedal1} Медаль СССР 1`);
    if (traderItem.priceSovietMedal2) currencies.push(`${traderItem.priceSovietMedal2} Медаль СССР 2`);
    if (traderItem.priceSovietMedal3) currencies.push(`${traderItem.priceSovietMedal3} Медаль СССР 3`);
    if (traderItem.priceReichMark1) currencies.push(`${traderItem.priceReichMark1} Рейхсмарка 1`);
    if (traderItem.priceReichMark2) currencies.push(`${traderItem.priceReichMark2} Рейхсмарка 2`);
    if (traderItem.priceReichMark3) currencies.push(`${traderItem.priceReichMark3} Рейхсмарка 3`);
    return currencies.length > 0 ? currencies.join(", ") : "Бесплатно";
  };

  const canAfford = (traderItem: TraderItemWithItem): boolean => {
    if (!character) return false;
    if (traderItem.priceGold && character.gold < traderItem.priceGold) return false;
    if (traderItem.priceSilver && character.silver < traderItem.priceSilver) return false;
    if (traderItem.priceCores && character.cores < traderItem.priceCores) return false;
    if (traderItem.priceSovietMedal1 && character.sovietMedal1 < traderItem.priceSovietMedal1) return false;
    if (traderItem.priceSovietMedal2 && character.sovietMedal2 < traderItem.priceSovietMedal2) return false;
    if (traderItem.priceSovietMedal3 && character.sovietMedal3 < traderItem.priceSovietMedal3) return false;
    if (traderItem.priceReichMark1 && character.reichMark1 < traderItem.priceReichMark1) return false;
    if (traderItem.priceReichMark2 && character.reichMark2 < traderItem.priceReichMark2) return false;
    if (traderItem.priceReichMark3 && character.reichMark3 < traderItem.priceReichMark3) return false;
    return true;
  };

  if (!selectedTraderId) {
    // Traders list view
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-6xl mx-auto space-y-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/world/sphere")}
              data-testid="button-back"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold">Торговцы</h1>
              <p className="text-muted-foreground">Купите снаряжение у торговцев</p>
            </div>
          </div>

          {/* Character Currencies Display */}
          {character && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Ваши валюты</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  <div className="flex items-center gap-2">
                    <Coins className="h-4 w-4 text-yellow-400" />
                    <span className="text-sm">Золото: {character.gold}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Coins className="h-4 w-4 text-gray-400" />
                    <span className="text-sm">Серебро: {character.silver}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Coins className="h-4 w-4 text-blue-400" />
                    <span className="text-sm">Ядра: {character.cores}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Coins className="h-4 w-4 text-red-400" />
                    <span className="text-sm">Медаль СССР 1: {character.sovietMedal1}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Coins className="h-4 w-4 text-red-500" />
                    <span className="text-sm">Медаль СССР 2: {character.sovietMedal2}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Coins className="h-4 w-4 text-red-600" />
                    <span className="text-sm">Медаль СССР 3: {character.sovietMedal3}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Coins className="h-4 w-4 text-orange-400" />
                    <span className="text-sm">Рейхсмарка 1: {character.reichMark1}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Coins className="h-4 w-4 text-orange-500" />
                    <span className="text-sm">Рейхсмарка 2: {character.reichMark2}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Coins className="h-4 w-4 text-orange-600" />
                    <span className="text-sm">Рейхсмарка 3: {character.reichMark3}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Traders Grid */}
          {tradersLoading ? (
            <p className="text-center text-muted-foreground">Загрузка торговцев...</p>
          ) : traders.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Store className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-lg font-medium">Торговцев пока нет</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Администратор может создать торговцев
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {traders.map((trader) => (
                <Card
                  key={trader.id}
                  className={`hover-elevate cursor-pointer ${!trader.isOpen ? "opacity-50" : ""}`}
                  onClick={() => trader.isOpen && setSelectedTraderId(trader.id)}
                  data-testid={`trader-card-${trader.id}`}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-xl">{trader.name}</CardTitle>
                        {trader.description && (
                          <CardDescription className="mt-2">{trader.description}</CardDescription>
                        )}
                      </div>
                      <Store className="h-6 w-6 text-primary" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Badge variant={trader.isOpen ? "default" : "secondary"}>
                      {trader.isOpen ? "Открыто" : "Закрыто"}
                    </Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Trader items view
  const selectedTrader = traders.find((t) => t.id === selectedTraderId);

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSelectedTraderId(null)}
            data-testid="button-back-to-traders"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">{selectedTrader?.name}</h1>
            <p className="text-muted-foreground">{selectedTrader?.description || "Товары торговца"}</p>
          </div>
        </div>

        {/* Character Currencies Display */}
        {character && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Ваши валюты</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div className="flex items-center gap-2">
                  <Coins className="h-4 w-4 text-yellow-400" />
                  <span className="text-sm">Золото: {character.gold}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Coins className="h-4 w-4 text-gray-400" />
                  <span className="text-sm">Серебро: {character.silver}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Coins className="h-4 w-4 text-blue-400" />
                  <span className="text-sm">Ядра: {character.cores}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Trader Items Grid */}
        {itemsLoading ? (
          <p className="text-center text-muted-foreground">Загрузка товаров...</p>
        ) : traderItems.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <ShoppingCart className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-lg font-medium">Товаров пока нет</p>
              <p className="text-sm text-muted-foreground mt-2">
                Торговец пока не продает никаких предметов
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {traderItems.map((traderItem) => {
              const affordable = canAfford(traderItem);
              const outOfStock = traderItem.stock <= 0;

              return (
                <Card key={traderItem.id} className={`${!affordable || outOfStock ? "opacity-50" : ""}`} data-testid={`trader-item-${traderItem.id}`}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className={`text-lg ${getRarityColor(traderItem.item.rarity)}`}>
                          {traderItem.item.name}
                        </CardTitle>
                        {traderItem.item.description && (
                          <CardDescription className="mt-2 line-clamp-2">
                            {traderItem.item.description}
                          </CardDescription>
                        )}
                      </div>
                      <Badge variant="outline">{traderItem.item.rarity}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-1 text-sm">
                      <p>
                        <span className="text-muted-foreground">Категория:</span>{" "}
                        {traderItem.item.category}
                      </p>
                      <p>
                        <span className="text-muted-foreground">Размер:</span>{" "}
                        {traderItem.item.width}x{traderItem.item.height}
                      </p>
                      <p>
                        <span className="text-muted-foreground">Вес:</span>{" "}
                        {traderItem.item.weight}г
                      </p>
                      <p>
                        <span className="text-muted-foreground">В наличии:</span>{" "}
                        {traderItem.stock}
                      </p>
                    </div>

                    <div className="pt-2 border-t">
                      <p className="text-sm font-medium mb-2">Цена:</p>
                      <p className="text-xs text-muted-foreground">{formatCurrencies(traderItem)}</p>
                    </div>

                    <Button
                      className="w-full"
                      size="sm"
                      onClick={() => handleBuyItem(traderItem.id)}
                      disabled={!affordable || outOfStock || buyMutation.isPending}
                      data-testid={`button-buy-${traderItem.id}`}
                    >
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      {outOfStock ? "Нет в наличии" : !affordable ? "Недостаточно валюты" : "Купить"}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
