import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation, Link } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Plus, Trash2, ArrowLeft, Package } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const CHARACTER_CLASS_NAMES = {
  loner: "Одиночка",
  mercenary: "Наёмник",
  technician: "Техник",
  medic: "Медик",
  stalker: "Сталкер",
  bandit: "Бандит",
} as const;

type Character = {
  id: number;
  name: string;
  characterClass: keyof typeof CHARACTER_CLASS_NAMES;
  avatarUrl: string | null;
  currentHp: number;
  maxHp: number;
  currentFood: number;
  currentWater: number;
};

export default function CharactersPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: currentUser, isLoading: userLoading } = useQuery({
    queryKey: ["/api/auth/me"],
    retry: false,
  });

  const { data: characters = [], isLoading: charactersLoading } = useQuery<Character[]>({
    queryKey: ["/api/characters"],
    enabled: !!currentUser,
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/characters/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/characters"] });
      toast({
        title: "Персонаж удалён",
        description: "Персонаж успешно удалён",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось удалить персонажа",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!userLoading && !currentUser) {
      setLocation("/login");
    }
  }, [userLoading, currentUser, setLocation]);

  if (userLoading || charactersLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <p className="text-muted-foreground">Загрузка...</p>
      </div>
    );
  }

  if (!currentUser) {
    return null;
  }

  const canCreateCharacter = characters.length < 2;

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-4xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/")}
              data-testid="button-back"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-foreground">
                Мои Персонажи
              </h1>
              <p className="text-sm text-muted-foreground">
                {characters.length} / 2 персонажа
              </p>
            </div>
          </div>

          {canCreateCharacter && (
            <Link href="/characters/new">
              <Button data-testid="button-create-character">
                <Plus className="mr-2 h-4 w-4" />
                Создать персонажа
              </Button>
            </Link>
          )}
        </div>

        {/* Characters Grid */}
        {characters.length === 0 ? (
          <Card className="p-12 text-center">
            <CardContent>
              <p className="mb-4 text-lg text-muted-foreground">
                У вас пока нет персонажей
              </p>
              <Link href="/characters/new">
                <Button data-testid="button-create-first-character">
                  <Plus className="mr-2 h-4 w-4" />
                  Создать первого персонажа
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6 md:grid-cols-2">
            {characters.map((character) => (
              <Card
                key={character.id}
                className="overflow-hidden"
                data-testid={`card-character-${character.id}`}
              >
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-2xl font-bold">
                    {character.name}
                  </CardTitle>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        data-testid={`button-delete-${character.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>
                          Удалить персонажа?
                        </AlertDialogTitle>
                        <AlertDialogDescription>
                          Это действие нельзя отменить. Персонаж{" "}
                          {character.name} будет удалён навсегда.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel data-testid="button-cancel-delete">
                          Отмена
                        </AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => deleteMutation.mutate(character.id)}
                          data-testid="button-confirm-delete"
                        >
                          Удалить
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="flex items-center gap-4">
                    <Avatar className="h-20 w-20">
                      <AvatarImage src={character.avatarUrl || undefined} />
                      <AvatarFallback className="text-2xl">
                        {character.name[0].toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">
                        Класс
                      </p>
                      <p className="text-lg font-bold text-foreground">
                        {CHARACTER_CLASS_NAMES[character.characterClass]}
                      </p>
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="space-y-2">
                    <div>
                      <div className="mb-1 flex justify-between text-sm">
                        <span className="text-muted-foreground">HP</span>
                        <span className="font-medium text-foreground">
                          {character.currentHp} / {character.maxHp}
                        </span>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                        <div
                          className="h-full bg-destructive transition-all"
                          style={{
                            width: `${(character.currentHp / character.maxHp) * 100}%`,
                          }}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <div className="mb-1 flex justify-between text-sm">
                          <span className="text-muted-foreground">Еда</span>
                          <span className="font-medium text-foreground">
                            {character.currentFood}
                          </span>
                        </div>
                        <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                          <div
                            className="h-full bg-primary transition-all"
                            style={{
                              width: `${character.currentFood}%`,
                            }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="mb-1 flex justify-between text-sm">
                          <span className="text-muted-foreground">Вода</span>
                          <span className="font-medium text-foreground">
                            {character.currentWater}
                          </span>
                        </div>
                        <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                          <div
                            className="h-full bg-primary transition-all"
                            style={{
                              width: `${character.currentWater}%`,
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>

                <CardFooter className="flex gap-2">
                  <Button
                    className="flex-1"
                    variant="outline"
                    onClick={() => setLocation(`/characters/${character.id}/inventory`)}
                    data-testid={`button-inventory-${character.id}`}
                  >
                    <Package className="mr-2 h-4 w-4" />
                    Инвентарь
                  </Button>
                  <Button
                    className="flex-1"
                    variant="outline"
                    onClick={() => setLocation(`/world/sphere`)}
                    data-testid={`button-play-${character.id}`}
                  >
                    Играть
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
