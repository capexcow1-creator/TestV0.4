import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-background">
      <Card className="mx-4 w-full max-w-md">
        <CardContent className="pt-6">
          <div className="mb-4 flex gap-2">
            <AlertCircle className="h-8 w-8 text-destructive" />
            <h1 className="font-heading text-2xl uppercase">404</h1>
          </div>

          <p className="mt-4 text-sm text-muted-foreground">
            Страница не найдена. Возможно, вы заблудились в Зоне.
          </p>

          <Link href="/">
            <Button className="mt-6 w-full" data-testid="button-home">
              Вернуться на главную
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
