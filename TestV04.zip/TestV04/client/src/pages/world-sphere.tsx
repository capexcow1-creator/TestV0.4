import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ArrowLeft, Package, Radio, Users, Plus, MessageCircle, Store } from "lucide-react";

const CHARACTER_CLASS_NAMES = {
  loner: "Одиночка",
  mercenary: "Наёмник",
  technician: "Техник",
  medic: "Медик",
  stalker: "Сталкер",
  bandit: "Бандит",
} as const;

type Character = {
  id: number;
  name: string;
  characterClass: keyof typeof CHARACTER_CLASS_NAMES;
  avatarUrl: string | null;
  currentHp: number;
  maxHp: number;
  currentFood: number;
  currentWater: number;
};

export default function WorldSpherePage() {
  const [, setLocation] = useLocation();
  const [selectedCharacterId, setSelectedCharacterId] = useState<number | null>(null);

  const { data: currentUser, isLoading: userLoading } = useQuery({
    queryKey: ["/api/auth/me"],
    retry: false,
  });

  const { data: characters = [], isLoading: charactersLoading } = useQuery<Character[]>({
    queryKey: ["/api/characters"],
    enabled: !!currentUser,
  });

  useEffect(() => {
    if (!userLoading && !currentUser) {
      setLocation("/login");
    }
  }, [userLoading, currentUser, setLocation]);

  useEffect(() => {
    // Load selected character from localStorage
    const saved = localStorage.getItem("selectedCharacterId");
    if (saved) {
      setSelectedCharacterId(parseInt(saved, 10));
    }
  }, []);

  useEffect(() => {
    // Validate selected character exists in current characters list
    if (selectedCharacterId && characters.length > 0) {
      const characterExists = characters.some((c) => c.id === selectedCharacterId);
      if (!characterExists) {
        // Character was deleted or doesn't exist, reset selection
        setSelectedCharacterId(null);
        localStorage.removeItem("selectedCharacterId");
      }
    }
  }, [selectedCharacterId, characters]);

  if (userLoading || charactersLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <p className="text-muted-foreground">Загрузка...</p>
      </div>
    );
  }

  if (!currentUser) {
    return null;
  }

  const selectedCharacter = characters.find((c) => c.id === selectedCharacterId);
  const canCreateCharacter = characters.length < 2;

  const handleSelectCharacter = (characterId: number) => {
    setSelectedCharacterId(characterId);
    localStorage.setItem("selectedCharacterId", characterId.toString());
  };

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="flex items-center justify-between border-b p-4">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/")}
            data-testid="button-back"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="font-heading text-xl uppercase tracking-wider">Сфера</h1>
          </div>
        </div>

        {selectedCharacter && (
          <div className="flex items-center gap-2">
            <Avatar>
              <AvatarFallback className="bg-primary text-primary-foreground font-mono">
                {selectedCharacter.name.substring(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="hidden md:block">
              <p className="text-sm font-medium">{selectedCharacter.name}</p>
              <p className="text-xs text-muted-foreground">
                {CHARACTER_CLASS_NAMES[selectedCharacter.characterClass]}
              </p>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex flex-1 flex-col p-6">
        {!selectedCharacter ? (
          /* Character Selection */
          <div className="mx-auto w-full max-w-4xl space-y-6">
            <div className="text-center">
              <h2 className="mb-2 font-heading text-3xl uppercase tracking-widest">
                Выберите персонажа
              </h2>
              <p className="text-muted-foreground">
                Добро пожаловать в Зону, сталкер
              </p>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              {characters.map((character) => (
                <Card
                  key={character.id}
                  className="hover-elevate cursor-pointer"
                  onClick={() => handleSelectCharacter(character.id)}
                  data-testid={`card-character-${character.id}`}
                >
                  <CardHeader>
                    <div className="flex items-center gap-4">
                      <Avatar className="h-16 w-16">
                        <AvatarFallback className="bg-primary text-primary-foreground text-xl font-mono">
                          {character.name.substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <CardTitle className="font-heading uppercase">
                          {character.name}
                        </CardTitle>
                        <CardDescription>
                          {CHARACTER_CLASS_NAMES[character.characterClass]}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <p className="text-2xl font-bold text-destructive">
                          {character.currentHp}
                        </p>
                        <p className="text-xs text-muted-foreground">HP</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-amber-500">
                          {character.currentFood}%
                        </p>
                        <p className="text-xs text-muted-foreground">Еда</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-blue-500">
                          {character.currentWater}%
                        </p>
                        <p className="text-xs text-muted-foreground">Вода</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {canCreateCharacter && (
                <Card
                  className="hover-elevate cursor-pointer border-dashed"
                  onClick={() => setLocation("/characters/new")}
                  data-testid="card-create-character"
                >
                  <CardHeader className="flex h-full items-center justify-center pb-6">
                    <div className="text-center">
                      <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                        <Plus className="h-8 w-8 text-primary" />
                      </div>
                      <CardTitle className="font-heading uppercase">
                        Создать персонажа
                      </CardTitle>
                    </div>
                  </CardHeader>
                </Card>
              )}
            </div>
          </div>
        ) : (
          /* World Navigation */
          <div className="mx-auto w-full max-w-4xl space-y-6">
            <div className="text-center">
              <h2 className="mb-2 font-heading text-3xl uppercase tracking-widest">
                Мир Сфера
              </h2>
              <p className="text-muted-foreground">
                Персонаж: {selectedCharacter.name}
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {/* Lobby */}
              <Card className="hover-elevate">
                <CardHeader className="text-center">
                  <div className="mx-auto mb-4 flex h-24 w-24 items-center justify-center rounded-full border-4 border-primary bg-card text-primary">
                    <Radio className="h-12 w-12" />
                  </div>
                  <CardTitle className="font-heading uppercase">Лобби</CardTitle>
                  <CardDescription>Подбор предметов</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    className="w-full font-heading uppercase"
                    onClick={() => setLocation("/lobby")}
                    data-testid="button-lobby"
                  >
                    Перейти
                  </Button>
                </CardContent>
              </Card>

              {/* Inventory */}
              <Card className="hover-elevate">
                <CardHeader className="text-center">
                  <div className="mx-auto mb-4 flex h-24 w-24 items-center justify-center rounded-full border-4 border-primary bg-card text-primary">
                    <Package className="h-12 w-12" />
                  </div>
                  <CardTitle className="font-heading uppercase">Инвентарь</CardTitle>
                  <CardDescription>Управление предметами</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    className="w-full font-heading uppercase"
                    onClick={() => setLocation(`/characters/${selectedCharacter.id}/inventory`)}
                    data-testid="button-inventory"
                  >
                    Перейти
                  </Button>
                </CardContent>
              </Card>

              {/* Chat */}
              <Card className="hover-elevate">
                <CardHeader className="text-center">
                  <div className="mx-auto mb-4 flex h-24 w-24 items-center justify-center rounded-full border-4 border-primary bg-card text-primary">
                    <MessageCircle className="h-12 w-12" />
                  </div>
                  <CardTitle className="font-heading uppercase">Чат</CardTitle>
                  <CardDescription>Общение с игроками</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    className="w-full font-heading uppercase"
                    onClick={() => setLocation("/chat")}
                    data-testid="button-chat"
                  >
                    Перейти
                  </Button>
                </CardContent>
              </Card>

              {/* Traders */}
              <Card className="hover-elevate">
                <CardHeader className="text-center">
                  <div className="mx-auto mb-4 flex h-24 w-24 items-center justify-center rounded-full border-4 border-primary bg-card text-primary">
                    <Store className="h-12 w-12" />
                  </div>
                  <CardTitle className="font-heading uppercase">Торговцы</CardTitle>
                  <CardDescription>Покупка предметов</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    className="w-full font-heading uppercase"
                    onClick={() => setLocation("/traders")}
                    data-testid="button-traders"
                  >
                    Перейти
                  </Button>
                </CardContent>
              </Card>

              {/* Characters */}
              <Card className="hover-elevate">
                <CardHeader className="text-center">
                  <div className="mx-auto mb-4 flex h-24 w-24 items-center justify-center rounded-full border-4 border-primary bg-card text-primary">
                    <Users className="h-12 w-12" />
                  </div>
                  <CardTitle className="font-heading uppercase">Персонажи</CardTitle>
                  <CardDescription>Смена персонажа</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    variant="outline"
                    className="w-full font-heading uppercase"
                    onClick={() => setSelectedCharacterId(null)}
                    data-testid="button-change-character"
                  >
                    Сменить
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
