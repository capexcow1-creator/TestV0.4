import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Item } from "@shared/schema";
import {
  Plus,
  Search,
  Edit,
  Trash2,
  Copy,
  ArrowLeft,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function ItemsPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [deleteItemId, setDeleteItemId] = useState<number | null>(null);

  // Fetch all items
  const { data: items = [], isLoading } = useQuery<Item[]>({
    queryKey: ["/api/items"],
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/items/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      toast({
        title: "Предмет удален",
        description: "Предмет успешно удален из базы данных",
      });
      setDeleteItemId(null);
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Не удалось удалить предмет",
      });
    },
  });

  // Duplicate mutation
  const duplicateMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("POST", `/api/items/${id}/duplicate`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      toast({
        title: "Предмет скопирован",
        description: "Создана копия предмета",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Не удалось скопировать предмет",
      });
    },
  });

  // Filter items by search query
  const filteredItems = items.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getRarityColor = (rarity: string) => {
    const colors: Record<string, string> = {
      poor: "text-muted-foreground",
      common: "text-foreground",
      uncommon: "text-green-600 dark:text-green-400",
      rare: "text-blue-600 dark:text-blue-400",
      epic: "text-purple-600 dark:text-purple-400",
      legendary: "text-orange-600 dark:text-orange-400",
      artifact: "text-red-600 dark:text-red-400",
      unique: "text-yellow-600 dark:text-yellow-400",
    };
    return colors[rarity] || "text-foreground";
  };

  const getRarityLabel = (rarity: string) => {
    const labels: Record<string, string> = {
      poor: "Плохое",
      common: "Обычное",
      uncommon: "Необычное",
      rare: "Редкое",
      epic: "Эпическое",
      legendary: "Легендарное",
      artifact: "Артефакт",
      unique: "Уникальное",
    };
    return labels[rarity] || rarity;
  };

  const getCategoryLabel = (category: string) => {
    const labels: Record<string, string> = {
      weapon: "Оружие",
      equipment: "Снаряжение",
      consumable: "Расходник",
    };
    return labels[category] || category;
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/")}
            data-testid="button-back"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">Управление предметами</h1>
            <p className="text-sm text-muted-foreground">
              Создание и редактирование предметов
            </p>
          </div>
        </div>
        <Button
          onClick={() => setLocation("/items/create")}
          data-testid="button-create-item"
        >
          <Plus className="mr-2 h-4 w-4" />
          Создать предмет
        </Button>
      </div>

      <Card className="p-6">
        {/* Search */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Поиск предметов..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="input-search"
            />
          </div>
        </div>

        {/* Items table */}
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Загрузка предметов...</p>
        ) : filteredItems.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-sm text-muted-foreground">
              {searchQuery ? "Предметы не найдены" : "Нет предметов"}
            </p>
          </div>
        ) : (
          <div className="border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Название</TableHead>
                  <TableHead>Категория</TableHead>
                  <TableHead>Редкость</TableHead>
                  <TableHead className="text-center">Размер</TableHead>
                  <TableHead className="text-center">Вес (г)</TableHead>
                  <TableHead className="text-right">Действия</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredItems.map((item) => (
                  <TableRow key={item.id} data-testid={`row-item-${item.id}`}>
                    <TableCell className="font-mono text-sm">
                      {item.id}
                    </TableCell>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {getCategoryLabel(item.category)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className={getRarityColor(item.rarity)}>
                        {getRarityLabel(item.rarity)}
                      </span>
                    </TableCell>
                    <TableCell className="text-center">
                      <span className="font-mono text-sm">
                        {item.width}×{item.height}
                      </span>
                    </TableCell>
                    <TableCell className="text-center">
                      <span className="font-mono text-sm">{item.weight}</span>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setLocation(`/items/${item.id}/edit`)}
                          data-testid={`button-edit-${item.id}`}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => duplicateMutation.mutate(item.id)}
                          disabled={duplicateMutation.isPending}
                          data-testid={`button-duplicate-${item.id}`}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setDeleteItemId(item.id)}
                          data-testid={`button-delete-${item.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>

      {/* Delete confirmation dialog */}
      <AlertDialog open={deleteItemId !== null} onOpenChange={() => setDeleteItemId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Удалить предмет?</AlertDialogTitle>
            <AlertDialogDescription>
              Это действие нельзя отменить. Предмет будет удален из базы данных.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">
              Отмена
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteItemId && deleteMutation.mutate(deleteItemId)}
              data-testid="button-confirm-delete"
            >
              Удалить
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
