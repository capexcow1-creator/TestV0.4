import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Minus, Plus } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const CHARACTER_CLASSES = [
  { value: "loner", label: "Одиночка", description: "Самостоятельный выживальщик" },
  { value: "mercenary", label: "Наёмник", description: "Боевик на службе" },
  { value: "technician", label: "Техник", description: "Мастер ремонта и крафта" },
  { value: "medic", label: "Медик", description: "Лекарь и химик" },
  { value: "stalker", label: "Сталкер", description: "Опытный исследователь Зоны" },
  { value: "bandit", label: "Бандит", description: "Живёт грабежом" },
] as const;

// All 27 characteristics grouped by category
const CHARACTERISTICS = {
  physical: [
    { key: "strength", label: "Сила" },
    { key: "endurance", label: "Выносливость" },
    { key: "agility", label: "Ловкость" },
    { key: "speed", label: "Скорость" },
    { key: "dexterity", label: "Точность" },
    { key: "constitution", label: "Телосложение" },
  ],
  mental: [
    { key: "intelligence", label: "Интеллект" },
    { key: "willpower", label: "Воля" },
    { key: "perception", label: "Восприятие" },
    { key: "charisma", label: "Харизма" },
    { key: "luck", label: "Удача" },
  ],
  combat: [
    { key: "firearmSkill", label: "Огнестрел" },
    { key: "meleeSkill", label: "Ближний бой" },
    { key: "throwingSkill", label: "Метание" },
    { key: "accuracy", label: "Меткость" },
    { key: "criticalChance", label: "Критический урон" },
  ],
  survival: [
    { key: "stealth", label: "Скрытность" },
    { key: "scavenging", label: "Собирательство" },
    { key: "tracking", label: "Выслеживание" },
    { key: "firstAid", label: "Первая помощь" },
    { key: "cooking", label: "Готовка" },
    { key: "radiation", label: "Радиация" },
  ],
  social: [
    { key: "barter", label: "Торговля" },
    { key: "intimidation", label: "Запугивание" },
    { key: "leadership", label: "Лидерство" },
    { key: "persuasion", label: "Убеждение" },
    { key: "deception", label: "Обман" },
  ],
};

const CATEGORY_LABELS = {
  physical: "Физические",
  mental: "Ментальные",
  combat: "Боевые",
  survival: "Выживание",
  social: "Социальные",
};

const MAX_POINTS = 10;

const createCharacterSchema = z.object({
  name: z.string().min(3, "Минимум 3 символа").max(100, "Максимум 100 символов"),
  characterClass: z.enum(["loner", "mercenary", "technician", "medic", "stalker", "bandit"]),
});

type FormData = z.infer<typeof createCharacterSchema>;

type CharacterPayload = FormData & {
  strength: number;
  endurance: number;
  agility: number;
  speed: number;
  dexterity: number;
  constitution: number;
  intelligence: number;
  willpower: number;
  perception: number;
  charisma: number;
  luck: number;
  firearmSkill: number;
  meleeSkill: number;
  throwingSkill: number;
  accuracy: number;
  criticalChance: number;
  stealth: number;
  scavenging: number;
  tracking: number;
  firstAid: number;
  cooking: number;
  radiation: number;
  barter: number;
  intimidation: number;
  leadership: number;
  persuasion: number;
  deception: number;
};

type StatsState = Omit<CharacterPayload, "name" | "characterClass"> & {
  [key: string]: number;
};

export default function CreateCharacterPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [stats, setStats] = useState<StatsState>(() => {
    const initial = {} as StatsState;
    Object.values(CHARACTERISTICS).forEach((category) => {
      category.forEach(({ key }) => {
        (initial as any)[key] = 0;
      });
    });
    return initial;
  });

  const { data: currentUser, isLoading: userLoading } = useQuery({
    queryKey: ["/api/auth/me"],
    retry: false,
  });

  const form = useForm<FormData>({
    resolver: zodResolver(createCharacterSchema),
    defaultValues: {
      name: "",
      characterClass: "loner",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: CharacterPayload) => {
      return apiRequest("POST", "/api/characters", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/characters"] });
      toast({
        title: "Персонаж создан",
        description: "Персонаж успешно создан",
      });
      setLocation("/characters");
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось создать персонажа",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!userLoading && !currentUser) {
      setLocation("/login");
    }
  }, [userLoading, currentUser, setLocation]);

  const totalPoints = Object.values(stats).reduce((sum, val) => sum + val, 0);
  const remainingPoints = MAX_POINTS - totalPoints;

  const adjustStat = (key: string, delta: number) => {
    const newValue = stats[key] + delta;
    if (newValue < 0 || newValue > 10) return;
    if (delta > 0 && remainingPoints <= 0) return;

    setStats((prev) => ({ ...prev, [key]: newValue }));
  };

  const onSubmit = (data: FormData) => {
    if (totalPoints !== MAX_POINTS) {
      toast({
        title: "Ошибка",
        description: `Необходимо распределить все ${MAX_POINTS} поинтов`,
        variant: "destructive",
      });
      return;
    }

    createMutation.mutate({ ...data, ...stats });
  };

  if (userLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <p className="text-muted-foreground">Загрузка...</p>
      </div>
    );
  }

  if (!currentUser) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-4xl space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/characters")}
            data-testid="button-back"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-foreground">
              Создать персонажа
            </h1>
            <p className="text-sm text-muted-foreground">
              Распределите {MAX_POINTS} поинтов по характеристикам
            </p>
          </div>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Basic Info */}
            <Card>
              <CardHeader>
                <CardTitle>Основная информация</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Имя персонажа</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="Введите имя"
                          data-testid="input-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="characterClass"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Класс</FormLabel>
                      <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3">
                        {CHARACTER_CLASSES.map((cls) => (
                          <Card
                            key={cls.value}
                            className={`cursor-pointer transition-all hover-elevate ${
                              field.value === cls.value
                                ? "ring-2 ring-primary"
                                : ""
                            }`}
                            onClick={() => field.onChange(cls.value)}
                            data-testid={`button-class-${cls.value}`}
                          >
                            <CardHeader className="space-y-1 p-4">
                              <CardTitle className="text-base">
                                {cls.label}
                              </CardTitle>
                              <CardDescription className="text-xs">
                                {cls.description}
                              </CardDescription>
                            </CardHeader>
                          </Card>
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Characteristics */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Характеристики</CardTitle>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">
                      Осталось поинтов
                    </p>
                    <p
                      className={`text-2xl font-bold ${
                        remainingPoints === 0
                          ? "text-primary"
                          : "text-foreground"
                      }`}
                      data-testid="text-remaining-points"
                    >
                      {remainingPoints}
                    </p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="physical" className="w-full">
                  <TabsList className="grid w-full grid-cols-5">
                    {Object.entries(CATEGORY_LABELS).map(([key, label]) => (
                      <TabsTrigger
                        key={key}
                        value={key}
                        data-testid={`tab-${key}`}
                      >
                        {label}
                      </TabsTrigger>
                    ))}
                  </TabsList>

                  {Object.entries(CHARACTERISTICS).map(([category, items]) => (
                    <TabsContent
                      key={category}
                      value={category}
                      className="space-y-3"
                    >
                      {items.map(({ key, label }) => (
                        <div
                          key={key}
                          className="flex items-center justify-between rounded-md border border-border p-3"
                          data-testid={`stat-${key}`}
                        >
                          <span className="font-medium text-foreground">
                            {label}
                          </span>
                          <div className="flex items-center gap-3">
                            <Button
                              type="button"
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => adjustStat(key, -1)}
                              disabled={stats[key] === 0}
                              data-testid={`button-decrease-${key}`}
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                            <span
                              className="w-8 text-center text-lg font-bold text-foreground"
                              data-testid={`value-${key}`}
                            >
                              {stats[key]}
                            </span>
                            <Button
                              type="button"
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => adjustStat(key, 1)}
                              disabled={
                                stats[key] >= 10 || remainingPoints <= 0
                              }
                              data-testid={`button-increase-${key}`}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </TabsContent>
                  ))}
                </Tabs>
              </CardContent>
            </Card>

            {/* Submit */}
            <div className="flex gap-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setLocation("/characters")}
                className="flex-1"
                data-testid="button-cancel"
              >
                Отмена
              </Button>
              <Button
                type="submit"
                className="flex-1"
                disabled={
                  createMutation.isPending || remainingPoints !== 0
                }
                data-testid="button-submit"
              >
                {createMutation.isPending
                  ? "Создание..."
                  : "Создать персонажа"}
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}
