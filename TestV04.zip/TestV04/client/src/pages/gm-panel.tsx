import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { ArrowLeft, Power, Plus, Edit, Trash2, Package } from "lucide-react";
import { Link } from "wouter";

type Trader = {
  id: number;
  name: string;
  description: string | null;
  isOpen: boolean;
};

type Item = {
  id: number;
  name: string;
  rarity: string;
};

type TraderItemDetail = {
  id: number;
  traderId: number;
  itemId: number;
  stock: number;
  priceGold: number;
  priceSilver: number;
  priceCores: number;
  priceSovietMedal1: number;
  priceSovietMedal2: number;
  priceSovietMedal3: number;
  priceReichMark1: number;
  priceReichMark2: number;
  priceReichMark3: number;
  item: Item;
};

export default function GmPanelPage() {
  const { toast } = useToast();
  const [selectedTrader, setSelectedTrader] = useState<number | null>(null);
  const [showAddItemDialog, setShowAddItemDialog] = useState(false);
  const [showEditStockDialog, setShowEditStockDialog] = useState(false);
  const [showSpawnDialog, setShowSpawnDialog] = useState(false);
  const [editingItem, setEditingItem] = useState<TraderItemDetail | null>(null);

  // Check user role
  const { data: currentUser } = useQuery<{ id: string; username: string; role: string }>({
    queryKey: ["/api/auth/me"],
  });

  // Redirect non-GM/admin users
  if (currentUser && currentUser.role !== "admin" && currentUser.role !== "gm") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="font-heading">Доступ запрещён</CardTitle>
            <CardDescription>У вас нет прав для доступа к GM Panel</CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/home">
              <Button className="w-full">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Вернуться на главную
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // Form state for adding items
  const [newItemId, setNewItemId] = useState("");
  const [newStock, setNewStock] = useState("10");
  const [newPriceGold, setNewPriceGold] = useState("0");
  const [newPriceSilver, setNewPriceSilver] = useState("0");
  const [newPriceCores, setNewPriceCores] = useState("0");
  
  // Form state for spawning lobby items
  const [spawnItemId, setSpawnItemId] = useState("");
  const [spawnWorld, setSpawnWorld] = useState("sphere");
  const [spawnGridX, setSpawnGridX] = useState("0");
  const [spawnGridY, setSpawnGridY] = useState("0");
  const [spawnStackCount, setSpawnStackCount] = useState("1");

  // Fetch traders
  const { data: traders, isLoading: tradersLoading } = useQuery<Trader[]>({
    queryKey: ["/api/traders"],
  });

  // Fetch all items
  const { data: items, isLoading: itemsLoading } = useQuery<Item[]>({
    queryKey: ["/api/items"],
  });

  // Fetch trader items
  const { data: traderItems, isLoading: traderItemsLoading } = useQuery<TraderItemDetail[]>({
    queryKey: ["/api/traders", selectedTrader, "items"],
    enabled: !!selectedTrader,
  });

  // Toggle trader status
  const toggleStatusMutation = useMutation({
    mutationFn: async (traderId: number) => {
      return await apiRequest("PATCH", `/api/gm/traders/${traderId}/status`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/traders"] });
      toast({
        title: "Статус изменён",
        description: "Статус торговца успешно изменён",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось изменить статус торговца",
        variant: "destructive",
      });
    },
  });

  // Update stock
  const updateStockMutation = useMutation({
    mutationFn: async ({ itemId, stock }: { itemId: number; stock: number }) => {
      return await apiRequest("PATCH", `/api/gm/traders/${selectedTrader}/items/${itemId}/stock`, {
        stock,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/traders", selectedTrader, "items"] });
      setShowEditStockDialog(false);
      setEditingItem(null);
      toast({
        title: "Stock обновлён",
        description: "Количество товара успешно обновлено",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить stock",
        variant: "destructive",
      });
    },
  });

  // Add item
  const addItemMutation = useMutation({
    mutationFn: async (data: {
      itemId: number;
      stock: number;
      priceGold?: number;
      priceSilver?: number;
      priceCores?: number;
    }) => {
      return await apiRequest("POST", `/api/gm/traders/${selectedTrader}/items`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/traders", selectedTrader, "items"] });
      setShowAddItemDialog(false);
      resetAddForm();
      toast({
        title: "Товар добавлен",
        description: "Товар успешно добавлен к торговцу",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось добавить товар",
        variant: "destructive",
      });
    },
  });

  // Delete item
  const deleteItemMutation = useMutation({
    mutationFn: async (itemId: number) => {
      return await apiRequest("DELETE", `/api/gm/traders/${selectedTrader}/items/${itemId}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/traders", selectedTrader, "items"] });
      toast({
        title: "Товар удалён",
        description: "Товар успешно удалён у торговца",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось удалить товар",
        variant: "destructive",
      });
    },
  });

  // Spawn lobby item
  const spawnLobbyItemMutation = useMutation({
    mutationFn: async (data: {
      itemId: number;
      worldName: string;
      gridX: number;
      gridY: number;
      stackCount: number;
    }) => {
      return await apiRequest("POST", "/api/lobby/spawn", data);
    },
    onSuccess: () => {
      setShowSpawnDialog(false);
      resetSpawnForm();
      toast({
        title: "Предмет создан",
        description: "Предмет успешно создан в лобби",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать предмет",
        variant: "destructive",
      });
    },
  });

  const resetAddForm = () => {
    setNewItemId("");
    setNewStock("10");
    setNewPriceGold("0");
    setNewPriceSilver("0");
    setNewPriceCores("0");
  };

  const resetSpawnForm = () => {
    setSpawnItemId("");
    setSpawnWorld("sphere");
    setSpawnGridX("0");
    setSpawnGridY("0");
    setSpawnStackCount("1");
  };

  const handleAddItem = () => {
    const itemId = parseInt(newItemId);
    const stock = parseInt(newStock);
    const priceGold = Math.max(0, parseInt(newPriceGold) || 0);
    const priceSilver = Math.max(0, parseInt(newPriceSilver) || 0);
    const priceCores = Math.max(0, parseInt(newPriceCores) || 0);

    if (!itemId || !stock || stock < 0) {
      toast({
        title: "Ошибка",
        description: "Заполните все обязательные поля корректными значениями",
        variant: "destructive",
      });
      return;
    }

    addItemMutation.mutate({ itemId, stock, priceGold, priceSilver, priceCores });
  };

  const handleEditStock = () => {
    if (!editingItem) return;
    
    const stock = parseInt(newStock);
    if (isNaN(stock) || stock < 0) {
      toast({
        title: "Ошибка",
        description: "Некорректное значение stock",
        variant: "destructive",
      });
      return;
    }

    updateStockMutation.mutate({ itemId: editingItem.id, stock });
  };

  const openEditStockDialog = (item: TraderItemDetail) => {
    setEditingItem(item);
    setNewStock(item.stock.toString());
    setShowEditStockDialog(true);
  };

  const handleSpawnItem = () => {
    const itemId = parseInt(spawnItemId);
    const gridX = parseInt(spawnGridX);
    const gridY = parseInt(spawnGridY);
    const stackCount = Math.max(1, parseInt(spawnStackCount) || 1);

    if (!itemId || isNaN(gridX) || isNaN(gridY) || gridX < 0 || gridX >= 10 || gridY < 0 || gridY >= 10) {
      toast({
        title: "Ошибка",
        description: "Заполните все поля корректно (grid: 0-9)",
        variant: "destructive",
      });
      return;
    }

    spawnLobbyItemMutation.mutate({ itemId, worldName: spawnWorld, gridX, gridY, stackCount });
  };

  if (tradersLoading) {
    return <div className="p-8 text-center">Загрузка...</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-4 max-w-6xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Link href="/home">
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold font-heading">Панель ГМ</h1>
            <p className="text-muted-foreground">Управление торговцами и лобби</p>
          </div>
        </div>

        {/* Traders List */}
        <div className="grid gap-4 mb-6">
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Торговцы</CardTitle>
              <CardDescription>Управление статусом и товарами торговцев</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3">
                {traders?.map((trader) => (
                  <div
                    key={trader.id}
                    className="flex items-center justify-between p-4 border rounded-md hover-elevate"
                    data-testid={`trader-card-${trader.id}`}
                  >
                    <div className="flex items-center gap-3">
                      <Package className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-heading font-semibold">{trader.name}</h3>
                          <Badge variant={trader.isOpen ? "default" : "secondary"} data-testid={`trader-status-${trader.id}`}>
                            {trader.isOpen ? "Открыт" : "Закрыт"}
                          </Badge>
                        </div>
                        {trader.description && (
                          <p className="text-sm text-muted-foreground">{trader.description}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toggleStatusMutation.mutate(trader.id)}
                        disabled={toggleStatusMutation.isPending}
                        data-testid={`button-toggle-${trader.id}`}
                      >
                        <Power className="h-4 w-4 mr-1" />
                        {trader.isOpen ? "Закрыть" : "Открыть"}
                      </Button>
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => setSelectedTrader(trader.id)}
                        data-testid={`button-manage-${trader.id}`}
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        Управлять
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Trader Items Management */}
        {selectedTrader && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="font-heading">
                    Товары: {traders?.find((t) => t.id === selectedTrader)?.name}
                  </CardTitle>
                  <CardDescription>Управление товарами торговца</CardDescription>
                </div>
                <Button
                  onClick={() => setShowAddItemDialog(true)}
                  data-testid="button-add-item"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Добавить товар
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {traderItemsLoading ? (
                <p className="text-center text-muted-foreground">Загрузка...</p>
              ) : traderItems && traderItems.length > 0 ? (
                <div className="grid gap-2">
                  {traderItems.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between p-3 border rounded-md"
                      data-testid={`trader-item-${item.id}`}
                    >
                      <div className="flex items-center gap-3">
                        <Badge variant="outline">{item.item.rarity}</Badge>
                        <div>
                          <h4 className="font-semibold">{item.item.name}</h4>
                          <p className="text-sm text-muted-foreground">
                            Stock: <span className="font-mono" data-testid={`stock-${item.id}`}>{item.stock}</span> | 
                            Золото: {item.priceGold} | Серебро: {item.priceSilver} | Ядра: {item.priceCores}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openEditStockDialog(item)}
                          data-testid={`button-edit-stock-${item.id}`}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => deleteItemMutation.mutate(item.id)}
                          disabled={deleteItemMutation.isPending}
                          data-testid={`button-delete-item-${item.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-muted-foreground" data-testid="no-items-message">
                  Нет товаров у этого торговца
                </p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Spawn Lobby Item Section */}
        <div className="grid gap-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="font-heading">Спавн предметов в лобби</CardTitle>
                  <CardDescription>Создание предметов в игровом лобби</CardDescription>
                </div>
                <Button
                  onClick={() => setShowSpawnDialog(true)}
                  data-testid="button-spawn-item"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Создать предмет
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Создавайте предметы напрямую в лобби. Укажите предмет, мир (Сфера/Стол 2), и позицию на сетке 10x10.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Add Item Dialog */}
      <Dialog open={showAddItemDialog} onOpenChange={setShowAddItemDialog}>
        <DialogContent data-testid="dialog-add-item">
          <DialogHeader>
            <DialogTitle className="font-heading">Добавить товар</DialogTitle>
            <DialogDescription>Добавьте новый товар к торговцу</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="item-select">Предмет *</Label>
              <Select value={newItemId} onValueChange={setNewItemId}>
                <SelectTrigger id="item-select" data-testid="select-item">
                  <SelectValue placeholder="Выберите предмет" />
                </SelectTrigger>
                <SelectContent>
                  {itemsLoading ? (
                    <SelectItem value="loading">Загрузка...</SelectItem>
                  ) : (
                    items?.map((item) => (
                      <SelectItem key={item.id} value={item.id.toString()}>
                        {item.name} ({item.rarity})
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="stock">Количество (stock) *</Label>
              <Input
                id="stock"
                type="number"
                value={newStock}
                onChange={(e) => setNewStock(e.target.value)}
                data-testid="input-stock"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="price-gold">Цена: Золото</Label>
              <Input
                id="price-gold"
                type="number"
                value={newPriceGold}
                onChange={(e) => setNewPriceGold(e.target.value)}
                data-testid="input-price-gold"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="price-silver">Цена: Серебро</Label>
              <Input
                id="price-silver"
                type="number"
                value={newPriceSilver}
                onChange={(e) => setNewPriceSilver(e.target.value)}
                data-testid="input-price-silver"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="price-cores">Цена: Ядра</Label>
              <Input
                id="price-cores"
                type="number"
                value={newPriceCores}
                onChange={(e) => setNewPriceCores(e.target.value)}
                data-testid="input-price-cores"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddItemDialog(false)} data-testid="button-cancel-add">
              Отмена
            </Button>
            <Button
              onClick={handleAddItem}
              disabled={addItemMutation.isPending}
              data-testid="button-confirm-add"
            >
              Добавить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Stock Dialog */}
      <Dialog open={showEditStockDialog} onOpenChange={setShowEditStockDialog}>
        <DialogContent data-testid="dialog-edit-stock">
          <DialogHeader>
            <DialogTitle className="font-heading">Изменить количество</DialogTitle>
            <DialogDescription>
              {editingItem && `Товар: ${editingItem.item.name}`}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-stock">Новое количество</Label>
              <Input
                id="edit-stock"
                type="number"
                value={newStock}
                onChange={(e) => setNewStock(e.target.value)}
                data-testid="input-edit-stock"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowEditStockDialog(false);
                setEditingItem(null);
              }}
              data-testid="button-cancel-edit"
            >
              Отмена
            </Button>
            <Button
              onClick={handleEditStock}
              disabled={updateStockMutation.isPending}
              data-testid="button-confirm-edit"
            >
              Сохранить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Spawn Lobby Item Dialog */}
      <Dialog open={showSpawnDialog} onOpenChange={setShowSpawnDialog}>
        <DialogContent data-testid="dialog-spawn-item">
          <DialogHeader>
            <DialogTitle className="font-heading">Создать предмет в лобби</DialogTitle>
            <DialogDescription>Добавьте предмет в игровое лобби</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="spawn-item-select">Предмет *</Label>
              <Select value={spawnItemId} onValueChange={setSpawnItemId}>
                <SelectTrigger id="spawn-item-select" data-testid="select-spawn-item">
                  <SelectValue placeholder="Выберите предмет" />
                </SelectTrigger>
                <SelectContent>
                  {itemsLoading ? (
                    <SelectItem value="loading">Загрузка...</SelectItem>
                  ) : (
                    items?.map((item) => (
                      <SelectItem key={item.id} value={item.id.toString()}>
                        {item.name} ({item.rarity})
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="spawn-world">Мир *</Label>
              <Select value={spawnWorld} onValueChange={setSpawnWorld}>
                <SelectTrigger id="spawn-world" data-testid="select-spawn-world">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sphere">Сфера</SelectItem>
                  <SelectItem value="table2">Стол 2</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="spawn-grid-x">Grid X (0-9) *</Label>
                <Input
                  id="spawn-grid-x"
                  type="number"
                  min="0"
                  max="9"
                  value={spawnGridX}
                  onChange={(e) => setSpawnGridX(e.target.value)}
                  data-testid="input-spawn-grid-x"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="spawn-grid-y">Grid Y (0-9) *</Label>
                <Input
                  id="spawn-grid-y"
                  type="number"
                  min="0"
                  max="9"
                  value={spawnGridY}
                  onChange={(e) => setSpawnGridY(e.target.value)}
                  data-testid="input-spawn-grid-y"
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="spawn-stack">Количество (stack)</Label>
              <Input
                id="spawn-stack"
                type="number"
                min="1"
                value={spawnStackCount}
                onChange={(e) => setSpawnStackCount(e.target.value)}
                data-testid="input-spawn-stack"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSpawnDialog(false)} data-testid="button-cancel-spawn">
              Отмена
            </Button>
            <Button
              onClick={handleSpawnItem}
              disabled={spawnLobbyItemMutation.isPending}
              data-testid="button-confirm-spawn"
            >
              Создать
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
