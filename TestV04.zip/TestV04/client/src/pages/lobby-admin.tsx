import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Item } from "@shared/schema";
import { ArrowLeft, Package } from "lucide-react";

const LOBBY_GRID_SIZE = 10;

export default function LobbyAdminPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const [selectedItemId, setSelectedItemId] = useState<number | null>(null);
  const [worldName, setWorldName] = useState<string>("sphere");
  const [gridX, setGridX] = useState<string>("0");
  const [gridY, setGridY] = useState<string>("0");
  const [stackCount, setStackCount] = useState<string>("1");

  // Fetch items
  const { data: items = [] } = useQuery<Item[]>({
    queryKey: ["/api/items"],
  });

  // Spawn mutation
  const spawnMutation = useMutation({
    mutationFn: async (data: {
      itemId: number;
      worldName: string;
      gridX: number;
      gridY: number;
      stackCount: number;
    }) => {
      return await apiRequest("POST", "/api/lobby/spawn", data);
    },
    onSuccess: () => {
      toast({
        title: "Предмет заспавнен",
        description: "Предмет появился в лобби",
      });
      // Reset form
      setGridX("0");
      setGridY("0");
      setStackCount("1");
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось заспавнить предмет",
        variant: "destructive",
      });
    },
  });

  // Handle spawn
  const handleSpawn = () => {
    if (!selectedItemId) {
      toast({
        title: "Выберите предмет",
        description: "Сначала выберите предмет для спавна",
        variant: "destructive",
      });
      return;
    }

    const x = parseInt(gridX);
    const y = parseInt(gridY);
    const count = parseInt(stackCount);

    if (isNaN(x) || isNaN(y) || isNaN(count)) {
      toast({
        title: "Неверные данные",
        description: "Проверьте правильность введенных данных",
        variant: "destructive",
      });
      return;
    }

    if (x < 0 || x >= LOBBY_GRID_SIZE || y < 0 || y >= LOBBY_GRID_SIZE) {
      toast({
        title: "Неверная позиция",
        description: `Позиция должна быть от 0 до ${LOBBY_GRID_SIZE - 1}`,
        variant: "destructive",
      });
      return;
    }

    if (count < 1) {
      toast({
        title: "Неверное количество",
        description: "Количество должно быть больше 0",
        variant: "destructive",
      });
      return;
    }

    spawnMutation.mutate({
      itemId: selectedItemId,
      worldName,
      gridX: x,
      gridY: y,
      stackCount: count,
    });
  };

  const selectedItem = items.find((item) => item.id === selectedItemId);

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="icon" onClick={() => navigate("/lobby")} data-testid="button-back">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">Спавн предметов в лобби</h1>
            <p className="text-muted-foreground">Добавьте предметы для игроков</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Spawn form */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Настройки спавна</h2>

            <div className="space-y-4">
              {/* Item selection */}
              <div>
                <Label htmlFor="item-select">Предмет</Label>
                <Select
                  value={selectedItemId?.toString() || ""}
                  onValueChange={(value) => setSelectedItemId(parseInt(value))}
                >
                  <SelectTrigger id="item-select" data-testid="select-item">
                    <SelectValue placeholder="Выберите предмет" />
                  </SelectTrigger>
                  <SelectContent>
                    {items.map((item) => (
                      <SelectItem key={item.id} value={item.id.toString()}>
                        {item.name} ({item.category})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* World selection */}
              <div>
                <Label htmlFor="world-select">Мир</Label>
                <Select value={worldName} onValueChange={setWorldName}>
                  <SelectTrigger id="world-select" data-testid="select-world">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sphere">Sphere</SelectItem>
                    <SelectItem value="table2">Table 2</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Grid position */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="grid-x">Позиция X (0-9)</Label>
                  <Input
                    id="grid-x"
                    type="number"
                    min="0"
                    max={LOBBY_GRID_SIZE - 1}
                    value={gridX}
                    onChange={(e) => setGridX(e.target.value)}
                    data-testid="input-grid-x"
                  />
                </div>
                <div>
                  <Label htmlFor="grid-y">Позиция Y (0-9)</Label>
                  <Input
                    id="grid-y"
                    type="number"
                    min="0"
                    max={LOBBY_GRID_SIZE - 1}
                    value={gridY}
                    onChange={(e) => setGridY(e.target.value)}
                    data-testid="input-grid-y"
                  />
                </div>
              </div>

              {/* Stack count */}
              <div>
                <Label htmlFor="stack-count">Количество</Label>
                <Input
                  id="stack-count"
                  type="number"
                  min="1"
                  value={stackCount}
                  onChange={(e) => setStackCount(e.target.value)}
                  data-testid="input-stack-count"
                />
              </div>

              {/* Spawn button */}
              <Button
                className="w-full"
                onClick={handleSpawn}
                disabled={spawnMutation.isPending || !selectedItemId}
                data-testid="button-spawn"
              >
                <Package className="h-5 w-5 mr-2" />
                {spawnMutation.isPending ? "Спавн..." : "Заспавнить предмет"}
              </Button>
            </div>
          </Card>

          {/* Item preview */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Предпросмотр</h2>

            {selectedItem ? (
              <div className="space-y-3">
                <div className="flex items-center gap-4">
                  {selectedItem.iconUrl ? (
                    <img
                      src={selectedItem.iconUrl}
                      alt={selectedItem.name}
                      className="w-16 h-16 object-contain rounded border border-border"
                    />
                  ) : (
                    <div className="w-16 h-16 bg-card border border-border rounded flex items-center justify-center">
                      <Package className="h-8 w-8 text-muted-foreground" />
                    </div>
                  )}
                  <div>
                    <h3 className="text-lg font-semibold">{selectedItem.name}</h3>
                    <p className="text-sm text-muted-foreground">{selectedItem.category}</p>
                  </div>
                </div>

                {selectedItem.description && (
                  <div>
                    <Label>Описание</Label>
                    <p className="text-sm text-muted-foreground">{selectedItem.description}</p>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <Label>Редкость</Label>
                    <p className="text-muted-foreground capitalize">{selectedItem.rarity}</p>
                  </div>
                  <div>
                    <Label>Вес</Label>
                    <p className="text-muted-foreground">{selectedItem.weight} кг</p>
                  </div>
                  <div>
                    <Label>Размер</Label>
                    <p className="text-muted-foreground">
                      {selectedItem.width} × {selectedItem.height}
                    </p>
                  </div>
                  {selectedItem.durability !== null && (
                    <div>
                      <Label>Прочность</Label>
                      <p className="text-muted-foreground">
                        {selectedItem.durability} / {selectedItem.maxDurability}
                      </p>
                    </div>
                  )}
                </div>

                <div className="pt-4 border-t border-border">
                  <Label>Позиция в лобби</Label>
                  <p className="text-muted-foreground">
                    Мир: <span className="font-medium">{worldName}</span>
                    {" • "}
                    Координаты: <span className="font-medium">({gridX}, {gridY})</span>
                    {" • "}
                    Количество: <span className="font-medium">{stackCount}</span>
                  </p>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-64 text-muted-foreground">
                Выберите предмет для предпросмотра
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
