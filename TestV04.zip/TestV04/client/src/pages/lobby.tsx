import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { LobbyItem, Item, Character } from "@shared/schema";
import { ArrowLeft, Package } from "lucide-react";

const GRID_CELL_SIZE = 50; // pixels
const LOBBY_GRID_SIZE = 10; // 10x10 grid

interface LobbyItemWithItem extends LobbyItem {
  item?: Item;
}

export default function LobbyPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [lobbyItems, setLobbyItems] = useState<LobbyItem[]>([]);
  const [ws, setWs] = useState<WebSocket | null>(null);
  const [selectedCharacterId, setSelectedCharacterId] = useState<number | null>(null);
  const worldName = "sphere"; // TODO: get from user/character selection

  // Fetch current user
  const { data: currentUser } = useQuery<any>({
    queryKey: ["/api/auth/me"],
  });

  // Fetch characters
  const { data: characters = [] } = useQuery<Character[]>({
    queryKey: ["/api/characters"],
    enabled: !!currentUser,
  });

  // Fetch all items for display
  const { data: allItems = [] } = useQuery<Item[]>({
    queryKey: ["/api/items"],
  });

  // Load selected character from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("selectedCharacterId");
    if (saved) {
      setSelectedCharacterId(parseInt(saved, 10));
    }
  }, []);

  // WebSocket connection
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      console.log("WebSocket connected");
      // Join world
      socket.send(JSON.stringify({ event: "join_world", data: { worldName } }));
    };

    socket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        console.log("WebSocket message:", message);

        switch (message.event) {
          case "lobby:list":
            setLobbyItems(message.data);
            break;
          case "lobby:spawned":
            setLobbyItems((prev) => [...prev, message.data]);
            toast({
              title: "Новый предмет!",
              description: "В лобби появился новый предмет",
            });
            break;
          case "lobby:picked_up":
            setLobbyItems((prev) => prev.filter((item) => item.id !== message.data.id));
            break;
        }
      } catch (error) {
        console.error("WebSocket message parse error:", error);
      }
    };

    socket.onerror = (error) => {
      console.error("WebSocket error:", error);
      toast({
        title: "Ошибка подключения",
        description: "Не удалось подключиться к серверу",
        variant: "destructive",
      });
    };

    socket.onclose = () => {
      console.log("WebSocket disconnected");
    };

    setWs(socket);

    return () => {
      socket.send(JSON.stringify({ event: "leave_world" }));
      socket.close();
    };
  }, [worldName, toast]);

  // Pickup mutation
  const pickupMutation = useMutation({
    mutationFn: async (data: { lobbyItemId: number; characterId: number }) => {
      return await apiRequest("POST", `/api/lobby/pickup/${data.lobbyItemId}`, {
        characterId: data.characterId,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/characters"] });
      toast({
        title: "Предмет подобран",
        description: "Предмет добавлен в инвентарь",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось подобрать предмет",
        variant: "destructive",
      });
    },
  });

  // Handle pickup
  const handlePickup = (lobbyItemId: number) => {
    if (!selectedCharacterId) {
      toast({
        title: "Выберите персонажа",
        description: "Сначала выберите персонажа для подбора предмета",
        variant: "destructive",
      });
      return;
    }

    pickupMutation.mutate({ lobbyItemId, characterId: selectedCharacterId });
  };

  // Get item details for lobby item
  const getLobbyItemWithDetails = (lobbyItem: LobbyItem): LobbyItemWithItem => {
    const item = allItems.find((i) => i.id === lobbyItem.itemId);
    return { ...lobbyItem, item };
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/world/sphere")} data-testid="button-back">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold">Лобби: {worldName}</h1>
              <p className="text-muted-foreground">Подбирайте предметы в реальном времени</p>
            </div>
          </div>
          {currentUser?.role === "admin" && (
            <Button variant="default" onClick={() => navigate("/lobby/admin")} data-testid="button-admin-spawn">
              <Package className="h-5 w-5 mr-2" />
              Спавн предметов
            </Button>
          )}
        </div>

        {/* Character selection */}
        <Card className="p-4 mb-6">
          <h2 className="text-lg font-semibold mb-3">Выберите персонажа</h2>
          <div className="flex gap-2 flex-wrap">
            {characters.map((char) => (
              <Button
                key={char.id}
                variant={selectedCharacterId === char.id ? "default" : "outline"}
                onClick={() => {
                  setSelectedCharacterId(char.id);
                  localStorage.setItem("selectedCharacterId", char.id.toString());
                }}
                data-testid={`button-select-character-${char.id}`}
              >
                {char.name} ({char.characterClass})
              </Button>
            ))}
          </div>
        </Card>

        {/* Lobby grid */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Предметы в лобби</h2>
            <div className="text-sm text-muted-foreground">
              Предметов: {lobbyItems.length}
            </div>
          </div>

          {/* 10x10 Grid */}
          <div
            className="relative border-2 border-border mx-auto"
            style={{
              width: LOBBY_GRID_SIZE * GRID_CELL_SIZE,
              height: LOBBY_GRID_SIZE * GRID_CELL_SIZE,
            }}
          >
            {/* Grid cells */}
            {Array.from({ length: LOBBY_GRID_SIZE }).map((_, y) =>
              Array.from({ length: LOBBY_GRID_SIZE }).map((_, x) => (
                <div
                  key={`${x}-${y}`}
                  className="absolute border border-border/30 bg-card/20"
                  style={{
                    left: x * GRID_CELL_SIZE,
                    top: y * GRID_CELL_SIZE,
                    width: GRID_CELL_SIZE,
                    height: GRID_CELL_SIZE,
                  }}
                  data-testid={`lobby-cell-${x}-${y}`}
                />
              ))
            )}

            {/* Lobby items */}
            {lobbyItems.map((lobbyItem) => {
              const itemWithDetails = getLobbyItemWithDetails(lobbyItem);
              const item = itemWithDetails.item;
              const isLocked = !!lobbyItem.lockedBy;

              return (
                <div
                  key={lobbyItem.id}
                  className={`absolute flex items-center justify-center cursor-pointer ${
                    isLocked ? "opacity-50" : "hover-elevate active-elevate-2"
                  }`}
                  style={{
                    left: lobbyItem.gridX * GRID_CELL_SIZE,
                    top: lobbyItem.gridY * GRID_CELL_SIZE,
                    width: GRID_CELL_SIZE,
                    height: GRID_CELL_SIZE,
                  }}
                  onClick={() => !isLocked && handlePickup(lobbyItem.id)}
                  data-testid={`lobby-item-${lobbyItem.id}`}
                >
                  <div className="bg-card border-2 border-primary rounded-md p-2 w-full h-full flex flex-col items-center justify-center text-xs">
                    {item ? (
                      <>
                        <Package className="h-5 w-5 mb-1" />
                        <span className="font-medium text-center line-clamp-1">{item.name}</span>
                        {lobbyItem.stackCount > 1 && (
                          <span className="text-muted-foreground">x{lobbyItem.stackCount}</span>
                        )}
                        {isLocked && (
                          <span className="text-destructive text-[10px]">Занято</span>
                        )}
                      </>
                    ) : (
                      <Package className="h-5 w-5" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </div>
  );
}
