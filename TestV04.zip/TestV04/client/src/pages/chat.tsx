import { useEffect, useState, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { ChatMessage } from "@shared/schema";
import { ArrowLeft, Send, Dice5 } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

export default function ChatPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Get worldName from localStorage (set in world selection)
  const worldName = "sphere"; // TODO: integrate with world selection state

  // Fetch current user
  const { data: currentUser } = useQuery<any>({
    queryKey: ["/api/auth/me"],
  });

  // Scroll to bottom when messages change
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // WebSocket connection
  useEffect(() => {
    if (!currentUser) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      console.log("Chat WebSocket connected");
      // Join world and request history
      socket.send(JSON.stringify({ event: "join_world", data: { worldName } }));
      socket.send(JSON.stringify({ event: "chat:request_history" }));
    };

    socket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        console.log("Chat WebSocket message:", message);

        switch (message.event) {
          case "chat:history":
            setMessages(message.data);
            break;
          case "chat:message":
            setMessages((prev) => [...prev, message.data]);
            break;
        }
      } catch (error) {
        console.error("WebSocket message parse error:", error);
      }
    };

    socket.onclose = () => {
      console.log("Chat WebSocket disconnected");
    };

    return () => {
      // Guard against sending when socket is closing/closed
      if (socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ event: "leave_world" }));
      }
      socket.close();
    };
  }, [currentUser, worldName]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!inputValue.trim() || isSending) return;

    try {
      setIsSending(true);
      await apiRequest("POST", "/api/chat/messages", {
        worldName,
        message: inputValue.trim(),
      });
      setInputValue("");
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось отправить сообщение",
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };

  const renderMessage = (msg: ChatMessage) => {
    const isOwnMessage = msg.userId === currentUser?.id;
    const timestamp = format(new Date(msg.createdAt), "HH:mm", { locale: ru });

    if (msg.isDiceRoll) {
      return (
        <div
          key={msg.id}
          className="flex items-start gap-3 p-3 rounded-md bg-accent/20 border border-accent"
          data-testid={`chat-message-${msg.id}`}
        >
          <Dice5 className="w-5 h-5 text-accent mt-1 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="flex items-baseline gap-2 mb-1">
              <span className="font-medium text-sm" data-testid={`chat-username-${msg.id}`}>
                {msg.username}
              </span>
              <span className="text-xs text-muted-foreground">{timestamp}</span>
            </div>
            <div className="text-sm">
              <div className="text-muted-foreground mb-1">{msg.message}</div>
              <div className="font-mono font-bold text-accent" data-testid={`chat-dice-result-${msg.id}`}>
                {msg.diceResult}
              </div>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div
        key={msg.id}
        className={`flex ${isOwnMessage ? "justify-end" : "justify-start"}`}
        data-testid={`chat-message-${msg.id}`}
      >
        <div
          className={`max-w-[70%] p-3 rounded-lg ${
            isOwnMessage
              ? "bg-primary text-primary-foreground"
              : "bg-card border border-border"
          }`}
        >
          <div className="flex items-baseline gap-2 mb-1">
            <span className="font-medium text-sm" data-testid={`chat-username-${msg.id}`}>
              {msg.username}
            </span>
            <span className={`text-xs ${isOwnMessage ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
              {timestamp}
            </span>
          </div>
          <div className="text-sm break-words" data-testid={`chat-text-${msg.id}`}>
            {msg.message}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-4 p-4 border-b border-border bg-background">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate("/world/sphere")}
          data-testid="button-back"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-xl font-bold">Чат</h1>
          <p className="text-sm text-muted-foreground">
            Сфера • {messages.length} сообщений
          </p>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-background">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <p className="text-muted-foreground">Нет сообщений</p>
            <p className="text-sm text-muted-foreground mt-2">
              Напишите что-нибудь или используйте /roll для броска кубиков
            </p>
          </div>
        ) : (
          <>
            {messages.map(renderMessage)}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {/* Input */}
      <div className="border-t border-border bg-background p-4">
        <form onSubmit={handleSendMessage} className="flex gap-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Сообщение или /roll 2d6+3..."
            disabled={isSending}
            className="flex-1"
            data-testid="input-chat-message"
          />
          <Button
            type="submit"
            disabled={!inputValue.trim() || isSending}
            data-testid="button-send-message"
          >
            <Send className="w-4 h-4" />
          </Button>
        </form>
        <div className="mt-2 text-xs text-muted-foreground">
          <strong>Команды:</strong> /roll 1d6, /roll 2d20+5, /roll d100-10
        </div>
      </div>
    </div>
  );
}
