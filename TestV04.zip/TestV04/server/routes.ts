import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocket, WebSocketServer } from "ws";
import { storage } from "./storage";
import bcrypt from "bcryptjs";
import { insertUserSchema, insertCharacterSchema, insertRecipeSchema } from "@shared/schema";
import { loadUser, requireAuth, requireRole } from "./middleware/auth";
import type { User, Character } from "@shared/schema";
import { parseDiceCommand } from "./utils/dice";

const INVITE_CODE = "R2D2";

export async function registerRoutes(app: Express): Promise<Server> {
  // Load user middleware for all routes
  app.use(loadUser);

  // ========== AUTH ROUTES ==========
  
  // Register
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { username, password, inviteCode } = req.body;

      if (inviteCode !== INVITE_CODE) {
        return res.status(400).json({ message: "Неверный пригласительный код" });
      }

      const parsed = insertUserSchema.safeParse({ username, password });
      if (!parsed.success) {
        return res
          .status(400)
          .json({ message: parsed.error.errors[0].message });
      }

      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Пользователь уже существует" });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const user = await storage.createUser({
        username,
        password: hashedPassword,
      });

      req.session.userId = user.id;
      res.json({ id: user.id, username: user.username, role: user.role });
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;

      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Неверный логин или пароль" });
      }

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ message: "Неверный логин или пароль" });
      }

      req.session.userId = user.id;
      res.json({ id: user.id, username: user.username, role: user.role });
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Logout
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Ошибка при выходе" });
      }
      res.json({ message: "Успешный выход" });
    });
  });

  // Get current user
  app.get("/api/auth/me", requireAuth, (req, res) => {
    if (!req.user) {
      return res.status(401).json({ message: "Не авторизован" });
    }
    res.json({
      id: req.user.id,
      username: req.user.username,
      role: req.user.role,
    });
  });

  // ========== CHARACTER ROUTES ==========
  
  // Get characters for current user
  app.get("/api/characters", requireAuth, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Не авторизован" });
      }

      const characters = await storage.getCharactersByUserId(req.user.id);
      res.json(characters);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Get character by ID
  app.get("/api/characters/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const character = await storage.getCharacter(id);

      if (!character) {
        return res.status(404).json({ message: "Персонаж не найден" });
      }

      if (character.userId !== req.user?.id) {
        return res.status(403).json({ message: "Доступ запрещён" });
      }

      res.json(character);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Create character
  app.post("/api/characters", requireAuth, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Не авторизован" });
      }

      const existingCharacters = await storage.getCharactersByUserId(req.user.id);
      if (existingCharacters.length >= 2) {
        return res
          .status(400)
          .json({ message: "Максимум 2 персонажа на аккаунт" });
      }

      const parsed = insertCharacterSchema.safeParse({
        ...req.body,
        userId: req.user.id,
      });

      if (!parsed.success) {
        return res
          .status(400)
          .json({ message: parsed.error.errors[0].message });
      }

      const character = await storage.createCharacter(parsed.data);
      res.json(character);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Update character
  app.patch("/api/characters/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const character = await storage.getCharacter(id);

      if (!character) {
        return res.status(404).json({ message: "Персонаж не найден" });
      }

      if (character.userId !== req.user?.id) {
        return res.status(403).json({ message: "Доступ запрещён" });
      }

      const updated = await storage.updateCharacter(id, req.body);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Delete character
  app.delete("/api/characters/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const character = await storage.getCharacter(id);

      if (!character) {
        return res.status(404).json({ message: "Персонаж не найден" });
      }

      if (character.userId !== req.user?.id) {
        return res.status(403).json({ message: "Доступ запрещён" });
      }

      await storage.deleteCharacter(id);
      res.json({ message: "Персонаж удалён" });
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // ========== ACTIVE EFFECTS ROUTES ==========
  
  // Get character active effects
  app.get("/api/characters/:id/effects", requireAuth, async (req, res) => {
    try {
      const characterId = parseInt(req.params.id);
      const character = await storage.getCharacter(characterId);

      if (!character) {
        return res.status(404).json({ message: "Персонаж не найден" });
      }

      if (character.userId !== req.user?.id) {
        return res.status(403).json({ message: "Доступ запрещён" });
      }

      const effects = await storage.getActiveEffects(characterId);
      res.json(effects);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Add active effect to character
  app.post("/api/characters/:id/effects", requireAuth, async (req, res) => {
    try {
      const characterId = parseInt(req.params.id);
      const character = await storage.getCharacter(characterId);

      if (!character) {
        return res.status(404).json({ message: "Персонаж не найден" });
      }

      if (character.userId !== req.user?.id) {
        return res.status(403).json({ message: "Доступ запрещён" });
      }

      const { name, description, statModifiers, durationSeconds, sourceItemId, isPositive } = req.body;

      if (!name || !durationSeconds) {
        return res.status(400).json({ message: "Необходимо указать название и длительность" });
      }

      const now = new Date();
      const expiresAt = new Date(now.getTime() + durationSeconds * 1000);

      const effect = await storage.createActiveEffect({
        characterId,
        name,
        description: description || null,
        statModifiers: statModifiers || null,
        startedAt: now,
        expiresAt,
        sourceItemId: sourceItemId || null,
        isPositive: isPositive !== undefined ? isPositive : true,
      });

      res.json(effect);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Create active effect (admin/gm only)
  app.post("/api/effects", requireAuth, requireRole("admin", "gm"), async (req, res) => {
    try {
      const { characterId, name, description, statModifiers, isPositive, expiresAt } = req.body;

      if (!characterId || !name) {
        return res.status(400).json({ message: "Необходимо указать characterId и название" });
      }

      // Verify character exists
      const character = await storage.getCharacter(characterId);
      if (!character) {
        return res.status(404).json({ message: "Персонаж не найден" });
      }

      const now = new Date();
      const effect = await storage.createActiveEffect({
        characterId,
        name,
        description: description || null,
        statModifiers: statModifiers || null,
        startedAt: now,
        expiresAt: expiresAt ? new Date(expiresAt) : null,
        sourceItemId: null,
        isPositive: isPositive !== undefined ? isPositive : true,
      });

      res.status(201).json(effect);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Delete active effect
  app.delete("/api/effects/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Get effect and verify ownership
      const effect = await storage.getActiveEffect(id);
      
      if (!effect) {
        return res.status(404).json({ message: "Эффект не найден" });
      }

      // Get character to verify ownership
      const character = await storage.getCharacter(effect.characterId);
      
      if (!character) {
        return res.status(404).json({ message: "Персонаж не найден" });
      }

      // Verify user owns the character OR is admin/GM
      if (character.userId !== req.user?.id && req.user?.role !== "admin" && req.user?.role !== "gm") {
        return res.status(403).json({ message: "Доступ запрещён" });
      }

      const deleted = await storage.deleteActiveEffect(id);
      
      if (!deleted) {
        return res.status(500).json({ message: "Ошибка удаления" });
      }

      res.json({ message: "Эффект удалён" });
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // ========== INVENTORY ROUTES ==========
  
  // Get character inventory (with joined item data)
  app.get("/api/characters/:id/inventory", requireAuth, async (req, res) => {
    try {
      const characterId = parseInt(req.params.id);
      const character = await storage.getCharacter(characterId);

      if (!character) {
        return res.status(404).json({ message: "Персонаж не найден" });
      }

      if (character.userId !== req.user?.id) {
        return res.status(403).json({ message: "Доступ запрещён" });
      }

      const inventory = await storage.getInventoryWithItems(characterId);
      res.json(inventory);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Expand character inventory grid
  app.patch("/api/characters/:id/inventory/expand", requireAuth, async (req, res) => {
    try {
      const characterId = parseInt(req.params.id);
      const character = await storage.getCharacter(characterId);

      if (!character) {
        return res.status(404).json({ message: "Персонаж не найден" });
      }

      if (character.userId !== req.user?.id) {
        return res.status(403).json({ message: "Доступ запрещён" });
      }

      const { width, height } = req.body;

      // Validate dimensions (max 10x10)
      if (width < 4 || width > 10 || height < 2 || height > 10) {
        return res.status(400).json({ message: "Неверные размеры (4-10 ширина, 2-10 высота)" });
      }

      // Update inventory grid size
      const updated = await storage.updateCharacter(characterId, {
        inventoryGridWidth: width,
        inventoryGridHeight: height,
      });

      res.json(updated);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Add item to character inventory
  app.post("/api/characters/:id/inventory", requireAuth, async (req, res) => {
    try {
      const characterId = parseInt(req.params.id);
      const character = await storage.getCharacter(characterId);

      if (!character) {
        return res.status(404).json({ message: "Персонаж не найден" });
      }

      if (character.userId !== req.user?.id) {
        return res.status(403).json({ message: "Доступ запрещён" });
      }

      const { itemId, gridX, gridY, rotated, stackCount } = req.body;

      if (typeof itemId !== 'number') {
        return res.status(400).json({ message: "itemId обязателен" });
      }

      // Verify item exists
      const item = await storage.getItem(itemId);
      if (!item) {
        return res.status(404).json({ message: "Предмет не найден" });
      }

      // Check weight limit (considering stack count)
      const totalWeight = item.weight * (stackCount || 1);
      if (character.currentWeight + totalWeight > character.maxWeight) {
        return res.status(400).json({ message: "Превышен лимит веса" });
      }

      // Get current inventory for collision detection
      const inventory = await storage.getInventoryByCharacterId(characterId);
      let finalX = gridX;
      let finalY = gridY;
      let finalRotated = rotated || false;

      // If coordinates not provided or invalid, find free position automatically
      if (typeof gridX !== 'number' || typeof gridY !== 'number' || gridX < 0 || gridY < 0) {
        // Helper function to check if item fits at position
        const tryPlacement = (width: number, height: number): { x: number; y: number } | null => {
          for (let y = 0; y <= character.inventoryGridHeight - height; y++) {
            for (let x = 0; x <= character.inventoryGridWidth - width; x++) {
              const hasCollision = inventory.some((invItem) => {
                const invItemData = invItem as any;
                const invWidth = invItemData.item?.width || 1;
                const invHeight = invItemData.item?.height || 1;
                const actualInvWidth = invItemData.rotated ? invHeight : invWidth;
                const actualInvHeight = invItemData.rotated ? invWidth : invHeight;

                // AABB collision detection
                return !(
                  x + width <= invItem.gridX ||
                  x >= invItem.gridX + actualInvWidth ||
                  y + height <= invItem.gridY ||
                  y >= invItem.gridY + actualInvHeight
                );
              });

              if (!hasCollision) {
                return { x, y };
              }
            }
          }
          return null;
        };

        // Try normal orientation first
        let position = tryPlacement(item.width, item.height);
        if (position) {
          finalRotated = false; // Explicitly set to false for normal orientation
        } else if (item.width !== item.height) {
          // If failed and item is not square, try rotated orientation
          position = tryPlacement(item.height, item.width);
          if (position) {
            finalRotated = true; // Set to true for rotated orientation
          }
        }

        if (!position) {
          return res.status(400).json({ message: "Нет свободного места в инвентаре" });
        }

        finalX = position.x;
        finalY = position.y;
      } else {
        // Validate provided coordinates
        const itemWidth = finalRotated ? item.height : item.width;
        const itemHeight = finalRotated ? item.width : item.height;

        // Check grid boundaries
        if (
          finalX < 0 ||
          finalY < 0 ||
          finalX + itemWidth > character.inventoryGridWidth ||
          finalY + itemHeight > character.inventoryGridHeight
        ) {
          return res.status(400).json({ 
            message: "Предмет не помещается в выбранной позиции" 
          });
        }

        // Check for collisions with other items (AABB collision detection)
        const hasCollision = inventory.some((invItem) => {
          const invItemData = invItem as any;
          const invWidth = invItemData.item?.width || 1;
          const invHeight = invItemData.item?.height || 1;
          const actualInvWidth = invItemData.rotated ? invHeight : invWidth;
          const actualInvHeight = invItemData.rotated ? invWidth : invHeight;

          // AABB collision check
          return !(
            finalX + itemWidth <= invItem.gridX ||
            finalX >= invItem.gridX + actualInvWidth ||
            finalY + itemHeight <= invItem.gridY ||
            finalY >= invItem.gridY + actualInvHeight
          );
        });

        if (hasCollision) {
          return res.status(400).json({ 
            message: "Место занято другим предметом" 
          });
        }
      }

      // Add item with validated coordinates
      const inventoryItem = await storage.addInventoryItem({
        characterId,
        itemId,
        gridX: finalX,
        gridY: finalY,
        rotated: finalRotated,
        stackCount: stackCount || 1,
      });

      // Update character weight
      await storage.updateCharacter(characterId, {
        currentWeight: character.currentWeight + totalWeight,
      });

      res.json(inventoryItem);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Move/rotate inventory item
  app.patch("/api/inventory/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const inventoryItem = await storage.getInventoryItem(id);

      if (!inventoryItem) {
        return res.status(404).json({ message: "Предмет не найден" });
      }

      const character = await storage.getCharacter(inventoryItem.characterId);
      if (!character || character.userId !== req.user?.id) {
        return res.status(403).json({ message: "Доступ запрещён" });
      }

      const { gridX, gridY, rotated } = req.body;

      // Get item details for dimensions
      const item = await storage.getItem(inventoryItem.itemId);
      if (!item) {
        return res.status(404).json({ message: "Предмет не найден в базе" });
      }

      // Use provided values or keep existing
      const newGridX = gridX ?? inventoryItem.gridX;
      const newGridY = gridY ?? inventoryItem.gridY;
      const newRotated = rotated ?? inventoryItem.rotated;

      // Calculate item dimensions considering rotation
      const itemWidth = newRotated ? item.height : item.width;
      const itemHeight = newRotated ? item.width : item.height;

      // Check grid boundaries (both negative and positive bounds)
      if (
        newGridX < 0 ||
        newGridY < 0 ||
        newGridX + itemWidth > character.inventoryGridWidth ||
        newGridY + itemHeight > character.inventoryGridHeight
      ) {
        return res.status(400).json({ 
          message: "Предмет не помещается в выбранной позиции" 
        });
      }

      // Get all inventory items with item data for collision check
      const allInventoryItems = await storage.getInventoryWithItems(inventoryItem.characterId);

      // Check for collisions with other items (AABB collision detection)
      for (const otherItem of allInventoryItems) {
        if (otherItem.id === id) continue; // Skip self

        const otherWidth = otherItem.rotated 
          ? otherItem.item.height 
          : otherItem.item.width;
        const otherHeight = otherItem.rotated 
          ? otherItem.item.width 
          : otherItem.item.height;

        // AABB collision check
        const hasCollision = !(
          newGridX + itemWidth <= otherItem.gridX ||
          newGridX >= otherItem.gridX + otherWidth ||
          newGridY + itemHeight <= otherItem.gridY ||
          newGridY >= otherItem.gridY + otherHeight
        );

        if (hasCollision) {
          return res.status(400).json({ 
            message: "Место занято другим предметом" 
          });
        }
      }

      // All checks passed, update position
      const updated = await storage.moveInventoryItem(
        id,
        newGridX,
        newGridY,
        newRotated
      );

      res.json(updated);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Delete inventory item
  app.delete("/api/inventory/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const inventoryItem = await storage.getInventoryItem(id);

      if (!inventoryItem) {
        return res.status(404).json({ message: "Предмет не найден" });
      }

      const character = await storage.getCharacter(inventoryItem.characterId);
      if (!character || character.userId !== req.user?.id) {
        return res.status(403).json({ message: "Доступ запрещён" });
      }

      // Get item details for weight update
      const item = await storage.getItem(inventoryItem.itemId);
      if (item) {
        // Update character weight (considering stack count)
        const totalWeight = item.weight * (inventoryItem.stackCount || 1);
        await storage.updateCharacter(inventoryItem.characterId, {
          currentWeight: Math.max(0, character.currentWeight - totalWeight),
        });
      }

      await storage.deleteInventoryItem(id);
      res.json({ message: "Предмет удалён" });
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Equip inventory item
  app.post("/api/inventory/:id/equip", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { slot } = req.body;

      if (!slot) {
        return res.status(400).json({ message: "Необходимо указать слот" });
      }

      const inventoryItem = await storage.getInventoryItem(id);
      if (!inventoryItem) {
        return res.status(404).json({ message: "Предмет не найден" });
      }

      const character = await storage.getCharacter(inventoryItem.characterId);
      if (!character || character.userId !== req.user?.id) {
        return res.status(403).json({ message: "Доступ запрещён" });
      }

      // Get item details to check requirements
      const item = await storage.getItem(inventoryItem.itemId);
      if (!item) {
        return res.status(404).json({ message: "Предмет не найден в базе" });
      }

      // Check class restrictions
      if (item.classRestrictions && Array.isArray(item.classRestrictions)) {
        if (!item.classRestrictions.includes(character.characterClass)) {
          return res.status(400).json({ 
            message: `Этот предмет не может использовать класс ${character.characterClass}` 
          });
        }
      }

      // Check stat requirements
      if (item.requiredStats && typeof item.requiredStats === 'object') {
        const requirements = item.requiredStats as Record<string, number>;
        for (const [stat, required] of Object.entries(requirements)) {
          const characterStat = Number((character as any)[stat] || 0);
          if (characterStat < required) {
            return res.status(400).json({ 
              message: `Недостаточно ${stat}: требуется ${required}, есть ${characterStat}` 
            });
          }
        }
      }

      const updated = await storage.equipItem(id, slot);
      res.json(updated);
    } catch (error: any) {
      if (error.message && error.message.includes("не может быть экипирован")) {
        return res.status(400).json({ message: error.message });
      }
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Unequip inventory item
  app.post("/api/inventory/:id/unequip", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const inventoryItem = await storage.getInventoryItem(id);

      if (!inventoryItem) {
        return res.status(404).json({ message: "Предмет не найден" });
      }

      const character = await storage.getCharacter(inventoryItem.characterId);
      if (!character || character.userId !== req.user?.id) {
        return res.status(403).json({ message: "Доступ запрещён" });
      }

      // Check if item is actually equipped
      if (!inventoryItem.equippedSlot) {
        return res.status(400).json({ message: "Предмет не экипирован" });
      }

      // Need to provide a valid grid position when unequipping
      const { gridX, gridY, rotated } = req.body;
      if (typeof gridX !== 'number' || typeof gridY !== 'number') {
        return res.status(400).json({ message: "Необходимо указать позицию в инвентаре" });
      }

      // Get item details for validation
      const item = await storage.getItem(inventoryItem.itemId);
      if (!item) {
        return res.status(404).json({ message: "Предмет не найден в базе" });
      }

      // Calculate dimensions (considering rotation)
      const useRotated = rotated !== undefined ? rotated : inventoryItem.rotated;
      const itemWidth = useRotated ? item.height : item.width;
      const itemHeight = useRotated ? item.width : item.height;

      // Check boundary constraints
      if (gridX < 0 || gridY < 0) {
        return res.status(400).json({ message: "Позиция не может быть отрицательной" });
      }

      if (gridX + itemWidth > character.inventoryGridWidth ||
          gridY + itemHeight > character.inventoryGridHeight) {
        return res.status(400).json({ message: "Предмет не помещается в указанной позиции" });
      }

      // Check collision with other items
      const allInventory = await storage.getInventoryByCharacterId(inventoryItem.characterId);
      for (const otherItem of allInventory) {
        if (otherItem.id === id || otherItem.equippedSlot) continue; // Skip self and equipped items

        const otherItemData = await storage.getItem(otherItem.itemId);
        if (!otherItemData) continue;

        const otherWidth = otherItem.rotated ? otherItemData.height : otherItemData.width;
        const otherHeight = otherItem.rotated ? otherItemData.width : otherItemData.height;

        // AABB collision detection
        const hasCollision = !(
          gridX + itemWidth <= otherItem.gridX ||
          gridX >= otherItem.gridX + otherWidth ||
          gridY + itemHeight <= otherItem.gridY ||
          gridY >= otherItem.gridY + otherHeight
        );

        if (hasCollision) {
          return res.status(400).json({ message: "Позиция занята другим предметом" });
        }
      }

      // All validations passed, unequip and move to grid position
      const updated = await storage.updateInventoryItem(id, {
        equippedSlot: null,
        gridX,
        gridY,
        rotated: useRotated,
      });

      res.json(updated);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // ========== ITEM ROUTES ==========
  
  // Get all items
  app.get("/api/items", requireAuth, async (req, res) => {
    try {
      const items = await storage.getAllItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Search items
  app.get("/api/items/search", requireAuth, async (req, res) => {
    try {
      const query = req.query.q as string || "";
      const items = await storage.searchItems(query);
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Get item by ID
  app.get("/api/items/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getItem(id);

      if (!item) {
        return res.status(404).json({ message: "Предмет не найден" });
      }

      res.json(item);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Create item (Admin only)
  app.post("/api/items", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      // Validate stack limits based on category
      const { category, subcategory, stackable, maxStack } = req.body;
      
      if (stackable && maxStack) {
        // Ammo: max 120
        if (subcategory === "ammo" && maxStack > 120) {
          return res.status(400).json({ message: "Максимальный стак патронов: 120" });
        }
        // Currency: max 50
        if (category === "currency" && maxStack > 50) {
          return res.status(400).json({ message: "Максимальный стак валюты: 50" });
        }
      }

      const item = await storage.createItem(req.body);
      
      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "create_item",
        description: `Создан предмет: ${item.name}`,
        metadata: { itemId: item.id },
      });

      res.json(item);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Update item (Admin only)
  app.patch("/api/items/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.updateItem(id, req.body);

      if (!item) {
        return res.status(404).json({ message: "Предмет не найден" });
      }

      res.json(item);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Delete item (Admin only)
  app.delete("/api/items/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getItem(id);

      if (!item) {
        return res.status(404).json({ message: "Предмет не найден" });
      }

      await storage.deleteItem(id);

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "delete_item",
        description: `Удалён предмет: ${item.name}`,
        metadata: { itemId: id },
      });

      res.json({ message: "Предмет удалён" });
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Duplicate item (Admin only)
  app.post("/api/items/:id/duplicate", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.duplicateItem(id);

      if (!item) {
        return res.status(404).json({ message: "Предмет не найден" });
      }

      res.json(item);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // ========== USER/ROLE ROUTES (Admin only) ==========
  
  // Get all users
  app.get("/api/users", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      // Don't send passwords
      const sanitized = users.map(({ password, ...user }) => user);
      res.json(sanitized);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Update user role
  app.patch("/api/users/:id/role", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const id = req.params.id;
      const { role } = req.body;

      if (!["admin", "gm", "player"].includes(role)) {
        return res.status(400).json({ message: "Неверная роль" });
      }

      const user = await storage.updateUserRole(id, role);

      if (!user) {
        return res.status(404).json({ message: "Пользователь не найден" });
      }

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "assign_role",
        description: `Назначена роль ${role} пользователю ${user.username}`,
        metadata: { targetUserId: id, role },
      });

      const { password, ...sanitized } = user;
      res.json(sanitized);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // ========== ACTION LOGS (Admin/GM) ==========
  
  app.get("/api/logs", requireAuth, requireRole("admin", "gm"), async (req, res) => {
    try {
      const logs = await storage.getActionLogs();
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // ========== NEWS ==========

  // Get all news (public)
  app.get("/api/news", async (req, res) => {
    try {
      const news = await storage.getAllNews();
      res.json(news);
    } catch (error) {
      console.error("Get news error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Get single news article (public)
  app.get("/api/news/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const news = await storage.getNewsArticle(id);
      
      if (!news) {
        return res.status(404).json({ message: "Новость не найдена" });
      }

      res.json(news);
    } catch (error) {
      console.error("Get news article error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Create news (Admin only)
  app.post("/api/news", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const { title, content, imageUrl } = req.body;

      if (!title || !content) {
        return res.status(400).json({ message: "Заголовок и содержание обязательны" });
      }

      const news = await storage.createNews({
        title,
        content,
        authorId: req.user!.id,
        imageUrl: imageUrl || null,
      });

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "create_news",
        description: `Создана новость: ${title}`,
        metadata: { newsId: news.id },
      });

      res.json(news);
    } catch (error) {
      console.error("Create news error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Update news (Admin only)
  app.patch("/api/news/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { title, content, imageUrl } = req.body;

      const news = await storage.updateNews(id, {
        title,
        content,
        imageUrl,
      });

      if (!news) {
        return res.status(404).json({ message: "Новость не найдена" });
      }

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "update_news",
        description: `Обновлена новость: ${news.title}`,
        metadata: { newsId: id },
      });

      res.json(news);
    } catch (error) {
      console.error("Update news error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Delete news (Admin only)
  app.delete("/api/news/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const news = await storage.getNewsArticle(id);

      if (!news) {
        return res.status(404).json({ message: "Новость не найдена" });
      }

      await storage.deleteNews(id);

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "delete_news",
        description: `Удалена новость: ${news.title}`,
        metadata: { newsId: id },
      });

      res.json({ message: "Новость удалена" });
    } catch (error) {
      console.error("Delete news error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // ========== LOBBY ==========

  // Get lobby items for a specific world
  app.get("/api/lobby/items/:worldName", requireAuth, async (req, res) => {
    try {
      const { worldName } = req.params;
      
      if (worldName !== "sphere" && worldName !== "table2") {
        return res.status(400).json({ message: "Неверное название мира" });
      }

      const lobbyItems = await storage.getLobbyItems(worldName);
      res.json(lobbyItems);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Spawn item in lobby (admin only)
  app.post("/api/lobby/spawn", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const { itemId, worldName, gridX, gridY, stackCount } = req.body;

      // Validate world name
      if (worldName !== "sphere" && worldName !== "table2") {
        return res.status(400).json({ message: "Неверное название мира" });
      }

      // Validate grid position (10x10 grid)
      if (gridX < 0 || gridX >= 10 || gridY < 0 || gridY >= 10) {
        return res.status(400).json({ message: "Неверная позиция (должна быть 0-9)" });
      }

      // Check if item exists
      const item = await storage.getItem(itemId);
      if (!item) {
        return res.status(404).json({ message: "Предмет не найден" });
      }

      // Check collision with existing items
      const existingItems = await storage.getLobbyItems(worldName);
      const hasCollision = existingItems.some(
        (existing) => existing.gridX === gridX && existing.gridY === gridY
      );

      if (hasCollision) {
        return res.status(400).json({ message: "Позиция занята" });
      }

      // Spawn item
      const lobbyItem = await storage.addLobbyItem({
        itemId,
        worldName,
        gridX,
        gridY,
        stackCount: stackCount || 1,
      });

      // Broadcast to all clients in world
      const broadcast = (req.app as any).broadcastToWorld;
      if (broadcast) {
        broadcast(worldName, 'lobby:spawned', lobbyItem);
      }

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "spawn_item",
        description: `Спавн предмета ${item.name} в ${worldName} (${gridX}, ${gridY})`,
        metadata: { itemId, worldName, gridX, gridY, stackCount },
      });

      res.json(lobbyItem);
    } catch (error) {
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Pickup item from lobby
  app.post("/api/lobby/pickup/:id", requireAuth, async (req, res) => {
    try {
      const lobbyItemId = parseInt(req.params.id);
      const { characterId } = req.body;

      if (!characterId) {
        return res.status(400).json({ message: "characterId обязателен" });
      }

      // Verify character ownership
      const character = await storage.getCharacter(characterId);
      if (!character || character.userId !== req.user!.id) {
        return res.status(403).json({ message: "Нет доступа к персонажу" });
      }

      // Try to lock item (0.8 second lock mechanism)
      const locked = await storage.lockLobbyItem(lobbyItemId, req.user!.id);
      if (!locked) {
        return res.status(409).json({ message: "Предмет уже захвачен" });
      }

      // Get lobby item details (try both worlds)
      let lobbyItem = (await storage.getLobbyItems("sphere")).find((item) => item.id === lobbyItemId);
      let worldName = "sphere";
      
      if (!lobbyItem) {
        lobbyItem = (await storage.getLobbyItems("table2")).find((item) => item.id === lobbyItemId);
        worldName = "table2";
      }

      if (!lobbyItem) {
        await storage.unlockLobbyItem(lobbyItemId);
        return res.status(404).json({ message: "Предмет не найден в лобби" });
      }

      // Check if still locked by this user
      if (lobbyItem.lockedBy !== req.user!.id) {
        return res.status(409).json({ message: "Предмет уже захвачен другим игроком" });
      }

      // Get item details
      const item = await storage.getItem(lobbyItem.itemId);
      if (!item) {
        await storage.unlockLobbyItem(lobbyItemId);
        return res.status(404).json({ message: "Предмет не найден" });
      }

      // Check weight limit (considering stack count)
      const totalWeight = item.weight * (lobbyItem.stackCount || 1);
      if (character.currentWeight + totalWeight > character.maxWeight) {
        await storage.unlockLobbyItem(lobbyItemId);
        return res.status(400).json({ message: "Превышен лимит веса" });
      }

      // Find free position in inventory with AABB collision detection
      // Try both orientations (normal and rotated)
      const inventory = await storage.getInventoryByCharacterId(characterId);
      let freeX = -1;
      let freeY = -1;
      let shouldRotate = false;

      // Helper function to check if item fits at position
      const tryPlacement = (width: number, height: number): { x: number; y: number } | null => {
        for (let y = 0; y <= character.inventoryGridHeight - height; y++) {
          for (let x = 0; x <= character.inventoryGridWidth - width; x++) {
            const hasCollision = inventory.some((invItem) => {
              // Get item dimensions (considering rotation)
              const invItemData = invItem as any;
              const invWidth = invItemData.item?.width || 1;
              const invHeight = invItemData.item?.height || 1;
              const actualInvWidth = invItemData.rotated ? invHeight : invWidth;
              const actualInvHeight = invItemData.rotated ? invWidth : invHeight;

              // AABB collision detection
              return !(
                x + width <= invItem.gridX ||
                x >= invItem.gridX + actualInvWidth ||
                y + height <= invItem.gridY ||
                y >= invItem.gridY + actualInvHeight
              );
            });

            if (!hasCollision) {
              return { x, y };
            }
          }
        }
        return null;
      };

      // Try normal orientation first
      let position = tryPlacement(item.width, item.height);
      
      // If failed and item is not square, try rotated orientation
      if (!position && item.width !== item.height) {
        position = tryPlacement(item.height, item.width);
        if (position) {
          shouldRotate = true;
        }
      }

      if (!position) {
        await storage.unlockLobbyItem(lobbyItemId);
        return res.status(400).json({ message: "Нет свободного места в инвентаре" });
      }

      freeX = position.x;
      freeY = position.y;

      // Add to inventory
      const inventoryItem = await storage.addInventoryItem({
        characterId,
        itemId: lobbyItem.itemId,
        gridX: freeX,
        gridY: freeY,
        rotated: shouldRotate,
        stackCount: lobbyItem.stackCount,
        currentDurability: item.durability,
      });

      // Update character weight (considering stack count)
      await storage.updateCharacter(characterId, { 
        currentWeight: character.currentWeight + totalWeight
      });

      // Delete from lobby
      await storage.deleteLobbyItem(lobbyItemId);

      // Broadcast to all clients in world
      const broadcast = (req.app as any).broadcastToWorld;
      if (broadcast) {
        broadcast(worldName, 'lobby:picked_up', { id: lobbyItemId });
      }

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "pickup_item",
        description: `Подбор предмета ${item.name} из ${worldName}`,
        metadata: { lobbyItemId, itemId: item.id, characterId },
      });

      res.json({ success: true, inventoryItem });
    } catch (error) {
      console.error("Pickup error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // ========== CHAT ==========

  // Get chat messages for a world
  app.get("/api/chat/messages/:worldName", requireAuth, async (req, res) => {
    try {
      const { worldName } = req.params;
      
      if (worldName !== "sphere" && worldName !== "table2") {
        return res.status(400).json({ message: "Неверное название мира" });
      }

      const messages = await storage.getChatMessages(worldName, 300);
      res.json(messages.reverse()); // Reverse to show oldest first
    } catch (error) {
      console.error("Get chat messages error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Send a chat message (or dice roll command)
  app.post("/api/chat/messages", requireAuth, async (req, res) => {
    try {
      const { worldName, message } = req.body;

      if (!worldName || !message) {
        return res.status(400).json({ message: "worldName и message обязательны" });
      }

      if (worldName !== "sphere" && worldName !== "table2") {
        return res.status(400).json({ message: "Неверное название мира" });
      }

      // Check if it's a /roll command
      const isDiceRoll = message.trim().toLowerCase().startsWith("/roll");
      let diceResult: string | null = null;
      let finalMessage = message;

      if (isDiceRoll) {
        const rollCommand = message.trim().slice(5).trim(); // Remove "/roll "
        const result = parseDiceCommand(rollCommand);
        
        if (result.success) {
          diceResult = result.formatted;
          finalMessage = `/roll ${rollCommand}`;
        } else {
          diceResult = result.formatted; // Error message
          finalMessage = `/roll ${rollCommand}`;
        }
      }

      // Create chat message
      const chatMessage = await storage.createChatMessage({
        userId: req.user!.id,
        username: req.user!.username,
        worldName,
        message: finalMessage,
        isDiceRoll,
        diceResult,
      });

      // Broadcast to all clients in world
      const broadcast = (req.app as any).broadcastToWorld;
      if (broadcast) {
        broadcast(worldName, 'chat:message', chatMessage);
      }

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "chat_message",
        description: isDiceRoll ? `Бросок кубика: ${diceResult}` : `Сообщение в чате: ${message}`,
        metadata: { worldName, isDiceRoll, diceResult },
      });

      res.json(chatMessage);
    } catch (error) {
      console.error("Send chat message error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // ========== TRADER ROUTES ==========

  // Get all traders
  app.get("/api/traders", requireAuth, async (req, res) => {
    try {
      const traders = await storage.getAllTraders();
      res.json(traders);
    } catch (error) {
      console.error("Get traders error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Get specific trader
  app.get("/api/traders/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const trader = await storage.getTrader(id);
      
      if (!trader) {
        return res.status(404).json({ message: "Торговец не найден" });
      }

      res.json(trader);
    } catch (error) {
      console.error("Get trader error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Get trader items with full details
  app.get("/api/traders/:id/items", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const trader = await storage.getTrader(id);
      
      if (!trader) {
        return res.status(404).json({ message: "Торговец не найден" });
      }

      const items = await storage.getTraderItemsWithDetails(id);
      res.json(items);
    } catch (error) {
      console.error("Get trader items error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Buy item from trader
  app.post("/api/traders/:id/buy", requireAuth, async (req, res) => {
    try {
      const traderId = parseInt(req.params.id);
      const { traderItemId, characterId } = req.body;

      if (!traderItemId || !characterId) {
        return res.status(400).json({ message: "traderItemId и characterId обязательны" });
      }

      // Verify trader exists and is open
      const trader = await storage.getTrader(traderId);
      if (!trader) {
        return res.status(404).json({ message: "Торговец не найден" });
      }
      if (!trader.isOpen) {
        return res.status(403).json({ message: "Торговец закрыт" });
      }

      // Verify character ownership
      const character = await storage.getCharacter(characterId);
      if (!character || character.userId !== req.user!.id) {
        return res.status(403).json({ message: "Нет доступа к персонажу" });
      }

      // Get trader item
      const traderItems = await storage.getTraderItemsWithDetails(traderId);
      const traderItem = traderItems.find((ti) => ti.id === traderItemId);
      
      if (!traderItem) {
        return res.status(404).json({ message: "Предмет не найден у торговца" });
      }

      // Check stock
      if (traderItem.stock <= 0) {
        return res.status(400).json({ message: "Предмет закончился" });
      }

      // Check if player has enough currency
      const prices = {
        gold: traderItem.priceGold || 0,
        silver: traderItem.priceSilver || 0,
        cores: traderItem.priceCores || 0,
        sovietMedal1: traderItem.priceSovietMedal1 || 0,
        sovietMedal2: traderItem.priceSovietMedal2 || 0,
        sovietMedal3: traderItem.priceSovietMedal3 || 0,
        reichMark1: traderItem.priceReichMark1 || 0,
        reichMark2: traderItem.priceReichMark2 || 0,
        reichMark3: traderItem.priceReichMark3 || 0,
      };

      const playerCurrencies = {
        gold: character.gold,
        silver: character.silver,
        cores: character.cores,
        sovietMedal1: character.sovietMedal1,
        sovietMedal2: character.sovietMedal2,
        sovietMedal3: character.sovietMedal3,
        reichMark1: character.reichMark1,
        reichMark2: character.reichMark2,
        reichMark3: character.reichMark3,
      };

      // Check each currency
      for (const [currency, price] of Object.entries(prices)) {
        if (price > 0) {
          const playerAmount = playerCurrencies[currency as keyof typeof playerCurrencies];
          if (playerAmount < price) {
            return res.status(400).json({ 
              message: `Недостаточно валюты: ${currency} (нужно ${price}, есть ${playerAmount})` 
            });
          }
        }
      }

      // Check weight limit
      const item = traderItem.item;
      const totalWeight = item.weight * 1; // Buying 1 item at a time
      if (character.currentWeight + totalWeight > character.maxWeight) {
        return res.status(400).json({ message: "Превышен лимит веса" });
      }

      // Find free position in inventory
      const inventory = await storage.getInventoryByCharacterId(characterId);
      let freeX = -1;
      let freeY = -1;
      let shouldRotate = false;

      // Helper function to check if item fits at position
      const tryPlacement = (width: number, height: number): { x: number; y: number } | null => {
        for (let y = 0; y <= character.inventoryGridHeight - height; y++) {
          for (let x = 0; x <= character.inventoryGridWidth - width; x++) {
            const hasCollision = inventory.some((invItem) => {
              const invItemData = invItem as any;
              const invWidth = invItemData.item?.width || 1;
              const invHeight = invItemData.item?.height || 1;
              const actualInvWidth = invItemData.rotated ? invHeight : invWidth;
              const actualInvHeight = invItemData.rotated ? invWidth : invHeight;

              return !(
                x + width <= invItem.gridX ||
                x >= invItem.gridX + actualInvWidth ||
                y + height <= invItem.gridY ||
                y >= invItem.gridY + actualInvHeight
              );
            });

            if (!hasCollision) {
              return { x, y };
            }
          }
        }
        return null;
      };

      // Try normal orientation first
      let position = tryPlacement(item.width, item.height);
      
      // If failed and item is not square, try rotated orientation
      if (!position && item.width !== item.height) {
        position = tryPlacement(item.height, item.width);
        if (position) {
          shouldRotate = true;
        }
      }

      if (!position) {
        return res.status(400).json({ message: "Нет свободного места в инвентаре" });
      }

      freeX = position.x;
      freeY = position.y;

      // Deduct currencies
      const newCurrencies: any = {};
      for (const [currency, price] of Object.entries(prices)) {
        if (price > 0) {
          newCurrencies[currency] = 
            playerCurrencies[currency as keyof typeof playerCurrencies] - price;
        }
      }

      // Update character currencies and weight
      await storage.updateCharacter(characterId, {
        ...newCurrencies,
        currentWeight: character.currentWeight + totalWeight,
      });

      // Add item to inventory
      const inventoryItem = await storage.addInventoryItem({
        characterId,
        itemId: item.id,
        gridX: freeX,
        gridY: freeY,
        rotated: shouldRotate,
        stackCount: 1,
        currentDurability: item.durability,
      });

      // Decrease stock
      await storage.updateTraderItem(traderItemId, {
        stock: traderItem.stock - 1,
      });

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "other",
        description: `Покупка ${item.name} у ${trader.name}`,
        metadata: { traderId, traderItemId, itemId: item.id, characterId },
      });

      res.json({ success: true, inventoryItem });
    } catch (error) {
      console.error("Buy item error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // ========== GM PANEL ROUTES ==========

  // Toggle trader status (open/close)
  app.patch("/api/gm/traders/:id/status", requireRole("admin", "gm"), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const trader = await storage.toggleTraderStatus(id);
      
      if (!trader) {
        return res.status(404).json({ message: "Торговец не найден" });
      }

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "other",
        description: `${trader.isOpen ? 'Открыл' : 'Закрыл'} торговца ${trader.name}`,
        metadata: { traderId: id, isOpen: trader.isOpen },
      });

      res.json(trader);
    } catch (error) {
      console.error("Toggle trader status error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Update trader item stock
  app.patch("/api/gm/traders/:traderId/items/:itemId/stock", requireRole("admin", "gm"), async (req, res) => {
    try {
      const itemId = parseInt(req.params.itemId);
      const { stock } = req.body;

      if (typeof stock !== 'number' || stock < 0) {
        return res.status(400).json({ message: "Некорректное значение stock" });
      }

      const updatedItem = await storage.updateTraderItem(itemId, { stock });
      
      if (!updatedItem) {
        return res.status(404).json({ message: "Товар не найден" });
      }

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "other",
        description: `Изменил stock товара (ID: ${itemId}) на ${stock}`,
        metadata: { traderItemId: itemId, newStock: stock },
      });

      res.json(updatedItem);
    } catch (error) {
      console.error("Update trader item stock error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Add item to trader
  app.post("/api/gm/traders/:traderId/items", requireRole("admin", "gm"), async (req, res) => {
    try {
      const traderId = parseInt(req.params.traderId);
      const { itemId, stock, priceGold, priceSilver, priceCores, 
              priceSovietMedal1, priceSovietMedal2, priceSovietMedal3,
              priceReichMark1, priceReichMark2, priceReichMark3 } = req.body;

      if (!itemId || typeof stock !== 'number') {
        return res.status(400).json({ message: "itemId и stock обязательны" });
      }

      // Verify trader exists
      const trader = await storage.getTrader(traderId);
      if (!trader) {
        return res.status(404).json({ message: "Торговец не найден" });
      }

      // Verify item exists
      const item = await storage.getItem(itemId);
      if (!item) {
        return res.status(404).json({ message: "Предмет не найден" });
      }

      const newTraderItem = await storage.addTraderItem({
        traderId,
        itemId,
        stock,
        priceGold: priceGold || 0,
        priceSilver: priceSilver || 0,
        priceCores: priceCores || 0,
        priceSovietMedal1: priceSovietMedal1 || 0,
        priceSovietMedal2: priceSovietMedal2 || 0,
        priceSovietMedal3: priceSovietMedal3 || 0,
        priceReichMark1: priceReichMark1 || 0,
        priceReichMark2: priceReichMark2 || 0,
        priceReichMark3: priceReichMark3 || 0,
      });

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "other",
        description: `Добавил товар ${item.name} к торговцу ${trader.name}`,
        metadata: { traderId, itemId, stock },
      });

      res.json(newTraderItem);
    } catch (error) {
      console.error("Add trader item error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Delete trader item
  app.delete("/api/gm/traders/:traderId/items/:itemId", requireRole("admin", "gm"), async (req, res) => {
    try {
      const itemId = parseInt(req.params.itemId);
      
      const success = await storage.deleteTraderItem(itemId);
      
      if (!success) {
        return res.status(404).json({ message: "Товар не найден" });
      }

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "other",
        description: `Удалил товар (ID: ${itemId}) у торговца`,
        metadata: { traderItemId: itemId },
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Delete trader item error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // ========== CRAFTING SYSTEM ROUTES ==========

  // Get all recipes (public)
  app.get("/api/recipes", requireAuth, async (req, res) => {
    try {
      const recipes = await storage.getAllRecipes();
      res.json(recipes);
    } catch (error) {
      console.error("Get recipes error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Get single recipe
  app.get("/api/recipes/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const recipe = await storage.getRecipe(id);

      if (!recipe) {
        return res.status(404).json({ message: "Рецепт не найден" });
      }

      res.json(recipe);
    } catch (error) {
      console.error("Get recipe error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Craft item
  app.post("/api/craft", requireAuth, async (req, res) => {
    try {
      const { recipeId, characterId } = req.body;

      if (!recipeId || !characterId) {
        return res.status(400).json({ message: "Требуются recipeId и characterId" });
      }

      // Get recipe
      const recipe = await storage.getRecipe(recipeId);
      if (!recipe) {
        return res.status(404).json({ message: "Рецепт не найден" });
      }

      // Get character
      const character = await storage.getCharacter(characterId);
      if (!character) {
        return res.status(404).json({ message: "Персонаж не найден" });
      }

      // Verify character belongs to user
      if (character.userId !== req.user?.id) {
        return res.status(403).json({ message: "Это не ваш персонаж" });
      }

      // Check class requirement
      if (recipe.requiredClass && character.characterClass !== recipe.requiredClass) {
        return res.status(400).json({ 
          message: `Требуется класс: ${recipe.requiredClass}` 
        });
      }

      // Get character inventory
      const inventory = await storage.getInventoryWithItems(characterId);

      // Verify materials
      const materials = recipe.materials as Array<{ itemId: number; quantity: number }>;
      const materialCounts = new Map<number, number>();

      // Count available materials in inventory
      for (const invItem of inventory) {
        const currentCount = materialCounts.get(invItem.itemId) || 0;
        materialCounts.set(invItem.itemId, currentCount + invItem.stackCount);
      }

      // Check if all materials are available
      for (const material of materials) {
        const available = materialCounts.get(material.itemId) || 0;
        if (available < material.quantity) {
          const item = await storage.getItem(material.itemId);
          return res.status(400).json({ 
            message: `Недостаточно материалов: ${item?.name || 'Unknown'} (требуется: ${material.quantity}, есть: ${available})` 
          });
        }
      }

      // Remove materials from inventory
      for (const material of materials) {
        let remainingToRemove = material.quantity;

        // Find inventory items with this material
        const materialItems = inventory.filter(inv => inv.itemId === material.itemId);

        for (const invItem of materialItems) {
          if (remainingToRemove <= 0) break;

          if (invItem.stackCount <= remainingToRemove) {
            // Remove entire stack
            await storage.deleteInventoryItem(invItem.id);
            remainingToRemove -= invItem.stackCount;
          } else {
            // Reduce stack count
            await storage.updateInventoryItem(invItem.id, {
              stackCount: invItem.stackCount - remainingToRemove,
            });
            remainingToRemove = 0;
          }
        }
      }

      // Get result item details
      const resultItem = await storage.getItem(recipe.resultItemId);
      if (!resultItem) {
        return res.status(500).json({ message: "Результирующий предмет не найден" });
      }

      // Add crafted item to inventory (find free space)
      const craftedItem = await storage.addInventoryItem({
        characterId,
        itemId: recipe.resultItemId,
        gridX: 0,
        gridY: 0,
        rotated: false,
        stackCount: recipe.resultQuantity,
        equippedSlot: null,
      });

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "craft",
        description: `Скрафтил ${resultItem.name} x${recipe.resultQuantity}`,
        metadata: { 
          recipeId, 
          characterId, 
          resultItemId: recipe.resultItemId,
          resultQuantity: recipe.resultQuantity,
        },
      });

      res.json({ 
        success: true, 
        craftedItem,
        message: `Успешно создано: ${resultItem.name} x${recipe.resultQuantity}`,
      });
    } catch (error) {
      console.error("Craft error:", error);
      res.status(500).json({ message: "Ошибка крафта" });
    }
  });

  // ========== ADMIN RECIPE ROUTES ==========

  // Create recipe (admin only)
  app.post("/api/admin/recipes", requireRole("admin"), async (req, res) => {
    try {
      const validation = insertRecipeSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Некорректные данные", errors: validation.error.errors });
      }

      const newRecipe = await storage.createRecipe(validation.data);

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "create_recipe",
        description: `Создал рецепт: ${newRecipe.name}`,
        metadata: { recipeId: newRecipe.id },
      });

      res.json(newRecipe);
    } catch (error) {
      console.error("Create recipe error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Update recipe (admin only)
  app.patch("/api/admin/recipes/:id", requireRole("admin"), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updatedRecipe = await storage.updateRecipe(id, req.body);

      if (!updatedRecipe) {
        return res.status(404).json({ message: "Рецепт не найден" });
      }

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "update_recipe",
        description: `Обновил рецепт: ${updatedRecipe.name}`,
        metadata: { recipeId: id },
      });

      res.json(updatedRecipe);
    } catch (error) {
      console.error("Update recipe error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  // Delete recipe (admin only)
  app.delete("/api/admin/recipes/:id", requireRole("admin"), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const recipe = await storage.getRecipe(id);

      if (!recipe) {
        return res.status(404).json({ message: "Рецепт не найден" });
      }

      const success = await storage.deleteRecipe(id);

      if (!success) {
        return res.status(500).json({ message: "Не удалось удалить рецепт" });
      }

      // Log action
      await storage.createActionLog({
        userId: req.user?.id,
        username: req.user?.username || "Unknown",
        actionType: "delete_recipe",
        description: `Удалил рецепт: ${recipe.name}`,
        metadata: { recipeId: id },
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Delete recipe error:", error);
      res.status(500).json({ message: "Ошибка сервера" });
    }
  });

  const httpServer = createServer(app);

  // ========== WEBSOCKET SERVER ==========
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Track connected clients by world
  const worldClients = new Map<string, Set<WebSocket>>();

  // Broadcast to all clients in a specific world
  function broadcastToWorld(worldName: string, event: string, data: any) {
    const clients = worldClients.get(worldName);
    if (!clients) return;

    const message = JSON.stringify({ event, data });
    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  // Handle WebSocket connections
  wss.on('connection', (ws) => {
    let currentWorld: string | null = null;

    ws.on('message', async (message) => {
      try {
        const parsed = JSON.parse(message.toString());
        const { event, data } = parsed;

        switch (event) {
          case 'join_world':
            // Join a specific world (sphere or table2)
            currentWorld = data.worldName || 'sphere';
            
            if (!worldClients.has(currentWorld!)) {
              worldClients.set(currentWorld!, new Set());
            }
            worldClients.get(currentWorld!)!.add(ws);

            // Send current lobby items
            const lobbyItems = await storage.getLobbyItems(currentWorld!);
            ws.send(JSON.stringify({ event: 'lobby:list', data: lobbyItems }));
            break;

          case 'leave_world':
            if (currentWorld && worldClients.has(currentWorld)) {
              worldClients.get(currentWorld)!.delete(ws);
            }
            currentWorld = null;
            break;

          case 'chat:request_history':
            // Send chat history for current world
            if (currentWorld) {
              const chatMessages = await storage.getChatMessages(currentWorld, 300);
              ws.send(JSON.stringify({ event: 'chat:history', data: chatMessages.reverse() }));
            }
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      // Clean up on disconnect
      if (currentWorld && worldClients.has(currentWorld)) {
        worldClients.get(currentWorld)!.delete(ws);
      }
    });
  });

  // Attach broadcast function to app for use in API routes
  (app as any).broadcastToWorld = broadcastToWorld;

  return httpServer;
}
