// Dice rolling utility for chat /roll command
// Supports formats: d6, 2d20, d100+5, 3d6-2, etc.

interface DiceRollResult {
  success: boolean;
  formula: string;
  total: number;
  rolls: number[];
  modifier: number;
  formatted: string;
}

/**
 * Parse and execute a dice roll command
 * @param command - dice command like "2d6+3", "d20", "3d100-5"
 * @returns DiceRollResult with rolls and total
 */
export function parseDiceCommand(command: string): DiceRollResult {
  // Remove /roll prefix if present
  const cleanCommand = command.trim().toLowerCase().replace(/^\/roll\s+/, '');
  
  // Match pattern: [count]d[sides][+/-][modifier]
  // Examples: d6, 2d20, 3d6+5, d100-2
  const pattern = /^(\d*)d(\d+)(([+-])(\d+))?$/;
  const match = cleanCommand.match(pattern);
  
  if (!match) {
    return {
      success: false,
      formula: cleanCommand,
      total: 0,
      rolls: [],
      modifier: 0,
      formatted: `Неверный формат. Используйте: d6, 2d20, 3d6+5, d100-2`,
    };
  }
  
  const count = parseInt(match[1] || '1', 10);
  const sides = parseInt(match[2], 10);
  const modifierSign = match[4];
  const modifierValue = match[5] ? parseInt(match[5], 10) : 0;
  const modifier = modifierSign === '-' ? -modifierValue : modifierValue;
  
  // Validate limits
  if (count < 1 || count > 20) {
    return {
      success: false,
      formula: cleanCommand,
      total: 0,
      rolls: [],
      modifier: 0,
      formatted: `Количество кубиков должно быть от 1 до 20`,
    };
  }
  
  if (sides < 2 || sides > 100) {
    return {
      success: false,
      formula: cleanCommand,
      total: 0,
      rolls: [],
      modifier: 0,
      formatted: `Количество граней должно быть от 2 до 100`,
    };
  }
  
  // Roll dice
  const rolls: number[] = [];
  for (let i = 0; i < count; i++) {
    rolls.push(Math.floor(Math.random() * sides) + 1);
  }
  
  const rollSum = rolls.reduce((sum, roll) => sum + roll, 0);
  const total = rollSum + modifier;
  
  // Format result
  const formula = `${count > 1 ? count : ''}d${sides}${modifier !== 0 ? (modifier > 0 ? '+' + modifier : modifier) : ''}`;
  const rollsStr = rolls.length > 1 ? ` [${rolls.join(', ')}]` : '';
  const modifierStr = modifier !== 0 ? ` ${modifier > 0 ? '+' : ''}${modifier}` : '';
  const formatted = `${formula} = ${total}${rollsStr}${modifierStr && rolls.length > 1 ? modifierStr : ''}`;
  
  return {
    success: true,
    formula,
    total,
    rolls,
    modifier,
    formatted,
  };
}
